--
-- PostgreSQL database dump
--

\restrict mnNS2MsD0VJFduHmb5G79peSumBSVDGA1T2apEXmENUyX2PkDX8WgOfgE4txcyh

-- Dumped from database version 16.15
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- Name: AlertChannel; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AlertChannel" AS ENUM (
    'telegram',
    'email'
);


--
-- Name: AlertMetric; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AlertMetric" AS ENUM (
    'cpu_percent',
    'memory_percent',
    'disk_percent',
    'db_down',
    'queue_down',
    'api_down',
    'queue_downtime_ms',
    'queue_latency_ms',
    'queue_failed_jobs'
);


--
-- Name: BatchStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."BatchStatus" AS ENUM (
    'pending',
    'processing',
    'completed',
    'completed_with_errors',
    'cancelled'
);


--
-- Name: JenisKelamin; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."JenisKelamin" AS ENUM (
    'L',
    'P'
);


--
-- Name: JobStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."JobStatus" AS ENUM (
    'pending',
    'processing',
    'completed',
    'failed'
);


--
-- Name: KategoriMateri; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."KategoriMateri" AS ENUM (
    'pencak_silat',
    'organisasi',
    'mental_spiritual',
    'rekreasi'
);


--
-- Name: KtaAppAction; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."KtaAppAction" AS ENUM (
    'SUBMITTED',
    'APPROVED',
    'REJECTED',
    'FORWARDED',
    'SKIPPED',
    'PAYMENT_SETUP',
    'PAYMENT_VERIFIED',
    'CARD_GENERATED',
    'CANCELLED',
    'SUPERADMIN_BYPASS'
);


--
-- Name: KtaAppLevel; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."KtaAppLevel" AS ENUM (
    'RANTING',
    'WILAYAH',
    'DISTRIK',
    'NASIONAL',
    'MEMBER'
);


--
-- Name: KtaAppStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."KtaAppStatus" AS ENUM (
    'SUBMITTED',
    'RANTING_REVIEW',
    'WILAYAH_REVIEW',
    'DISTRIK_REVIEW',
    'NASIONAL_REVIEW',
    'APPROVED',
    'PAYMENT_SETUP',
    'PAYMENT_PENDING',
    'PAYMENT_VERIFIED',
    'CARD_GENERATING',
    'CARD_GENERATED',
    'REJECTED',
    'CANCELLED'
);


--
-- Name: KtaBatchStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."KtaBatchStatus" AS ENUM (
    'IN_PROGRESS',
    'COMPLETED',
    'PARTIAL'
);


--
-- Name: MetodeBayar; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MetodeBayar" AS ENUM (
    'manual',
    'transfer',
    'online'
);


--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'BELUM_BAYAR',
    'MENUNGGU_VERIFIKASI',
    'LUNAS',
    'DITOLAK'
);


--
-- Name: QrSource; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."QrSource" AS ENUM (
    'digital',
    'printed'
);


--
-- Name: Role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Role" AS ENUM (
    'superadmin',
    'admin_distrik',
    'admin_wilayah',
    'admin_ranting',
    'admin_kegiatan',
    'penguji',
    'anggota',
    'admin_nasional',
    'admin_berita'
);


--
-- Name: ScopeType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ScopeType" AS ENUM (
    'nasional',
    'distrik',
    'wilayah',
    'ranting',
    'unit_latihan'
);


--
-- Name: StatusCalon; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."StatusCalon" AS ENUM (
    'diusulkan',
    'mengikuti_pendadaran',
    'lulus',
    'gagal',
    'dibatalkan'
);


--
-- Name: StatusData; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."StatusData" AS ENUM (
    'complete',
    'incomplete'
);


--
-- Name: StatusDisposisi; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."StatusDisposisi" AS ENUM (
    'pending',
    'dibaca',
    'ditindaklanjuti'
);


--
-- Name: StatusDokumen; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."StatusDokumen" AS ENUM (
    'generated',
    'downloaded',
    'revoked'
);


--
-- Name: StatusGaleri; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."StatusGaleri" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


--
-- Name: StatusIuran; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."StatusIuran" AS ENUM (
    'belum_dibayar',
    'menunggu_verifikasi',
    'lunas',
    'menunggak'
);


--
-- Name: StatusKeanggotaan; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."StatusKeanggotaan" AS ENUM (
    'aktif',
    'nonaktif',
    'pindah',
    'keluar',
    'meninggal'
);


--
-- Name: StatusKegiatan; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."StatusKegiatan" AS ENUM (
    'draft',
    'published',
    'closed',
    'cancelled'
);


--
-- Name: StatusKelulusan; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."StatusKelulusan" AS ENUM (
    'lulus',
    'gagal'
);


--
-- Name: StatusKlaim; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."StatusKlaim" AS ENUM (
    'pending',
    'diproses',
    'disetujui',
    'ditolak'
);


--
-- Name: StatusPenugasanPenguji; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."StatusPenugasanPenguji" AS ENUM (
    'pending',
    'approved',
    'rejected'
);


--
-- Name: StatusSesiUjian; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."StatusSesiUjian" AS ENUM (
    'belum_mulai',
    'berlangsung',
    'selesai'
);


--
-- Name: StatusSurat; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."StatusSurat" AS ENUM (
    'draft',
    'diterima',
    'diproses',
    'terkirim',
    'diarsipkan'
);


--
-- Name: StatusUjianPraktek; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."StatusUjianPraktek" AS ENUM (
    'draft',
    'berlangsung',
    'selesai',
    'dibatalkan'
);


--
-- Name: StatusUndangan; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."StatusUndangan" AS ENUM (
    'dikirim',
    'hadir',
    'tidak_hadir'
);


--
-- Name: StatusValidasi; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."StatusValidasi" AS ENUM (
    'pending',
    'approved',
    'rejected'
);


--
-- Name: StatusValidasiNilai; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."StatusValidasiNilai" AS ENUM (
    'pending',
    'approved',
    'rejected'
);


--
-- Name: SumberPeserta; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SumberPeserta" AS ENUM (
    'manual',
    'import',
    'daftar_calon'
);


--
-- Name: TipeDokumen; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TipeDokumen" AS ENUM (
    'kartu_anggota',
    'sertifikat_pendadaran',
    'sertifikat_pelatihan',
    'piagam_prestasi',
    'sertifikat_tingkatan',
    'sertifikat_pelatih',
    'sertifikat_wasit_dan_juri',
    'sertifikat_penguji',
    'piagam_seroja',
    'piagam_melati',
    'piagam_mawar'
);


--
-- Name: TipeKegiatan; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TipeKegiatan" AS ENUM (
    'latihan',
    'pendadaran',
    'ujian_tingkat',
    'rapat',
    'retret',
    'pelantikan',
    'lainnya'
);


--
-- Name: TipeKlaim; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TipeKlaim" AS ENUM (
    'keanggotaan',
    'dokumen'
);


--
-- Name: TipeNotifikasi; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TipeNotifikasi" AS ENUM (
    'welcome',
    'data_incomplete',
    'reminder_latihan',
    'reminder_pendadaran',
    'reminder_iuran',
    'status_klaim',
    'dokumen_ready',
    'umum',
    'forum_reply',
    'forum_solution',
    'kartu_dipindai',
    'anggota_disetujui',
    'pembayaran_terverifikasi',
    'kta_submitted',
    'kta_rejected',
    'kta_approved',
    'kta_fee_notification',
    'kta_payment_verified',
    'kta_generated',
    'kta_approval_request',
    'kta_payment_setup',
    'kta_escalation',
    'kta_escalation_upper'
);


--
-- Name: TipeUnitLatihan; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TipeUnitLatihan" AS ENUM (
    'reguler',
    'khusus'
);


--
-- Name: galeri_moderation_log_append_only(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.galeri_moderation_log_append_only() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'galeri_moderation_log bersifat append-only: UPDATE tidak diizinkan';
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: absensi_latihan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.absensi_latihan (
    id text NOT NULL,
    latihan_id text NOT NULL,
    anggota_id text NOT NULL,
    hadir boolean DEFAULT true NOT NULL,
    catatan text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: anggota; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.anggota (
    id text NOT NULL,
    ranting_id text NOT NULL,
    nomor_anggota text NOT NULL,
    nama_lengkap text NOT NULL,
    jenis_kelamin public."JenisKelamin" NOT NULL,
    tempat_lahir text,
    tanggal_lahir timestamp(3) without time zone,
    alamat text,
    no_hp text,
    email text,
    foto_path text,
    status_keanggotaan public."StatusKeanggotaan" DEFAULT 'aktif'::public."StatusKeanggotaan" NOT NULL,
    tingkat text,
    status_data public."StatusData" DEFAULT 'complete'::public."StatusData" NOT NULL,
    status_validasi public."StatusValidasi" DEFAULT 'pending'::public."StatusValidasi" NOT NULL,
    missing_fields jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    deleted_at timestamp(3) without time zone,
    tahun_dadar text,
    tempat_dadar text,
    is_imported boolean DEFAULT false NOT NULL,
    import_source text,
    imported_at timestamp(3) without time zone,
    no_hp_normalized text,
    version integer DEFAULT 0 NOT NULL,
    created_by_id text,
    updated_by_id text,
    pekerjaan text,
    tanggal_terbit timestamp(3) without time zone,
    tanggal_berlaku_sampai timestamp(3) without time zone
);


--
-- Name: approval_levels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_levels (
    id text NOT NULL,
    name text NOT NULL,
    "roleName" text NOT NULL,
    "order" integer NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: approval_request_levels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_request_levels (
    request_id text NOT NULL,
    approval_level_id text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    decided_by text,
    decided_at timestamp(3) without time zone,
    note text
);


--
-- Name: approval_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_requests (
    id text NOT NULL,
    "requestType" text NOT NULL,
    "itemId" text NOT NULL,
    submitted_by text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completed_at timestamp(3) without time zone
);


--
-- Name: aspek_penilaian; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aspek_penilaian (
    id text NOT NULL,
    kode_aspek text NOT NULL,
    nama_aspek text NOT NULL,
    deskripsi text,
    bobot numeric(65,30) DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    kegiatan_id text
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    action text NOT NULL,
    entity text NOT NULL,
    entity_id text,
    user_id text,
    ip_address text,
    user_agent text,
    details jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ranting_id text
);


--
-- Name: bank_info; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bank_info (
    id text NOT NULL,
    bank_name text NOT NULL,
    account_number text NOT NULL,
    account_name text NOT NULL,
    qris_image_url text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: berita; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.berita (
    id text NOT NULL,
    judul text NOT NULL,
    ringkasan text NOT NULL,
    konten text NOT NULL,
    gambar text,
    tanggal timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    slug text NOT NULL,
    is_visible boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: bulk_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bulk_notifications (
    id text NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    "targetType" text DEFAULT 'all'::text NOT NULL,
    target_ids jsonb,
    scheduled_at timestamp(3) without time zone,
    sent_at timestamp(3) without time zone,
    status text DEFAULT 'draft'::text NOT NULL,
    total_sent integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: calon_anggota; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calon_anggota (
    id text NOT NULL,
    ranting_id text NOT NULL,
    nama_lengkap text NOT NULL,
    jenis_kelamin public."JenisKelamin" NOT NULL,
    tempat_lahir text,
    tanggal_lahir timestamp(3) without time zone,
    alamat text,
    no_hp text,
    email text,
    status public."StatusCalon" DEFAULT 'diusulkan'::public."StatusCalon" NOT NULL,
    usul_oleh_user_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    tingkat text
);


--
-- Name: card_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.card_templates (
    id text NOT NULL,
    name text NOT NULL,
    label text NOT NULL,
    front_image text,
    back_image text,
    overlay_config jsonb NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    distrik_id text
);


--
-- Name: chat_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_members (
    id text NOT NULL,
    room_id text NOT NULL,
    anggota_id text NOT NULL,
    role text DEFAULT 'member'::text NOT NULL,
    joined_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_read_at timestamp(3) without time zone
);


--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_messages (
    id text NOT NULL,
    room_id text NOT NULL,
    sender_id text NOT NULL,
    content text NOT NULL,
    type text DEFAULT 'text'::text NOT NULL,
    status text DEFAULT 'sent'::text NOT NULL,
    read_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: chat_rooms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_rooms (
    id text NOT NULL,
    name text,
    type text DEFAULT 'direct'::text NOT NULL,
    "isGroup" boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: check_ins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.check_ins (
    id text NOT NULL,
    qr_code_id text NOT NULL,
    anggota_id text NOT NULL,
    latihan_id text,
    kegiatan_id text,
    checked_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    source text DEFAULT 'qr_scan'::text NOT NULL
);


--
-- Name: data_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.data_revisions (
    id text NOT NULL,
    entity text NOT NULL,
    entity_id text NOT NULL,
    action text DEFAULT 'UPDATE'::text NOT NULL,
    before jsonb,
    after jsonb,
    diff jsonb,
    changed_by_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: device_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_tokens (
    id text NOT NULL,
    user_id text NOT NULL,
    token text NOT NULL,
    platform text DEFAULT 'android'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: disposisi; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.disposisi (
    id text NOT NULL,
    surat_masuk_id text NOT NULL,
    dari_user_id text NOT NULL,
    kepada_user_id text NOT NULL,
    isi text NOT NULL,
    status public."StatusDisposisi" DEFAULT 'pending'::public."StatusDisposisi" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: distrik; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.distrik (
    id text NOT NULL,
    nasional_id text NOT NULL,
    kode_distrik text NOT NULL,
    nama text NOT NULL,
    alamat text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    is_visible boolean DEFAULT true NOT NULL
);


--
-- Name: document_batch_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_batch_jobs (
    id text NOT NULL,
    type text NOT NULL,
    total_jobs integer NOT NULL,
    completed integer DEFAULT 0 NOT NULL,
    failed integer DEFAULT 0 NOT NULL,
    status public."BatchStatus" DEFAULT 'pending'::public."BatchStatus" NOT NULL,
    created_by text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: document_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_jobs (
    id text NOT NULL,
    batch_id text NOT NULL,
    member_id text NOT NULL,
    nomor_dokumen text,
    status public."JobStatus" DEFAULT 'pending'::public."JobStatus" NOT NULL,
    error text,
    retry_count integer DEFAULT 0 NOT NULL,
    started_at timestamp(3) without time zone,
    completed_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: dokumen; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dokumen (
    id text NOT NULL,
    anggota_id text NOT NULL,
    tipe public."TipeDokumen" NOT NULL,
    nomor_dokumen text NOT NULL,
    file_path text,
    verification_url text,
    signature_id text,
    stamp_id text,
    status public."StatusDokumen" DEFAULT 'generated'::public."StatusDokumen" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: dokumen_kegiatan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dokumen_kegiatan (
    id text NOT NULL,
    kegiatan_id text NOT NULL,
    nama text NOT NULL,
    file_path text,
    tipe text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: dokumen_organisasi; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dokumen_organisasi (
    id text NOT NULL,
    kategori_id text NOT NULL,
    judul text NOT NULL,
    deskripsi text,
    file_path text NOT NULL,
    uploaded_by text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: dokumen_penandatangans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dokumen_penandatangans (
    id text NOT NULL,
    dokumen_type text NOT NULL,
    penandatangan_id text NOT NULL,
    urutan integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    distrik_id text
);


--
-- Name: dokumen_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dokumen_versions (
    id text NOT NULL,
    dokumen_id text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    file_path text NOT NULL,
    changes text,
    created_by text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: donasi_program; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.donasi_program (
    id text NOT NULL,
    nama text NOT NULL,
    deskripsi text NOT NULL,
    target_dana numeric(65,30) NOT NULL,
    terkumpul numeric(65,30) DEFAULT 0 NOT NULL,
    is_visible boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: dues_lock_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dues_lock_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    iuran_id text NOT NULL,
    action text NOT NULL,
    reason text,
    performed_by text NOT NULL,
    performed_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: email_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_events (
    id text NOT NULL,
    email_log_id text,
    event text NOT NULL,
    recipient text,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    data jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: email_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_logs (
    id text NOT NULL,
    "to" text NOT NULL,
    subject text NOT NULL,
    status text NOT NULL,
    provider text,
    error text,
    metadata jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    content text,
    retry_count integer DEFAULT 0 NOT NULL,
    last_retry_at timestamp(3) without time zone
);


--
-- Name: email_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_templates (
    id text NOT NULL,
    name text NOT NULL,
    subject text NOT NULL,
    html_body text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    updated_by text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: evaluasi_latihan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.evaluasi_latihan (
    id text NOT NULL,
    latihan_id text NOT NULL,
    anggota_id text NOT NULL,
    nilai numeric(5,2) NOT NULL,
    catatan text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: feature_flags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feature_flags (
    id text NOT NULL,
    key text NOT NULL,
    is_enabled boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: forum_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.forum_categories (
    id text NOT NULL,
    nama text NOT NULL,
    deskripsi text,
    "order" integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: forum_post_reactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.forum_post_reactions (
    id text NOT NULL,
    post_id text NOT NULL,
    user_id text NOT NULL,
    emoji text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: forum_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.forum_posts (
    id text NOT NULL,
    thread_id text NOT NULL,
    author_id text,
    konten text NOT NULL,
    is_solution boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    parent_id text,
    author_name text,
    images text[] DEFAULT ARRAY[]::text[]
);


--
-- Name: forum_thread_reactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.forum_thread_reactions (
    id text NOT NULL,
    thread_id text NOT NULL,
    user_id text NOT NULL,
    emoji text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: forum_threads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.forum_threads (
    id text NOT NULL,
    category_id text NOT NULL,
    author_id text,
    judul text NOT NULL,
    konten text NOT NULL,
    is_pinned boolean DEFAULT false NOT NULL,
    is_locked boolean DEFAULT false NOT NULL,
    view_count integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    author_name text,
    images text[] DEFAULT ARRAY[]::text[]
);


--
-- Name: galeri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.galeri (
    id text NOT NULL,
    judul text NOT NULL,
    gambar text NOT NULL,
    tanggal timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    is_visible boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    status public."StatusGaleri" DEFAULT 'PENDING'::public."StatusGaleri" NOT NULL,
    storage_key text,
    file_name text,
    mime_type text,
    ukuran_bytes integer,
    uploader_id text,
    reviewer_id text,
    rejected_reason text,
    reviewed_at timestamp(3) without time zone,
    deskripsi text,
    kategori text,
    thumb_key text
);


--
-- Name: galeri_moderation_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.galeri_moderation_log (
    id text NOT NULL,
    galeri_id text NOT NULL,
    actor_id text,
    action text DEFAULT 'REVIEW'::text NOT NULL,
    from_status public."StatusGaleri",
    to_status public."StatusGaleri" NOT NULL,
    reason text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: gamification_badges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gamification_badges (
    id uuid NOT NULL,
    profile_id uuid NOT NULL,
    badge_id text NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    icon text NOT NULL,
    category text NOT NULL,
    earned_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: gamification_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gamification_events (
    id uuid NOT NULL,
    profile_id uuid NOT NULL,
    anggota_id text NOT NULL,
    type text NOT NULL,
    points integer NOT NULL,
    description text NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: gamification_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gamification_profiles (
    id uuid NOT NULL,
    anggota_id text NOT NULL,
    points integer DEFAULT 0 NOT NULL,
    latihan_streak integer DEFAULT 0 NOT NULL,
    iuran_streak integer DEFAULT 0 NOT NULL,
    last_activity timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: gamification_redemptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gamification_redemptions (
    id uuid NOT NULL,
    reward_id uuid NOT NULL,
    anggota_id text NOT NULL,
    points_spent integer NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: gamification_rewards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gamification_rewards (
    id uuid NOT NULL,
    name text NOT NULL,
    description text,
    icon text DEFAULT '🎁'::text NOT NULL,
    point_cost integer NOT NULL,
    stock integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: hasil_pendadaran; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hasil_pendadaran (
    id text NOT NULL,
    kegiatan_id text NOT NULL,
    calon_anggota_id text NOT NULL,
    total_skor numeric(5,2) NOT NULL,
    ranking integer,
    status_kelulusan public."StatusKelulusan" NOT NULL,
    status_validasi public."StatusValidasi" DEFAULT 'pending'::public."StatusValidasi" NOT NULL,
    divalidasi_oleh text,
    divalidasi_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    is_top_ten boolean DEFAULT false NOT NULL
);


--
-- Name: import_batch_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_batch_items (
    id text NOT NULL,
    batch_id text NOT NULL,
    row_index integer NOT NULL,
    "row" jsonb NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    error text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: import_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_batches (
    id text NOT NULL,
    module text NOT NULL,
    file_name text,
    total_rows integer NOT NULL,
    processed integer DEFAULT 0 NOT NULL,
    success integer DEFAULT 0 NOT NULL,
    errors integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    scope jsonb,
    details jsonb,
    imported_by_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completed_at timestamp(3) without time zone
);


--
-- Name: import_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_logs (
    id text NOT NULL,
    module text NOT NULL,
    file_name text,
    total_rows integer NOT NULL,
    success_rows integer NOT NULL,
    error_rows integer NOT NULL,
    details jsonb,
    imported_by text,
    imported_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: item_penilaian; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.item_penilaian (
    id text NOT NULL,
    aspek_id text NOT NULL,
    kode_item text NOT NULL,
    nama_item text NOT NULL,
    skor_maksimal numeric(65,30) DEFAULT 100 NOT NULL,
    bobot numeric(65,30) DEFAULT 1 NOT NULL,
    urutan integer NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: iuran; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.iuran (
    id text NOT NULL,
    anggota_id text NOT NULL,
    periode text NOT NULL,
    jumlah numeric(10,2) NOT NULL,
    tanggal_bayar timestamp(3) without time zone,
    metode_bayar public."MetodeBayar" DEFAULT 'manual'::public."MetodeBayar" NOT NULL,
    status public."StatusIuran" DEFAULT 'belum_dibayar'::public."StatusIuran" NOT NULL,
    bukti_bayar_path text,
    diverifikasi_oleh text,
    diverifikasi_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    due_date timestamp(3) without time zone,
    "isLocked" boolean DEFAULT false NOT NULL,
    locked_at timestamp(3) without time zone,
    locked_by text,
    lock_reason text,
    lock_expires_at timestamp(3) without time zone
);


--
-- Name: iuran_recurring; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.iuran_recurring (
    id text NOT NULL,
    anggota_id text NOT NULL,
    amount numeric(65,30) NOT NULL,
    frequency text DEFAULT 'monthly'::text NOT NULL,
    next_due_date timestamp(3) without time zone NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: iuran_reminders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.iuran_reminders (
    id text NOT NULL,
    iuran_id text NOT NULL,
    sent_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    channel text DEFAULT 'email'::text NOT NULL,
    status text DEFAULT 'sent'::text NOT NULL
);


--
-- Name: jabatan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jabatan (
    id text NOT NULL,
    nama text NOT NULL,
    kode text,
    urutan integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    distrik_id text
);


--
-- Name: kategori_dokumen; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kategori_dokumen (
    id text NOT NULL,
    nama text NOT NULL,
    deskripsi text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: kegiatan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kegiatan (
    id text NOT NULL,
    scope_type public."ScopeType" NOT NULL,
    scope_id text NOT NULL,
    nama text NOT NULL,
    tipe public."TipeKegiatan" NOT NULL,
    lokasi text,
    tanggal_mulai timestamp(3) without time zone NOT NULL,
    tanggal_selesai timestamp(3) without time zone NOT NULL,
    created_by text NOT NULL,
    status public."StatusKegiatan" DEFAULT 'draft'::public."StatusKegiatan" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    admin_kegiatan_id text,
    pengajuan_nilai_oleh text,
    pengajuan_nilai_at timestamp(3) without time zone,
    updated_by_id text
);


--
-- Name: kegiatan_peserta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kegiatan_peserta (
    id text NOT NULL,
    kegiatan_id text NOT NULL,
    anggota_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: kepengurusan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kepengurusan (
    id text NOT NULL,
    user_id text NOT NULL,
    jabatan_id text NOT NULL,
    periode_id text NOT NULL,
    nasional_id text,
    distrik_id text,
    wilayah_id text,
    ranting_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    parent_id text,
    start_date timestamp(3) without time zone,
    end_date timestamp(3) without time zone,
    status text DEFAULT 'approved'::character varying NOT NULL,
    approved_by text,
    approved_at timestamp(3) without time zone,
    rejection_reason text
);


--
-- Name: klaim; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.klaim (
    id text NOT NULL,
    anggota_id text,
    tipe public."TipeKlaim" NOT NULL,
    status public."StatusKlaim" DEFAULT 'pending'::public."StatusKlaim" NOT NULL,
    catatan text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    version integer DEFAULT 0 NOT NULL,
    nama_lengkap text,
    jenis_kelamin text,
    tempat_lahir text,
    tanggal_lahir timestamp(3) without time zone,
    alamat text,
    no_hp text,
    email text,
    ranting_id text,
    bukti_dokumen jsonb,
    approved_by text,
    approved_at timestamp(3) without time zone,
    tempat_dadar text,
    tahun_dadar text
);


--
-- Name: kta_app_histories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kta_app_histories (
    id text NOT NULL,
    kta_application_id text NOT NULL,
    level public."KtaAppLevel" NOT NULL,
    action public."KtaAppAction" NOT NULL,
    actor_id text NOT NULL,
    actor_role text NOT NULL,
    catatan text,
    is_skipped boolean DEFAULT false NOT NULL,
    skipped_reason text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: kta_applications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kta_applications (
    id text NOT NULL,
    anggota_id text NOT NULL,
    nomor_anggota text,
    status public."KtaAppStatus" DEFAULT 'SUBMITTED'::public."KtaAppStatus" NOT NULL,
    biaya numeric(10,2),
    rekening_tujuan text,
    bukti_bayar_path text,
    status_pembayaran public."PaymentStatus" DEFAULT 'BELUM_BAYAR'::public."PaymentStatus" NOT NULL,
    diterbitkan_oleh text,
    diterbitkan_at timestamp(3) without time zone,
    submitted_by_id text NOT NULL,
    submitted_by_role text NOT NULL,
    batch_id text,
    catatan_admin text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: kta_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kta_batches (
    id text NOT NULL,
    name text,
    submitted_by_id text NOT NULL,
    submitted_by_role text NOT NULL,
    scope_level text NOT NULL,
    scope_id text NOT NULL,
    total_submitted integer DEFAULT 0 NOT NULL,
    total_approved integer DEFAULT 0 NOT NULL,
    total_rejected integer DEFAULT 0 NOT NULL,
    total_generated integer DEFAULT 0 NOT NULL,
    status public."KtaBatchStatus" DEFAULT 'IN_PROGRESS'::public."KtaBatchStatus" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: latihan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.latihan (
    id text NOT NULL,
    ranting_id text NOT NULL,
    kegiatan_id text,
    pelatih_id text NOT NULL,
    hari_tanggal timestamp(3) without time zone NOT NULL,
    lokasi text,
    jenis_materi text,
    hasil_latihan_global text,
    rekomendasi_latihan_berikutnya text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: materi_latihan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.materi_latihan (
    id text NOT NULL,
    latihan_id text NOT NULL,
    kategori public."KategoriMateri" NOT NULL,
    detail text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: member_referrals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_referrals (
    id text NOT NULL,
    referrer_id text NOT NULL,
    referred_id text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    "rewardPoints" integer DEFAULT 100 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: monitoring_alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.monitoring_alerts (
    id text NOT NULL,
    name text NOT NULL,
    metric public."AlertMetric" NOT NULL,
    operator text NOT NULL,
    threshold double precision NOT NULL,
    duration integer DEFAULT 0 NOT NULL,
    channels public."AlertChannel"[] NOT NULL,
    telegram_bot_token text,
    telegram_chat_id text,
    email_recipients text,
    cooldown integer DEFAULT 300 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_triggered_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: nasional; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nasional (
    id text NOT NULL,
    nama text NOT NULL,
    kode text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    is_visible boolean DEFAULT true NOT NULL
);


--
-- Name: national_holidays; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.national_holidays (
    id text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    name text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: nilai_pendadaran; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nilai_pendadaran (
    id text NOT NULL,
    kegiatan_id text NOT NULL,
    calon_anggota_id text NOT NULL,
    anggota_id text,
    item_penilaian_id text NOT NULL,
    penguji_user_id text NOT NULL,
    skor numeric(5,2) NOT NULL,
    komentar text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    ujian_praktek_id text,
    status_validasi public."StatusValidasiNilai" DEFAULT 'pending'::public."StatusValidasiNilai" NOT NULL,
    divalidasi_oleh text,
    divalidasi_at timestamp(3) without time zone
);


--
-- Name: notifikasi; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifikasi (
    id text NOT NULL,
    user_id text NOT NULL,
    judul text NOT NULL,
    isi text NOT NULL,
    tipe public."TipeNotifikasi" NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    data jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: oauth_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_accounts (
    id text NOT NULL,
    user_id text NOT NULL,
    provider text NOT NULL,
    provider_id text NOT NULL,
    email text,
    name text NOT NULL,
    photo text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: organisasi; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organisasi (
    id text NOT NULL,
    struktur jsonb NOT NULL,
    is_visible boolean DEFAULT true NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: payment_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_transactions (
    id text NOT NULL,
    iuran_id text NOT NULL,
    order_id text NOT NULL,
    amount numeric(10,2) NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    payment_type text,
    transaction_id text,
    raw_response jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: penandatangans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.penandatangans (
    id text NOT NULL,
    nama text NOT NULL,
    jabatan text NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    distrik_id text
);


--
-- Name: pendaftaran; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pendaftaran (
    id text NOT NULL,
    nama_lengkap text NOT NULL,
    jenis_kelamin public."JenisKelamin" NOT NULL,
    tempat_lahir text,
    tanggal_lahir timestamp(3) without time zone,
    alamat text,
    no_hp text,
    email text,
    sumber_info text,
    status public."StatusValidasi" DEFAULT 'pending'::public."StatusValidasi" NOT NULL,
    catatan text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    ranting_id text
);


--
-- Name: penugasan_penguji; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.penugasan_penguji (
    id text NOT NULL,
    penguji_user_id text NOT NULL,
    kegiatan_id text NOT NULL,
    peran text DEFAULT 'penguji'::text,
    catatan text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    status public."StatusPenugasanPenguji" DEFAULT 'pending'::public."StatusPenugasanPenguji" NOT NULL,
    disetujui_oleh text,
    disetujui_at timestamp(3) without time zone
);


--
-- Name: periode; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.periode (
    id text NOT NULL,
    nama text NOT NULL,
    tgl_mulai timestamp(3) without time zone NOT NULL,
    tgl_selesai timestamp(3) without time zone NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: periode_aktif; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.periode_aktif (
    id text NOT NULL,
    periode_id text NOT NULL,
    level text NOT NULL,
    unit_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: peserta_pendadaran; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.peserta_pendadaran (
    id text NOT NULL,
    kegiatan_id text NOT NULL,
    calon_anggota_id text NOT NULL,
    sumber public."SumberPeserta" DEFAULT 'manual'::public."SumberPeserta" NOT NULL,
    diusulkan_oleh text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: presensi_kegiatan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.presensi_kegiatan (
    id text NOT NULL,
    kegiatan_id text NOT NULL,
    anggota_id text NOT NULL,
    hadir boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: qr_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qr_codes (
    id text NOT NULL,
    anggota_id text NOT NULL,
    token text NOT NULL,
    type text DEFAULT 'member'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    expires_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: qr_scan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qr_scan (
    id text NOT NULL,
    qr_validation_id text NOT NULL,
    scanned_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ip_address text,
    user_agent text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: qr_validation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qr_validation (
    id text NOT NULL,
    dokumen_id text NOT NULL,
    token text NOT NULL,
    is_valid boolean DEFAULT true NOT NULL,
    scanned_at timestamp(3) without time zone,
    scan_count integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    reason text,
    source public."QrSource" DEFAULT 'digital'::public."QrSource" NOT NULL,
    verification_url text
);


--
-- Name: queue_uptime_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.queue_uptime_events (
    id text NOT NULL,
    start_time timestamp(3) without time zone NOT NULL,
    end_time timestamp(3) without time zone,
    duration_ms integer,
    notes text,
    component text DEFAULT 'queue'::text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    approved_at timestamp(3) without time zone,
    approved_by text,
    rejection_reason text,
    status text DEFAULT 'approved'::text NOT NULL
);


--
-- Name: ranting; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ranting (
    id text NOT NULL,
    wilayah_id text NOT NULL,
    kode_ranting text NOT NULL,
    nama text NOT NULL,
    lokasi_latihan text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    is_visible boolean DEFAULT true NOT NULL
);


--
-- Name: risk_flags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.risk_flags (
    id text NOT NULL,
    anggota_id text NOT NULL,
    "riskType" text NOT NULL,
    score numeric(5,4) NOT NULL,
    factors jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: role_menu_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_menu_permissions (
    id text NOT NULL,
    role text NOT NULL,
    menu_key text NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    id text NOT NULL,
    role text NOT NULL,
    key text NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: sambutan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sambutan (
    id text NOT NULL,
    judul text NOT NULL,
    konten text NOT NULL,
    tokoh text,
    foto_tokoh text,
    is_visible boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: sejarah; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sejarah (
    id text NOT NULL,
    konten text NOT NULL,
    is_visible boolean DEFAULT true NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: sesi_ujian_peserta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sesi_ujian_peserta (
    id text NOT NULL,
    ujian_praktek_id text NOT NULL,
    calon_anggota_id text NOT NULL,
    durasi_standar_menit integer DEFAULT 30 NOT NULL,
    tambahan_menit integer DEFAULT 0 NOT NULL,
    mulai_at timestamp(3) without time zone,
    selesai_at timestamp(3) without time zone,
    status public."StatusSesiUjian" DEFAULT 'belum_mulai'::public."StatusSesiUjian" NOT NULL,
    diperpanjang_oleh text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings (
    id text NOT NULL,
    key text NOT NULL,
    value jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: stempel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stempel (
    id text NOT NULL,
    nama text NOT NULL,
    image_path text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    distrik_id text
);


--
-- Name: suppressed_emails; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suppressed_emails (
    id text NOT NULL,
    email text NOT NULL,
    reason text NOT NULL,
    event_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: surat_keluar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.surat_keluar (
    id text NOT NULL,
    nomor_surat text NOT NULL,
    tanggal_surat timestamp(3) without time zone NOT NULL,
    tujuan text NOT NULL,
    perihal text NOT NULL,
    isi text,
    file_path text,
    status public."StatusSurat" DEFAULT 'draft'::public."StatusSurat" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: surat_masuk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.surat_masuk (
    id text NOT NULL,
    nomor_surat text NOT NULL,
    tanggal_surat timestamp(3) without time zone NOT NULL,
    tanggal_terima timestamp(3) without time zone NOT NULL,
    pengirim text NOT NULL,
    perihal text NOT NULL,
    file_scan_path text,
    status public."StatusSurat" DEFAULT 'diterima'::public."StatusSurat" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: tanda_tangan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tanda_tangan (
    id text NOT NULL,
    user_id text NOT NULL,
    nama text NOT NULL,
    jabatan text NOT NULL,
    image_path text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    distrik_id text
);


--
-- Name: tingkatan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tingkatan (
    id text NOT NULL,
    nama text NOT NULL,
    strip_count integer DEFAULT 0 NOT NULL,
    strip_warna text DEFAULT '#94a3b8'::text NOT NULL,
    urutan integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: transfer_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transfer_approvals (
    id text NOT NULL,
    transfer_request_id text NOT NULL,
    side text NOT NULL,
    level text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    decided_by text,
    decided_at timestamp(3) without time zone,
    note text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: transfer_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transfer_requests (
    id text NOT NULL,
    anggota_id text NOT NULL,
    from_ranting_id text NOT NULL,
    to_ranting_id text NOT NULL,
    reason text,
    status text DEFAULT 'pending'::text NOT NULL,
    approved_by text,
    approved_at timestamp(3) without time zone,
    rejected_by text,
    rejected_at timestamp(3) without time zone,
    note text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    requested_by text,
    scope text DEFAULT 'distrik'::text NOT NULL
);


--
-- Name: ujian_praktek; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ujian_praktek (
    id text NOT NULL,
    kegiatan_id text NOT NULL,
    nama text NOT NULL,
    deskripsi text,
    tanggal timestamp(3) without time zone,
    durasi_menit integer,
    status public."StatusUjianPraktek" DEFAULT 'draft'::public."StatusUjianPraktek" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: ujian_praktek_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ujian_praktek_item (
    id text NOT NULL,
    ujian_praktek_id text NOT NULL,
    item_penilaian_id text NOT NULL,
    urutan integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ujian_praktek_penilai; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ujian_praktek_penilai (
    id text NOT NULL,
    ujian_praktek_id text NOT NULL,
    penguji_user_id text NOT NULL,
    catatan text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: undangan_pendadaran; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.undangan_pendadaran (
    id text NOT NULL,
    kegiatan_id text NOT NULL,
    anggota_id text NOT NULL,
    status public."StatusUndangan" DEFAULT 'dikirim'::public."StatusUndangan" NOT NULL,
    dikirim_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    konfirmasi_at timestamp(3) without time zone,
    konfirmasi_oleh text,
    catatan text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: unit_latihan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unit_latihan (
    id text NOT NULL,
    distrik_id text NOT NULL,
    nama text NOT NULL,
    tipe public."TipeUnitLatihan" NOT NULL,
    lokasi text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sessions (
    id text NOT NULL,
    user_id text NOT NULL,
    refresh_token text NOT NULL,
    device_name text,
    ip_address text,
    user_agent text,
    last_used_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    revoked_at timestamp(3) without time zone
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    nama_lengkap text NOT NULL,
    role public."Role" DEFAULT 'anggota'::public."Role" NOT NULL,
    ranting_id text,
    fcm_token text,
    refresh_token text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    phone text,
    must_change_password boolean DEFAULT false NOT NULL,
    failed_login_attempts integer DEFAULT 0 NOT NULL,
    locked_until timestamp(3) without time zone,
    totp_secret text,
    totp_enabled boolean DEFAULT false NOT NULL,
    totp_verified_at timestamp(3) without time zone,
    distrik_id text,
    wilayah_id text
);


--
-- Name: webhook_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_events (
    id text NOT NULL,
    event_id text NOT NULL,
    provider text NOT NULL,
    event_type text,
    payload jsonb,
    processed_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: wilayah; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wilayah (
    id text NOT NULL,
    distrik_id text NOT NULL,
    kode_wilayah text NOT NULL,
    nama text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    is_visible boolean DEFAULT true NOT NULL
);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
014901cd-4572-433f-9a3f-07317ce93772	45b82f59b27ce3202a354eec3da21166d51ace74b67e575a466dbbeb655ea0c8	2026-08-19 05:51:43.647356+00	20260818070644_add_is_visible_to_org_models	\N	\N	2026-08-19 05:51:43.639373+00	1
7098cbf5-706b-41a4-9bf6-152a2c39ae42	015f9f1c8405515e3b8d3875ff551e6d96f00f2e8213b6c9e7b1e74159b35e80	2026-08-19 05:51:42.801069+00	20260531065614_init	\N	\N	2026-08-19 05:51:42.483673+00	1
55635c99-4ad0-4ce0-ae5c-02372c64445b	8add5693858419cacf85ef49c5a91d21a9bede305751db0c7533c0684cf82348	2026-08-19 05:51:43.362253+00	20260726000000_add_monitoring_alerts_and_uptime_notes	\N	\N	2026-08-19 05:51:43.334594+00	1
f737344e-b5e9-4183-b1a6-4e5895801f0f	a0cbdaf0c28fe93b8eae5dd31a39fa1a7cb710ae86ed445f3f489f4ba780dece	2026-08-19 05:51:42.854163+00	20260606000000_add_gamification	\N	\N	2026-08-19 05:51:42.803231+00	1
fab1a101-ed29-4e4e-8461-60e6fd1a0f34	39bda215827ad3d86b5a4fde98bf9679f916003ef3b1172c61ff553c48b181d4	2026-08-19 05:51:42.88259+00	20260606000001_add_rewards	\N	\N	2026-08-19 05:51:42.856198+00	1
25b1ab42-f5e8-4945-bb5e-f35c7d60ae11	688b9d23573ee09549cfecc8b5164b0dd839e88034f7f7ad8330e708af69c2b7	2026-08-19 05:51:43.568436+00	20260809000000_add_undangan_pendadaran	\N	\N	2026-08-19 05:51:43.546074+00	1
373cff8f-39a2-441f-a47f-01d03eb0b59d	7595a785f7b9699b1a16167c61cc439a7dd6e977cd87c1a99708ff0f6edcca8f	2026-08-19 05:51:42.935379+00	20260606234734_add_composite_indexes	\N	\N	2026-08-19 05:51:42.885081+00	1
87c7006e-65c5-4a3f-877e-08a00f23f32d	5e873c8800cecf9107b42fad2457e888a5464f9a8926378297f2d64342c65b7e	2026-08-19 05:51:43.408372+00	20260727000000_add_ujian_praktek	\N	\N	2026-08-19 05:51:43.363984+00	1
6114f0c5-10cd-4702-b644-9f2cc0a7081d	50d59e173a8dab1be17a222644acb32274ea820a690b4902063d7f3645e79ad3	2026-08-19 05:51:42.957853+00	20260609101619_add_email_logs	\N	\N	2026-08-19 05:51:42.93788+00	1
752874b5-dce1-4efe-bea2-0777af5a4eae	c15b121301c403903c9a87f84bcbe47840185a12bf38610912912be69e1a239b	2026-08-19 05:51:42.965911+00	20260609110434_add_email_log_content	\N	\N	2026-08-19 05:51:42.960346+00	1
58f603ce-3b08-4518-aeb6-4bec42f39cef	742945bb404d9710d7e2ee4a3ac02c877b0384924222cfbd705c8a5b05c83ad5	2026-08-19 05:51:42.98787+00	20260609115349_add_email_event_model	\N	\N	2026-08-19 05:51:42.968024+00	1
0c31bf57-5f27-43cd-a81e-dbee29bc859e	b7c45ae76d6f1ee193d44df182086dc25e966d5643997b182a486e1217aae062	2026-08-19 05:51:43.428731+00	20260727000001_add_national_holidays	\N	\N	2026-08-19 05:51:43.41048+00	1
8bdee68f-80e9-465f-9ecc-b453b6045032	4f56737a261d5bf7b19149d8d2f9fbcd25c8c16884550ed284d38e9a0f357496	2026-08-19 05:51:43.010974+00	20260609121735_add_suppressed_email_model	\N	\N	2026-08-19 05:51:42.989944+00	1
9c12f877-321c-4c4c-bd22-1c95c652e15c	97873c0d36e85eb8be32c652503df75512d0f643618a55d7d0a86d4247ac3d8a	2026-08-19 05:51:43.203936+00	20260613161714_add_oauth_and_chat_models	\N	\N	2026-08-19 05:51:43.013017+00	1
ca57d4ed-d484-4bac-b6ac-89c1813a93a1	34401a2cce898a5102fa4e8682e58997e0eb3f91e86b9b1f2500d257261c18fd	2026-08-19 05:51:43.272991+00	20260617143912_add_bank_info	\N	\N	2026-08-19 05:51:43.206347+00	1
a94d2782-f757-488d-8527-6aea5c5f68ec	7eba3e5709c0d52403a2428680e299c5494f89eaa42efd51204269d49f821fea	2026-08-19 05:51:43.446406+00	20260728000000_add_email_templates	\N	\N	2026-08-19 05:51:43.430629+00	1
3023fd18-4c2d-4416-a3d2-1e4d87059e35	f0724d14f5c6bb594e465fb1ff1c3f2a7e5865328c45e23628ff65df77b3d5eb	2026-08-19 05:51:43.282039+00	20260618160057_add_tempat_dadar_tingkat	\N	\N	2026-08-19 05:51:43.275118+00	1
359778b2-cd5a-4066-ac15-caaffb40d8e2	9e2a4cbd1755d0ecf3f56bf0bbaae864e5d2c83a065aee8fd400d0b6757f55e6	2026-08-19 05:51:43.299826+00	20260721000000_add_email_unique	\N	\N	2026-08-19 05:51:43.284373+00	1
da896a73-cdb0-4630-8905-45ffcc780998	974c91887350db5e24238974511267b5a09408c28bcfd74b05293ef2385e5138	2026-08-19 05:51:43.591116+00	20260809100000_org_kode_unique_per_parent	\N	\N	2026-08-19 05:51:43.571433+00	1
6e130b8d-2af2-46c2-9c86-d7a24190792b	75996e55eeb0e048a9e85c9f45987cb630555f8ec14f684278f918ed281ad6cf	2026-08-19 05:51:43.332432+00	20260725000000_add_document_batch_jobs	\N	\N	2026-08-19 05:51:43.302337+00	1
96998dc1-6b00-4bdf-8104-0c3c922949be	860427a935f96625cecf052af1598563b8a56abd484b4474ef6d205fcd1c0d8e	2026-08-19 05:51:43.486731+00	20260731010029_add_forum_notification_types	\N	\N	2026-08-19 05:51:43.448682+00	1
4c333461-4d67-4827-9656-d5aa6d55afe4	fa223a5761fc263030a4553cd75bab8060c096badbd9abd14eeb78d305b2e308	2026-08-19 05:51:43.506716+00	20260806020000_add_penandatangan	\N	\N	2026-08-19 05:51:43.488872+00	1
79d5f97f-7be2-4c0e-b511-2975d0b8caa0	cf2ba51aaf516908d95fdf77de9e4c01ed97e5f9acb8716fff070a63777f81c8	2026-10-26 05:51:54.175779+00	20260820090000_add_user_sessions	\N	\N	2026-10-26 05:51:54.13355+00	1
1a5eb99c-7287-4502-9dc9-611ca4b2b80a	431776d90f786bcfea12883fa6d18b984c1ddcb6a575a49f4df1122aa37aecaf	2026-08-19 05:51:43.529331+00	20260808000000_add_dokumen_penandatangan	\N	\N	2026-08-19 05:51:43.509421+00	1
f85d2c1c-bf48-4fb7-b84e-e7bd1b372078	fd6e2f47cf30cb5815d83aeec13eb6ea668a5185a9d25746992f16b1c9368453	2026-08-19 05:51:43.614329+00	20260809120000_add_tingkatan	\N	\N	2026-08-19 05:51:43.595027+00	1
40764e2a-003e-467f-a1db-6dd6880a9164	a54b0d58c9e83bf6e96e5ff43d8ac349f9ca30c74b9839f55e8f6cbd5cbbb5ca	2026-08-19 05:51:43.543348+00	20260808120000_add_graduation_workflow_status	\N	\N	2026-08-19 05:51:43.531773+00	1
1afb8721-a86f-464e-94f6-78b6577af549	ee44fc6e43b006315d2fe28fe569556ab294e72e93b33c4fa5a7a66e3d22c778	2026-08-19 05:51:43.692414+00	20260818075252_add_public_content_models	\N	\N	2026-08-19 05:51:43.650159+00	1
e17435aa-6fd6-4f22-ba22-261c252423b6	b72e604a47e77768a6a631ec6d7af9926cf87b6e18e03ed8c5b7de2323775fe5	2026-08-19 05:51:43.624172+00	20260810000000_add_anggota_import_tracking	\N	\N	2026-08-19 05:51:43.616673+00	1
79192f99-2ca3-4373-ac04-607ead7e8496	9fcd5fe493c718ff2bfadbced26890551982e881072c7c510454ee91056d7d03	2026-08-19 05:51:43.636375+00	20260812000000_add_user_phone_and_must_change_password	\N	\N	2026-08-19 05:51:43.626026+00	1
b1f026f8-0e64-4b6b-8eaf-3a994d838567	db669444a233992565b3881253f7a1aec8302a3b4e50a36321fd2b49e6ec74c4	2026-08-19 07:04:11.264988+00	20260819070411_add_transfer_approvals	\N	\N	2026-08-19 07:04:11.18793+00	1
4357ff73-24e9-4879-bfbf-9c3346bbce33	27dc6b8dbad5bccbe3965f78c689c4f2dc5b76ead3eb14e81f4d283618948405	2026-08-19 05:51:43.732145+00	20260818161857_add_sambutan_model	\N	\N	2026-08-19 05:51:43.694865+00	1
a6bea0f4-d007-4788-a785-dcb71fa0fa92	b222398d8c71170978e5bd04d17ce7daf7db98d2809b1d84aec3c136ac42dbed	2026-10-26 05:51:54.129708+00	20260820010000_backfill_no_hp_normalized	\N	\N	2026-10-26 05:51:54.121397+00	1
6dfd1ff4-48a2-47ec-a3a1-fdf3c4156ce9	318d8b389f10d5f02bd243cea1c664a3ab0325c2302fc9d41f3a9cda085958e3	2026-08-19 05:51:43.814981+00	20260819053035_org_delete_cascade	\N	\N	2026-08-19 05:51:43.734164+00	1
823e9ed8-9098-47c0-9c69-3de98978ca65	8a3573b9d277b21f5c7305700ca2cbe1aad7d96c04fe20d6f66bd8d3bc173238	2026-10-26 05:51:54.11782+00	20260820000000_hardening_indexes_unique	\N	\N	2026-10-26 05:51:53.897269+00	1
84abc256-d039-4a1a-9ebe-344f1c3c15e0	2d54f1ae38cb4a6a7b9fb61ee331869a2b16ceb1c92470cad9fb543192eccf55	2026-10-26 05:51:54.201966+00	20260820100000_add_webhook_events	\N	\N	2026-10-26 05:51:54.179515+00	1
9fafdde2-2142-4b3b-914c-6c5ed43490ee	dca621e773ebd302ded07760ef5e36fcfa21d37945e418c2ae5be2e9e32c80ff	2026-10-26 05:51:54.218171+00	20260820110000_add_account_lockout	\N	\N	2026-10-26 05:51:54.205305+00	1
d3db6607-b678-4653-80fc-60fadb5b1c55	aa01401d0b45705dd6af69658055dc34becda8a177943d8415c23452efbb1e1c	2026-10-26 05:51:54.230292+00	20260820120000_add_optimistic_lock_version	\N	\N	2026-10-26 05:51:54.221277+00	1
0be20d67-ec4f-474c-9242-ea67f870aaff	0638ff15f2abe76206233ea5affaa88f99f3202a2f1ab92efe0304ce5feb25b4	2026-10-26 05:51:54.242453+00	20260820130000_add_totp_2fa	\N	\N	2026-10-26 05:51:54.233503+00	1
eb7fe859-56e8-481f-93e7-404ac6432295	620b2b6d7d43f9ac1991db5d78df6a74eced8cc7892cf5587e4e9ffab00f39ef	2026-10-26 05:51:54.268243+00	20260820140000_add_data_revisions	\N	\N	2026-10-26 05:51:54.246548+00	1
4e90a0bb-1078-4101-a5b6-9432b491af71	8ab6ae0cfba8c080ca9ee985d8a2fb3ec73d7c30fc50fc6ebedc172c58da39fd	2026-10-26 05:51:54.911148+00	20261012120000_galeri_moderation	\N	\N	2026-10-26 05:51:54.887244+00	1
6e9f62a5-d7ab-489f-9b94-61a4f432d2a8	d1c917292314e0a67a1c0d855da5b84ab0382c1665c7d2271d2d7b136f46f082	2026-10-26 05:51:54.31201+00	20260820150000_add_import_batches	\N	\N	2026-10-26 05:51:54.272301+00	1
747912aa-eef6-409e-a99e-eaa20ebdb798	91e0aeae79e4546379613539e919c3be04b631f4b7f4c27002dd290bf67bd642	2026-10-26 05:51:54.697982+00	20260908120000_card_templates_district_scope	\N	\N	2026-10-26 05:51:54.676786+00	1
1966fea4-ab8e-421a-adb4-fc5acc5c072b	34ece3259a9d404076ed159a0cbf0f4f25fdeb136f8292efa8135f2faef07e12	2026-10-26 05:51:54.345595+00	20260822000000_add_feature_flags_and_audit_fields	\N	\N	2026-10-26 05:51:54.314773+00	1
91b7c2a9-b22c-4148-b58e-402080b1b065	63de664ee4d09c8a34b383c83ff8d17b5dc57c2785f0ac6c1dded19bc71c56d7	2026-10-26 05:51:54.369582+00	20260824000000_update_claims_schema	\N	\N	2026-10-26 05:51:54.349112+00	1
3c9ff036-806e-4e2c-a9f7-027577b8746b	5f0671f0032198227ebb27f9d588d9f7e572eb3e320a120b80a7e01f49cf830a	2026-10-26 05:51:54.833292+00	20260929090000_email_log_retry_tracking	\N	\N	2026-10-26 05:51:54.825847+00	1
463b06b3-b2fd-4ed9-b919-f9d1b296ecfb	06eac92bbcfc1e9e656da51da1d458c571c3b25100ef2204200cfa2908b119f4	2026-10-26 05:51:54.409591+00	20260828100000_cleanup_tipeklaim_enum	\N	\N	2026-10-26 05:51:54.373232+00	1
720475b8-a4b2-4d33-8a6c-626692bd43cb	8f1d015779e3c2926777e674779d55a0c9e674aecf33c5a3737bebdf16fb3050	2026-10-26 05:51:54.72229+00	20260908130000_jabatan_district_scope	\N	\N	2026-10-26 05:51:54.702233+00	1
230e22be-c024-42ae-b9a1-422604b32f92	869ac7b14a5033ec09176665a30ea470f86f5cee62101a3440342945a57638d5	2026-10-26 05:51:54.42604+00	20260828120000_add_parent_id_to_kepengurusan	\N	\N	2026-10-26 05:51:54.412535+00	1
7d9527d5-983a-43b0-b176-260adc203c22	e9099d8b0a5d9c1b063271e698cef6db4a783e71f1f6a02118fe9b020b05c256	2026-10-26 05:51:54.43746+00	20260831000000_add_kepengurusan_dates	\N	\N	2026-10-26 05:51:54.43019+00	1
75b37baa-ed99-4444-937c-fdf591e1a9f2	0478bd9da49b38682ee1ac89bbe69cdde3041a93056fb2e80ecd44f4b7e704e4	2026-10-26 05:51:54.494765+00	20260831120000_card_templates_and_district_scope	\N	\N	2026-10-26 05:51:54.441574+00	1
dc685948-2f84-4c1b-af59-62547aa88a39	bec7be93b6b4f1b57aae78fa5fe0bb1f72f94a9daed67a75ca68d0be8b648fed	2026-10-26 05:51:54.746334+00	20260914014624_qr_scan_log	\N	\N	2026-10-26 05:51:54.725967+00	1
b8450469-8ceb-4e57-af85-4fba2172756b	7676d567b55ac335fbb26fcecf3adb2d1b27ee579f8ffb408b3726eb7fe86f90	2026-10-26 05:51:54.510414+00	20260901000000_add_kepengurusan_approval_workflow	\N	\N	2026-10-26 05:51:54.498106+00	1
93c79142-f50e-44f9-8365-4828d3db3e18	13c4c698dc74729c0b9fb9722c3eaa206cc1d9a9042346f03107562e3ab4f4ca	2026-10-26 05:51:54.536054+00	20260902120000_add_materi_latihan	\N	\N	2026-10-26 05:51:54.513796+00	1
a2619252-8bec-4401-a58a-d4442d1275a3	23fa1bff982812a6494828f16599780e71b4c4859896bae86765086dce26b81e	2026-10-26 05:51:54.554627+00	20260903000000_add_is_top_ten	\N	\N	2026-10-26 05:51:54.539311+00	1
88be854f-4393-40d3-981f-5154325395cd	58ba558b9105f3f3984bbbb79a0400e6552020a9fb50e613fe01037c0076089d	2026-10-26 05:51:54.761898+00	20260914021847_qr_multi_issuance	\N	\N	2026-10-26 05:51:54.749205+00	1
d09586aa-d726-4869-9781-ae34d95e00c8	b98c740ede3fde230e48f4ad55566d8d8603b3dcad3b8972f1dc9eaf52e357ff	2026-10-26 05:51:54.58114+00	20260903000000_add_periode_aktif	\N	\N	2026-10-26 05:51:54.557813+00	1
49ada45b-26c9-4e50-81b8-ee103b26bc50	821c4991b37cc9c8384d6b775abca7547dc7473c50a5b540e73bc67bbdb766d7	2026-10-26 05:51:54.607137+00	20260904082705_add_role_menu_permissions	\N	\N	2026-10-26 05:51:54.584893+00	1
7419e1cb-1eb6-468d-beb7-158323c5fc1c	4edd27621308f0376b54d154c0338735fbbb29b68bddc4e14a07c35d02dd862b	2026-10-26 05:51:54.8433+00	20260929100000_klaim_tempat_tahun_dadar	\N	\N	2026-10-26 05:51:54.835842+00	1
ffc132ae-8d91-4ba7-897d-6d7889920102	9053340926df03d822096f9494798dd37afc72821cb6cdd5998eba8fc7443f77	2026-10-26 05:51:54.672261+00	20260904120000_penilaian_peserta_sesi_per_kegiatan	\N	\N	2026-10-26 05:51:54.611649+00	1
cfcf682f-ce9b-4780-a62f-8245a4995425	85711897c42501c64dc0469507c3037c13d6c687eb983c004cda1bb774eac402	2026-10-26 05:51:54.772089+00	20260914060955_realtime_notif_events	\N	\N	2026-10-26 05:51:54.765285+00	1
0bc88a39-15dd-404a-a5a9-a3788bca5124	eb6178ce263b81b70ca87fbe21227d4e64c05866d1acc407fc9bc6bb157e46f2	2026-10-26 05:51:54.787381+00	20260915130840_add_ranting_id_pendaftaran	\N	\N	2026-10-26 05:51:54.774846+00	1
6fc69918-7706-4fdc-8a32-531150430727	d7014081da27ae02fadec1c43d020154a47459eac89b14d23e8ea553eafe3250	2026-11-15 12:38:12.067887+00	20261109000000_add_admin_berita_role	\N	\N	2026-11-15 12:38:12.03909+00	1
57f53953-06bf-47d0-b5f4-0c0220b8eef7	bcffcf0d8b244d1bc244f4ad73d48a86f056ef995512f573f7e43011f15092e7	2026-10-26 05:51:54.805776+00	20260921000000_iuran_unique_anggota_periode	\N	\N	2026-10-26 05:51:54.790752+00	1
135d5306-0325-4285-88f0-4c69e351a2c4	3101a80a9a918756ec20b9b77fe32788091843f236520920e3dc114abb0072f7	2026-10-26 05:51:54.860937+00	20261004100000_add_user_distrik_wilayah_scope	\N	\N	2026-10-26 05:51:54.846541+00	1
25a50e6f-f237-4e35-a4f6-3e75199b9fd9	2f71645253f267c55368a4a83e53eec5934609b3b1fec733b90b9f6dd2e8b24f	2026-10-26 05:51:54.823193+00	20260921100000_anggota_unique_partial_soft_delete	\N	\N	2026-10-26 05:51:54.809519+00	1
07cf6052-0945-49e7-9582-2fe0af087930	ebe22b03eb096d1c687238b0b674e488431a26fc466e64a955438377e2dfabae	2026-10-26 05:51:54.928401+00	20261013120000_forum_nested_replies	\N	\N	2026-10-26 05:51:54.914171+00	1
8d67dd3c-7535-4c66-a460-1ff91dd4e611	244d378df9c047afdd39bcf2119eacb013b3c4d0650c3fa4377468317d81f977	2026-10-26 05:51:54.871831+00	20261010233000_add_document_types	\N	\N	2026-10-26 05:51:54.864394+00	1
b222139f-7d2f-4066-9376-b023b6562857	4adad6925fc807b8579b3eed4e2d06a29492f3a6ab2ae929747293a3296add2a	2026-10-26 05:51:54.88388+00	20261012120000_add_iuran_due_date	\N	\N	2026-10-26 05:51:54.875352+00	1
09749359-2d78-4069-8ef2-6c72b1dfdba4	47d4e9b3b2a25f40eb0918682cdf301ae19e2b259fe35695b81aad75a269dad4	2026-11-05 01:46:17.50408+00	20261031150000_forum_images_and_reactions	\N	\N	2026-11-05 01:46:17.444684+00	1
4b2a4306-4df6-4fb7-a2c6-56a267452eb2	867ee5554e7c1af5a721f4d816dbeee3f57004a73037b194578953728a1d0cf5	2026-10-26 06:14:19.572727+00	20261026000000_add_role_permissions	\N	\N	2026-10-26 06:14:19.540254+00	1
3f98cc93-b97f-4ddc-a196-457e7a392bbb	318d878ddc64ded4a1afc5db3965c70b0fe7e61a6d3f9fdcd65efdafb3eaed26	2026-11-05 01:46:17.624624+00	20261105000000_add_kta_application_workflow	\N	\N	2026-11-05 01:46:17.51616+00	1
63a84ff4-2940-48a9-b68f-33d2cdd7fae8	c64fd30874a35c1e5b36b0458f6985027a38f67d30b1344a4bab59ce1e3684b8	2026-11-05 01:46:17.441948+00	20261031120000_forum_admin_authors_and_default_categories	\N	\N	2026-11-05 01:46:17.424505+00	1
b12572ee-10ea-42b0-9f6f-bfc59b0c0bdd	ca5c4988507c08c15872266a21e7ce9a3cb0fa4df7f78304c499249d2ef6ee11	2026-11-05 01:46:17.513994+00	20261102120000_add_kta_terbit_berlaku_pekerjaan	\N	\N	2026-11-05 01:46:17.506529+00	1
942c292b-b934-45f1-ad30-f505d68bf213	3d582ba89fc4c40d36f2bf4a51d42d4e9bfd2fb84304414065dc121cdd4b5baa	2026-11-15 12:38:12.159997+00	20261113000000_add_dues_lock_fields	\N	\N	2026-11-15 12:38:12.071742+00	1
8549586f-d593-4ec8-9d9e-d0984198450e	6a777dcbd96d95159bbfcc947ceaf8fd8a6796852d9cc6d145986a0e70173429	2026-11-15 13:03:52.450049+00	20261115000000_fix_iuran_lock_columns	\N	\N	2026-11-15 13:03:52.326298+00	1
e3d08fbf-d6fd-45f4-8ebd-927b02051f30	fd53fdcf5a768202da0ff4953dd9a9a7a83d9fc2410fb692d3a0e164ceed47f9	2026-11-15 13:03:52.509741+00	20261115010000_add_kta_notification_types	\N	\N	2026-11-15 13:03:52.478797+00	1
fe33b666-600b-439f-8686-94bcea652ce4	5a414957e924ef6953d4ac9434e4895f42a6e0dfeacd7a39187676c17b715c01	2026-11-16 13:47:26.137031+00	20261116140000_galeri_deskripsi_kategori	\N	\N	2026-11-16 13:47:26.092827+00	1
146ad26c-1bc0-4178-bce2-0c22db7951fe	68834db5f8c1d31d727f77b29c206661af8116098a6d38cae77d8d869d9d10d9	2026-11-16 14:00:20.001278+00	20261116160000_galeri_thumbnail	\N	\N	2026-11-16 14:00:19.97913+00	1
0b559e70-893b-4994-b74c-6bf65ff0f5ec	c2f64721a84184ff81f929197669d2a93d988f98f85f69a40a53db556102daf0	2026-11-16 14:13:55.810277+00	20261116170000_galeri_moderation_log	\N	\N	2026-11-16 14:13:55.737585+00	1
\.


--
-- Data for Name: absensi_latihan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.absensi_latihan (id, latihan_id, anggota_id, hadir, catatan, created_at) FROM stdin;
\.


--
-- Data for Name: anggota; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.anggota (id, ranting_id, nomor_anggota, nama_lengkap, jenis_kelamin, tempat_lahir, tanggal_lahir, alamat, no_hp, email, foto_path, status_keanggotaan, tingkat, status_data, status_validasi, missing_fields, created_at, updated_at, deleted_at, tahun_dadar, tempat_dadar, is_imported, import_source, imported_at, no_hp_normalized, version, created_by_id, updated_by_id, pekerjaan, tanggal_terbit, tanggal_berlaku_sampai) FROM stdin;
2e8d5f7c-1226-43c9-94d2-5f2d6f23a0b1	e1214623-1776-460b-a931-4bf8ff03da30	E2E-001	E2E Test Member	L	\N	\N	Test Street	08123456789	e2e.member+1794750860513@example.com	\N	aktif	\N	complete	pending	\N	2026-11-15 13:54:20.514	2026-11-15 13:54:20.514	\N	\N	\N	f	\N	\N	\N	0	\N	\N	\N	\N	\N
046c3cb8-9a5a-47bb-b936-c27334e82730	e9bdaa44-1839-4302-8113-b605a1b95bdb	E2E-1794751156807	E2E Test Member	L	\N	\N	Test Street	08123456789	e2e.member+1794751156807@example.com	\N	aktif	\N	complete	pending	\N	2026-11-15 13:59:17.059	2026-11-15 13:59:17.059	\N	\N	\N	f	\N	\N	\N	0	\N	\N	\N	\N	\N
6a096981-4a07-4059-9263-83ac6880e865	e19d1986-f576-4680-9609-7f01fe597e6b	E2E-1794752433513	E2E Test Member	L	\N	\N	Test Street	08123456789	e2e.member+1794752433513@example.com	\N	aktif	\N	complete	pending	\N	2026-11-15 14:20:33.775	2026-11-15 14:20:33.775	\N	\N	\N	f	\N	\N	\N	0	\N	\N	\N	\N	\N
0d74d08b-4ea8-441d-a5e0-c5fcb3600e9d	d778828d-0752-4e88-8254-28459a8485d0	E2E-1794792526089	E2E Test Member	L	\N	\N	Test Street	08123456789	e2e.member+1794792526089@example.com	\N	aktif	\N	complete	pending	\N	2026-11-16 01:28:46.337	2026-11-16 01:28:46.337	\N	\N	\N	f	\N	\N	\N	0	\N	\N	\N	\N	\N
ae2767c8-aed9-4897-b905-0617c5a88985	7cb72afc-51a5-4f17-829e-326211117a65	E2E-1794792737618	E2E Test Member	L	\N	\N	Test Street	08123456789	e2e.member+1794792737618@example.com	\N	aktif	\N	complete	pending	\N	2026-11-16 01:32:18.494	2026-11-16 01:32:18.494	\N	\N	\N	f	\N	\N	\N	0	\N	\N	\N	\N	\N
54aaa629-d2bd-47da-a08f-67eeb338ca81	57b3d03a-2d7a-4d76-ada9-3547ed8c062e	E2E-1794793574689	E2E Test Member	L	\N	\N	Test Street	08123456789	e2e.member+1794793574689@example.com	\N	aktif	\N	complete	pending	\N	2026-11-16 01:46:16.026	2026-11-16 01:46:16.026	\N	\N	\N	f	\N	\N	\N	0	\N	\N	\N	\N	\N
ad185622-0ab8-43ad-b237-f1009ff65a84	5f820086-10bd-4c14-8fd7-87ee2164cd43	E2E-1794793677210	E2E Test Member	L	\N	\N	Test Street	08123456789	e2e.member+1794793677210@example.com	\N	aktif	\N	complete	pending	\N	2026-11-16 01:47:58.054	2026-11-16 01:47:58.054	\N	\N	\N	f	\N	\N	\N	0	\N	\N	\N	\N	\N
\.


--
-- Data for Name: approval_levels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.approval_levels (id, name, "roleName", "order", is_active) FROM stdin;
kta-ranting	Review Ranting	admin_ranting	1	t
kta-wilayah	Review Wilayah	admin_wilayah	2	t
kta-distrik-review	Review Distrik (Pre-Nasional)	admin_distrik	3	t
kta-nasional	Final Approve Nasional	admin_nasional	4	t
\.


--
-- Data for Name: approval_request_levels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.approval_request_levels (request_id, approval_level_id, status, decided_by, decided_at, note) FROM stdin;
\.


--
-- Data for Name: approval_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.approval_requests (id, "requestType", "itemId", submitted_by, status, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: aspek_penilaian; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aspek_penilaian (id, kode_aspek, nama_aspek, deskripsi, bobot, is_active, created_at, updated_at, kegiatan_id) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, action, entity, entity_id, user_id, ip_address, user_agent, details, created_at, ranting_id) FROM stdin;
07f37907-2e54-462b-93eb-4397567322e4	LOGIN	User	d95e739b-52d8-499b-b5ed-6a462e0cc80f	\N	::1	node	{"method": "email", "mustChangePassword": false}	2026-11-15 13:01:01.829	\N
c7e3f7d3-dc3c-46cd-93e7-254aeb088c12	LOGIN	User	ac6a60b8-280b-4e50-acee-1de26e322bad	\N	::1	node	{"method": "email", "mustChangePassword": false}	2026-11-16 15:08:48.309	\N
2ab21cc8-548a-434e-98d3-92f7eeb55dc6	LOGIN	User	c9ea5619-8c08-4c9a-808f-6b104d3d810d	\N	::1	node	{"method": "email", "mustChangePassword": false}	2026-11-15 13:06:05.064	\N
6caf2b56-dbb1-425b-bd5a-51b35b00bd26	KTA_SUBMIT	KtaApplication	c58c0df2-9e37-4201-a7d5-d63ce0f8303c	\N	\N	\N	{"anggotaId": "c0735751-67d2-4b04-ae73-500f0230f48d", "initialStatus": "RANTING_REVIEW", "skippedLevels": []}	2026-11-15 13:06:05.296	\N
210eb166-7b43-4388-8f31-9854fd68015a	LOGIN	User	ac6a60b8-280b-4e50-acee-1de26e322bad	\N	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Freebuff/0.0.203 Chrome/130.0.6723.191 Electron/33.4.11 Safari/537.36	{"method": "email", "mustChangePassword": false}	2026-11-16 15:10:56.587	\N
838bf7bc-7c4a-4ac1-8dba-c614d37063b8	LOGIN	User	7c10db76-a09c-44e7-bb4e-77a255cb30b9	7c10db76-a09c-44e7-bb4e-77a255cb30b9	::1	axios/1.20.0	{"method": "email", "mustChangePassword": false}	2026-11-16 01:28:46.621	\N
f43bc91b-34f7-4d54-91c5-7f128941eb17	LOGIN	User	f001e357-fa08-42f8-a647-095fdf32b757	f001e357-fa08-42f8-a647-095fdf32b757	::1	axios/1.20.0	{"method": "email", "mustChangePassword": false}	2026-11-16 01:32:18.781	\N
6245be8a-f932-423e-810a-b39030d6e636	LOGIN	User	4a3af5b9-8acb-4bc5-9ab1-2efcecc41d04	4a3af5b9-8acb-4bc5-9ab1-2efcecc41d04	::1	axios/1.20.0	{"method": "email", "mustChangePassword": false}	2026-11-16 01:46:16.315	\N
4c540b08-748e-4179-95b6-fdf5e823637f	LOGIN	User	c0f267a7-5bf8-41a2-ae1c-0ebb1e4c8d5d	c0f267a7-5bf8-41a2-ae1c-0ebb1e4c8d5d	::1	axios/1.20.0	{"method": "email", "mustChangePassword": false}	2026-11-16 01:47:58.339	\N
1c2ca672-4d06-44c4-8d58-2fbaabf7b436	REFRESH_TOKEN	User	a1caae12-b751-4f34-bcd7-e81963decde2	\N	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Freebuff/0.0.202 Chrome/130.0.6723.191 Electron/33.4.11 Safari/537.36	\N	2026-11-16 14:45:42.901	\N
9972e9bb-6910-42a6-86ce-db61807d2842	LOGIN	User	584d7c0a-686a-4ac8-a4bf-6bb2dd2c3d8a	\N	::1	node	{"method": "email", "mustChangePassword": false}	2026-11-16 15:08:48.641	\N
bf1e7423-2b5e-4f68-b1f7-5f6c25b2642e	LOGIN	User	584d7c0a-686a-4ac8-a4bf-6bb2dd2c3d8a	\N	::1	curl/8.22.0	{"method": "email", "mustChangePassword": false}	2026-11-16 15:12:00.318	\N
c38ecce1-9683-467c-ae84-fc97253bbc1e	LOGIN	User	36babb59-cf23-4f16-a935-22289712e1b0	\N	::1	curl/8.22.0	{"method": "email", "mustChangePassword": false}	2026-11-16 12:39:58.607	\N
e4321294-f1ab-440f-87a7-da56924a4f58	LOGIN	User	36babb59-cf23-4f16-a935-22289712e1b0	\N	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Freebuff/0.0.202 Chrome/130.0.6723.191 Electron/33.4.11 Safari/537.36	{"method": "email", "mustChangePassword": false}	2026-11-16 12:44:26.275	\N
4b488724-df45-4fb1-8a8d-02afcd56076a	LOGIN	User	36babb59-cf23-4f16-a935-22289712e1b0	\N	::1	curl/8.22.0	{"method": "email", "mustChangePassword": false}	2026-11-16 12:46:21.01	\N
88e208b2-b14a-44f8-a5ba-24574112acce	LOGIN	User	6f3ab50c-a18f-456e-9232-d6114b706944	\N	::1	curl/8.22.0	{"method": "email", "mustChangePassword": false}	2026-11-16 13:49:39.33	\N
4dc2f030-aac0-4f40-be61-e4f2c98a6f49	LOGIN	User	6f3ab50c-a18f-456e-9232-d6114b706944	\N	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Freebuff/0.0.202 Chrome/130.0.6723.191 Electron/33.4.11 Safari/537.36	{"method": "email", "mustChangePassword": false}	2026-11-16 13:50:57.69	\N
093ee081-a909-445b-8730-f5e6fa560883	LOGIN	User	e4658918-fb83-4a57-8b19-af9703e25c21	\N	::1	curl/8.22.0	{"method": "email", "mustChangePassword": false}	2026-11-16 14:04:14.21	\N
eea741bd-43f9-4790-a9a6-991c776c9023	LOGIN	User	e4658918-fb83-4a57-8b19-af9703e25c21	\N	::1	curl/8.22.0	{"method": "email", "mustChangePassword": false}	2026-11-16 14:05:25.874	\N
61c15ddb-93a5-4722-aaf2-b71f9740b9f8	LOGIN	User	147457af-1b08-4a45-8f8b-378222d3906d	\N	::1	curl/8.22.0	{"method": "email", "mustChangePassword": false}	2026-11-16 14:15:30.509	\N
4ea0a6f6-580d-4fdd-92f7-d1b520b3f2ee	LOGIN	User	4ea09ddc-a8ec-41e4-a615-297b6770e777	\N	::1	curl/8.22.0	{"method": "email", "mustChangePassword": false}	2026-11-16 14:15:30.837	\N
544f0637-92bf-4a9a-a2d8-54ca169c388e	LOGIN	User	b94e8c1b-3393-470b-8c69-4991e0144f38	\N	::1	curl/8.22.0	{"method": "email", "mustChangePassword": false}	2026-11-16 14:15:31.149	\N
8e30dd3a-7213-4a73-9440-93bb3b56ee6b	LOGIN	User	3970b5db-9f0f-4b63-b53f-86b8bf83301e	3970b5db-9f0f-4b63-b53f-86b8bf83301e	::1	curl/8.22.0	{"method": "email", "mustChangePassword": false}	2026-11-16 14:38:33.856	\N
9750ca23-b089-4829-b515-89d79b0c0135	LOGIN	User	90d26e6f-6b17-48a0-b1a2-6f898d1aba94	\N	::1	curl/8.22.0	{"method": "email", "mustChangePassword": false}	2026-11-16 14:29:56.284	\N
084a4f8e-f433-4fbe-bade-b3f44a6f94fd	LOGIN	User	90d26e6f-6b17-48a0-b1a2-6f898d1aba94	\N	::1	curl/8.22.0	{"method": "email", "mustChangePassword": false}	2026-11-16 14:30:38.451	\N
972aa876-f49b-4f53-ba32-18de00826646	LOGIN	User	90d26e6f-6b17-48a0-b1a2-6f898d1aba94	\N	::1	curl/8.22.0	{"method": "email", "mustChangePassword": false}	2026-11-16 14:34:36.904	\N
b952c4f1-c37f-42a6-bd87-a463f3d2eb70	LOGIN	User	90d26e6f-6b17-48a0-b1a2-6f898d1aba94	\N	::1	node	{"method": "email", "mustChangePassword": false}	2026-11-16 14:42:42.728	\N
9440e22a-348b-4f48-867b-befc49a8b5e1	LOGIN	User	90d26e6f-6b17-48a0-b1a2-6f898d1aba94	\N	::1	node	{"method": "email", "mustChangePassword": false}	2026-11-16 14:44:56.395	\N
735c7c47-f419-4de8-b5d2-2ecd8710ca64	LOGIN	User	90d26e6f-6b17-48a0-b1a2-6f898d1aba94	\N	::1	curl/8.22.0	{"method": "email", "mustChangePassword": false}	2026-11-16 14:45:18.76	\N
790b6c1d-e912-4bdc-8c19-8fd2a4449085	LOGIN	User	a1caae12-b751-4f34-bcd7-e81963decde2	\N	::1	curl/8.22.0	{"method": "email", "mustChangePassword": false}	2026-11-16 14:30:38.123	\N
5e071fc5-81d7-4617-a229-e6253b6f5195	LOGIN	User	a1caae12-b751-4f34-bcd7-e81963decde2	\N	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Freebuff/0.0.202 Chrome/130.0.6723.191 Electron/33.4.11 Safari/537.36	{"method": "email", "mustChangePassword": false}	2026-11-16 14:33:57.291	\N
176a6d80-971f-41d7-9be7-e2e7ea6a78e8	LOGIN	User	a1caae12-b751-4f34-bcd7-e81963decde2	\N	::1	curl/8.22.0	{"method": "email", "mustChangePassword": false}	2026-11-16 14:38:33.538	\N
4e98b45b-c84d-4c5c-a94d-9d02c3cc5cb3	LOGIN	User	a1caae12-b751-4f34-bcd7-e81963decde2	\N	::1	node	{"method": "email", "mustChangePassword": false}	2026-11-16 14:42:42.447	\N
4cc18b66-72b0-43ee-8821-5834f6d12495	LOGIN	User	a1caae12-b751-4f34-bcd7-e81963decde2	\N	::1	node	{"method": "email", "mustChangePassword": false}	2026-11-16 14:44:56.116	\N
\.


--
-- Data for Name: bank_info; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bank_info (id, bank_name, account_number, account_name, qris_image_url, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: berita; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.berita (id, judul, ringkasan, konten, gambar, tanggal, slug, is_visible, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bulk_notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bulk_notifications (id, title, content, "targetType", target_ids, scheduled_at, sent_at, status, total_sent, created_at) FROM stdin;
\.


--
-- Data for Name: calon_anggota; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calon_anggota (id, ranting_id, nama_lengkap, jenis_kelamin, tempat_lahir, tanggal_lahir, alamat, no_hp, email, status, usul_oleh_user_id, created_at, updated_at, tingkat) FROM stdin;
\.


--
-- Data for Name: card_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.card_templates (id, name, label, front_image, back_image, overlay_config, is_active, created_at, updated_at, distrik_id) FROM stdin;
8b55b665-5556-457e-a72d-13d0feb9431d	classic	Desain Bawaan (Klasik)	\N	\N	{}	t	2026-10-30 01:16:53.604	2026-10-30 01:16:53.604	\N
\.


--
-- Data for Name: chat_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_members (id, room_id, anggota_id, role, joined_at, last_read_at) FROM stdin;
\.


--
-- Data for Name: chat_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_messages (id, room_id, sender_id, content, type, status, read_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chat_rooms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_rooms (id, name, type, "isGroup", created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: check_ins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.check_ins (id, qr_code_id, anggota_id, latihan_id, kegiatan_id, checked_at, source) FROM stdin;
\.


--
-- Data for Name: data_revisions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.data_revisions (id, entity, entity_id, action, before, after, diff, changed_by_id, created_at) FROM stdin;
\.


--
-- Data for Name: device_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.device_tokens (id, user_id, token, platform, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: disposisi; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.disposisi (id, surat_masuk_id, dari_user_id, kepada_user_id, isi, status, created_at) FROM stdin;
\.


--
-- Data for Name: distrik; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.distrik (id, nasional_id, kode_distrik, nama, alamat, created_at, updated_at, is_visible) FROM stdin;
ff8a62f0-8460-4b23-b60c-017bc20bc860	11c1a5ce-f597-4317-bf52-b6481b1e4a0e	TESTD	Test Distrik	\N	2026-11-15 13:48:21.418	2026-11-15 13:48:21.418	t
24200442-6534-4f5c-8d66-2d241a62f992	6cfc26f5-448e-417f-b473-b261ae97537c	TD1794750860495	Test Distrik	\N	2026-11-15 13:54:20.502	2026-11-15 13:54:20.502	t
e114afe8-7254-4358-b409-d6286293ef71	748708af-7f84-4e78-861a-37d6dbc2347b	TD1794751025406	Test Distrik	\N	2026-11-15 13:57:05.415	2026-11-15 13:57:05.415	t
3340fd51-f9a4-4cbf-8f6a-2ba726d6bec2	ed5ce2bf-89b2-4c80-9439-b5d521676cb0	TD1794751156807	Test Distrik	\N	2026-11-15 13:59:16.814	2026-11-15 13:59:16.814	t
36390b4d-10eb-47ce-823d-718c90780230	fa0ee6c6-13ee-4fe3-8387-e3e6e41ac459	TD1794752433513	Test Distrik	\N	2026-11-15 14:20:33.521	2026-11-15 14:20:33.521	t
a261cd25-f0fb-4013-bdea-9c96ee068e4b	a7943766-30bb-4eed-bb09-c64de2ce7dd4	TD1794792526089	Test Distrik	\N	2026-11-16 01:28:46.095	2026-11-16 01:28:46.095	t
88864740-e3f4-4c1a-abc1-20dd9275c9fe	36c321f4-7ba4-4abb-bcfc-88e744ac5138	TD1794792737618	Test Distrik	\N	2026-11-16 01:32:18.239	2026-11-16 01:32:18.239	t
4c0c5dff-6058-4fba-a48e-b1977647d8fb	79b6b164-50f7-4eb9-ad05-be5327f5d991	TD1794793574689	Test Distrik	\N	2026-11-16 01:46:15.76	2026-11-16 01:46:15.76	t
5a265be7-c7c3-4a69-a7f2-d6bac8c82912	6219d2e2-c683-46f7-aafa-ad6fb690c66b	TD1794793677210	Test Distrik	\N	2026-11-16 01:47:57.803	2026-11-16 01:47:57.803	t
\.


--
-- Data for Name: document_batch_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_batch_jobs (id, type, total_jobs, completed, failed, status, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: document_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_jobs (id, batch_id, member_id, nomor_dokumen, status, error, retry_count, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: dokumen; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dokumen (id, anggota_id, tipe, nomor_dokumen, file_path, verification_url, signature_id, stamp_id, status, created_at, updated_at) FROM stdin;
268bc75d-4166-46e1-899c-d7e7e564e33f	0d74d08b-4ea8-441d-a5e0-c5fcb3600e9d	kartu_anggota	DOC-001	\N	\N	\N	\N	generated	2026-11-16 01:28:46.353	2026-11-16 01:28:46.353
5ad08b30-45e9-4731-8bab-8e10a925b3e7	ae2767c8-aed9-4897-b905-0617c5a88985	kartu_anggota	DOC-1794792737618	\N	\N	\N	\N	revoked	2026-11-16 01:32:18.514	2026-11-16 01:32:18.957
3516f104-7729-469e-aa2e-53a47975b312	54aaa629-d2bd-47da-a08f-67eeb338ca81	kartu_anggota	DOC-1794793574689	\N	\N	\N	\N	revoked	2026-11-16 01:46:16.044	2026-11-16 01:46:16.47
cc984dfe-5c6b-4a75-957a-3b3e57941b50	ad185622-0ab8-43ad-b237-f1009ff65a84	kartu_anggota	DOC-1794793677210	\N	\N	\N	\N	revoked	2026-11-16 01:47:58.073	2026-11-16 01:47:58.391
\.


--
-- Data for Name: dokumen_kegiatan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dokumen_kegiatan (id, kegiatan_id, nama, file_path, tipe, created_at) FROM stdin;
\.


--
-- Data for Name: dokumen_organisasi; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dokumen_organisasi (id, kategori_id, judul, deskripsi, file_path, uploaded_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: dokumen_penandatangans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dokumen_penandatangans (id, dokumen_type, penandatangan_id, urutan, created_at, distrik_id) FROM stdin;
\.


--
-- Data for Name: dokumen_versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dokumen_versions (id, dokumen_id, version, file_path, changes, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: donasi_program; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.donasi_program (id, nama, deskripsi, target_dana, terkumpul, is_visible, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: dues_lock_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dues_lock_history (id, iuran_id, action, reason, performed_by, performed_at) FROM stdin;
\.


--
-- Data for Name: email_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_events (id, email_log_id, event, recipient, "timestamp", data, created_at) FROM stdin;
\.


--
-- Data for Name: email_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_logs (id, "to", subject, status, provider, error, metadata, created_at, content, retry_count, last_retry_at) FROM stdin;
aff931b4-d5e7-4ffc-b172-6e7fded8c0aa	test.kta8@example.com	[THS-THM] 📋 Pengajuan KTA Diterima	skipped	dev	\N	{"module": "notifications", "userId": "c9ea5619-8c08-4c9a-808f-6b104d3d810d", "template": "generalNotificationEmail", "notifType": "kta_submitted"}	2026-11-15 13:06:05.301	\n    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n      \n      <h2 style="color: #1a56db;">📋 Pengajuan KTA Diterima</h2>\n      <p>Halo <strong>TEST KTA Anggota 8 (E2E)</strong>,</p>\n      <p>Pengajuan KTA Anda telah dikirim. Status saat ini: RANTING REVIEW. Pantau perkembangannya di aplikasi.</p>\n    \n      \n  <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 20px 0;" />\n  <p style="color: #6b7280; font-size: 12px;">\n    THS-THM System &mdash; Tunggal Hati Seminari - Tunggal Hati Maria\n  </p>\n\n    </div>\n  	0	\N
bc89a4e2-5626-467f-b4b5-433b0c8fbaa8	e2e.member+1794794845631@example.com	[THS-THM] 📋 Pengajuan KTA Diterima	skipped	dev	\N	{"module": "notifications", "userId": "d92a7db5-fbe1-4c0f-8125-d4c95c0b9e94", "template": "generalNotificationEmail", "notifType": "kta_submitted"}	2026-11-16 02:07:27.796	\n    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n      \n      <h2 style="color: #1a56db;">📋 Pengajuan KTA Diterima</h2>\n      <p>Halo <strong>E2E Test Member</strong>,</p>\n      <p>Pengajuan KTA Anda telah dikirim. Status saat ini: RANTING REVIEW. Pantau perkembangannya di aplikasi.</p>\n    \n      \n  <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 20px 0;" />\n  <p style="color: #6b7280; font-size: 12px;">\n    THS-THM System &mdash; Tunggal Hati Seminari - Tunggal Hati Maria\n  </p>\n\n    </div>\n  	0	\N
8655cd45-96f0-42e2-b519-e04e88dd4cbe	e2e.member+1794795339702@example.com	[THS-THM] 📋 Pengajuan KTA Diterima	skipped	dev	\N	{"module": "notifications", "userId": "8a17c610-8b7a-412e-a5e8-46f11ecb910f", "template": "generalNotificationEmail", "notifType": "kta_submitted"}	2026-11-16 02:15:41.611	\n    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n      \n      <h2 style="color: #1a56db;">📋 Pengajuan KTA Diterima</h2>\n      <p>Halo <strong>E2E Test Member</strong>,</p>\n      <p>Pengajuan KTA Anda telah dikirim. Status saat ini: RANTING REVIEW. Pantau perkembangannya di aplikasi.</p>\n    \n      \n  <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 20px 0;" />\n  <p style="color: #6b7280; font-size: 12px;">\n    THS-THM System &mdash; Tunggal Hati Seminari - Tunggal Hati Maria\n  </p>\n\n    </div>\n  	0	\N
789eefc8-50de-4046-b049-33d95ba7ce00	e2e.member+1794799362498@example.com	[THS-THM] 📋 Pengajuan KTA Diterima	skipped	dev	\N	{"module": "notifications", "userId": "dc37edc8-7f27-4976-ae55-cd095ca65e3d", "template": "generalNotificationEmail", "notifType": "kta_submitted"}	2026-11-16 03:22:44.649	\n    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n      \n      <h2 style="color: #1a56db;">📋 Pengajuan KTA Diterima</h2>\n      <p>Halo <strong>E2E Test Member</strong>,</p>\n      <p>Pengajuan KTA Anda telah dikirim. Status saat ini: RANTING REVIEW. Pantau perkembangannya di aplikasi.</p>\n    \n      \n  <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 20px 0;" />\n  <p style="color: #6b7280; font-size: 12px;">\n    THS-THM System &mdash; Tunggal Hati Seminari - Tunggal Hati Maria\n  </p>\n\n    </div>\n  	0	\N
\.


--
-- Data for Name: email_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_templates (id, name, subject, html_body, is_active, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: evaluasi_latihan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.evaluasi_latihan (id, latihan_id, anggota_id, nilai, catatan, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: feature_flags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feature_flags (id, key, is_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: forum_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.forum_categories (id, nama, deskripsi, "order", created_at, updated_at) FROM stdin;
forum-cat-diskusi-umum	Diskusi Umum	Diskusi umum antar anggota	1	2026-11-05 01:46:17.432	2026-11-05 01:46:17.432
forum-cat-pengumuman	Pengumuman	Pengumuman resmi organisasi	2	2026-11-05 01:46:17.432	2026-11-05 01:46:17.432
forum-cat-tanya-jawab	Tanya Jawab	Pertanyaan dan jawaban seputar organisasi	3	2026-11-05 01:46:17.432	2026-11-05 01:46:17.432
\.


--
-- Data for Name: forum_post_reactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.forum_post_reactions (id, post_id, user_id, emoji, created_at) FROM stdin;
\.


--
-- Data for Name: forum_posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.forum_posts (id, thread_id, author_id, konten, is_solution, created_at, updated_at, parent_id, author_name, images) FROM stdin;
\.


--
-- Data for Name: forum_thread_reactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.forum_thread_reactions (id, thread_id, user_id, emoji, created_at) FROM stdin;
\.


--
-- Data for Name: forum_threads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.forum_threads (id, category_id, author_id, judul, konten, is_pinned, is_locked, view_count, created_at, updated_at, author_name, images) FROM stdin;
\.


--
-- Data for Name: galeri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.galeri (id, judul, gambar, tanggal, is_visible, created_at, updated_at, status, storage_key, file_name, mime_type, ukuran_bytes, uploader_id, reviewer_id, rejected_reason, reviewed_at, deskripsi, kategori, thumb_key) FROM stdin;
\.


--
-- Data for Name: galeri_moderation_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.galeri_moderation_log (id, galeri_id, actor_id, action, from_status, to_status, reason, created_at) FROM stdin;
\.


--
-- Data for Name: gamification_badges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gamification_badges (id, profile_id, badge_id, name, description, icon, category, earned_at) FROM stdin;
\.


--
-- Data for Name: gamification_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gamification_events (id, profile_id, anggota_id, type, points, description, "timestamp") FROM stdin;
\.


--
-- Data for Name: gamification_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gamification_profiles (id, anggota_id, points, latihan_streak, iuran_streak, last_activity, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: gamification_redemptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gamification_redemptions (id, reward_id, anggota_id, points_spent, status, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: gamification_rewards; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gamification_rewards (id, name, description, icon, point_cost, stock, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: hasil_pendadaran; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hasil_pendadaran (id, kegiatan_id, calon_anggota_id, total_skor, ranking, status_kelulusan, status_validasi, divalidasi_oleh, divalidasi_at, created_at, updated_at, is_top_ten) FROM stdin;
\.


--
-- Data for Name: import_batch_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_batch_items (id, batch_id, row_index, "row", status, error, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: import_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_batches (id, module, file_name, total_rows, processed, success, errors, status, scope, details, imported_by_id, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: import_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_logs (id, module, file_name, total_rows, success_rows, error_rows, details, imported_by, imported_at) FROM stdin;
\.


--
-- Data for Name: item_penilaian; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.item_penilaian (id, aspek_id, kode_item, nama_item, skor_maksimal, bobot, urutan, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: iuran; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.iuran (id, anggota_id, periode, jumlah, tanggal_bayar, metode_bayar, status, bukti_bayar_path, diverifikasi_oleh, diverifikasi_at, created_at, updated_at, due_date, "isLocked", locked_at, locked_by, lock_reason, lock_expires_at) FROM stdin;
\.


--
-- Data for Name: iuran_recurring; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.iuran_recurring (id, anggota_id, amount, frequency, next_due_date, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: iuran_reminders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.iuran_reminders (id, iuran_id, sent_at, channel, status) FROM stdin;
\.


--
-- Data for Name: jabatan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.jabatan (id, nama, kode, urutan, created_at, updated_at, distrik_id) FROM stdin;
e0c49849-29f9-4466-883d-b50abd44c008	Pastor Moderator	\N	0	2026-10-30 01:16:53.48	2026-10-30 01:16:53.48	\N
4f1cc547-caa5-4fc3-8d31-879d5fe411d3	Koordinator	\N	1	2026-10-30 01:16:53.492	2026-10-30 01:16:53.492	\N
8611f64b-b7d5-4406-80af-ceaf171c7ef4	Wakil Koordinator	\N	2	2026-10-30 01:16:53.497	2026-10-30 01:16:53.497	\N
c6d45c8a-31ec-4719-81fc-9477873ce1e8	Sekretaris	\N	3	2026-10-30 01:16:53.502	2026-10-30 01:16:53.502	\N
5b37b579-c562-4747-9061-8b91b10e0990	Bendahara	\N	4	2026-10-30 01:16:53.506	2026-10-30 01:16:53.506	\N
f7281318-dfa7-4c42-ba91-82ae59952328	Komisi Pengembangan Mental Spiritual	\N	5	2026-10-30 01:16:53.511	2026-10-30 01:16:53.511	\N
c1498f2f-b855-47ca-8988-96af5d0b2917	Komisi Kepelatihan	\N	6	2026-10-30 01:16:53.514	2026-10-30 01:16:53.514	\N
e718cd57-bd5b-4100-b715-2a5c22b00a6a	Komisi Organisasi	\N	7	2026-10-30 01:16:53.518	2026-10-30 01:16:53.518	\N
5274c8e7-8cba-49a4-98f7-935a7306b0ae	Komisi Pengabdian Gereja dan Masyarakat	\N	8	2026-10-30 01:16:53.522	2026-10-30 01:16:53.522	\N
039eeb52-592d-406d-aec0-386fe72ba3b1	Komisi Penelitian dan Pengembangan	\N	9	2026-10-30 01:16:53.526	2026-10-30 01:16:53.526	\N
4e1ddb40-e3b8-4105-b129-3ee83e716ee4	Komisi Ekonomi dan Kewirasusahaan	\N	10	2026-10-30 01:16:53.531	2026-10-30 01:16:53.531	\N
\.


--
-- Data for Name: kategori_dokumen; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kategori_dokumen (id, nama, deskripsi, created_at, updated_at) FROM stdin;
kategori-dokumen-ad-art	AD/ART	Anggaran Dasar dan Rumah Tangga	2026-10-30 01:16:53.573	2026-10-30 01:16:53.573
kategori-dokumen-surat-keputusan	Surat Keputusan	Surat keputusan pengurus dan kepanitiaan	2026-10-30 01:16:53.579	2026-10-30 01:16:53.579
kategori-dokumen-notulensi-rapat	Notulensi Rapat	Catatan hasil rapat pengurus	2026-10-30 01:16:53.583	2026-10-30 01:16:53.583
kategori-dokumen-laporan-kegiatan	Laporan Kegiatan	Laporan pelaksanaan kegiatan organisasi	2026-10-30 01:16:53.586	2026-10-30 01:16:53.586
kategori-dokumen-sertifikat	Sertifikat	Sertifikat dan piagam penghargaan	2026-10-30 01:16:53.592	2026-10-30 01:16:53.592
kategori-dokumen-dokumen-umum	Dokumen Umum	Dokumen organisasi lainnya	2026-10-30 01:16:53.596	2026-10-30 01:16:53.596
\.


--
-- Data for Name: kegiatan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kegiatan (id, scope_type, scope_id, nama, tipe, lokasi, tanggal_mulai, tanggal_selesai, created_by, status, created_at, updated_at, admin_kegiatan_id, pengajuan_nilai_oleh, pengajuan_nilai_at, updated_by_id) FROM stdin;
\.


--
-- Data for Name: kegiatan_peserta; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kegiatan_peserta (id, kegiatan_id, anggota_id, created_at) FROM stdin;
\.


--
-- Data for Name: kepengurusan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kepengurusan (id, user_id, jabatan_id, periode_id, nasional_id, distrik_id, wilayah_id, ranting_id, created_at, updated_at, parent_id, start_date, end_date, status, approved_by, approved_at, rejection_reason) FROM stdin;
\.


--
-- Data for Name: klaim; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.klaim (id, anggota_id, tipe, status, catatan, created_at, updated_at, version, nama_lengkap, jenis_kelamin, tempat_lahir, tanggal_lahir, alamat, no_hp, email, ranting_id, bukti_dokumen, approved_by, approved_at, tempat_dadar, tahun_dadar) FROM stdin;
\.


--
-- Data for Name: kta_app_histories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kta_app_histories (id, kta_application_id, level, action, actor_id, actor_role, catatan, is_skipped, skipped_reason, created_at) FROM stdin;
\.


--
-- Data for Name: kta_applications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kta_applications (id, anggota_id, nomor_anggota, status, biaya, rekening_tujuan, bukti_bayar_path, status_pembayaran, diterbitkan_oleh, diterbitkan_at, submitted_by_id, submitted_by_role, batch_id, catatan_admin, created_at, updated_at) FROM stdin;
3b754a1f-fbc7-429d-b447-a560606b4e3b	0d74d08b-4ea8-441d-a5e0-c5fcb3600e9d	\N	CARD_GENERATED	\N	\N	\N	BELUM_BAYAR	\N	\N	3970b5db-9f0f-4b63-b53f-86b8bf83301e	superadmin	1d2c588e-43f3-49e8-a454-bbd3d54010c4	\N	2026-11-16 01:28:46.347	2026-11-16 01:28:46.347
\.


--
-- Data for Name: kta_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kta_batches (id, name, submitted_by_id, submitted_by_role, scope_level, scope_id, total_submitted, total_approved, total_rejected, total_generated, status, created_at, updated_at) FROM stdin;
7fba8a87-e7e9-4b10-80ed-a34b8104ac57	Test Batch	3970b5db-9f0f-4b63-b53f-86b8bf83301e	superadmin	national	national	0	0	0	0	IN_PROGRESS	2026-11-15 14:20:33.783	2026-11-15 14:20:33.783
1d2c588e-43f3-49e8-a454-bbd3d54010c4	Test Batch	3970b5db-9f0f-4b63-b53f-86b8bf83301e	superadmin	national	national	0	0	0	0	IN_PROGRESS	2026-11-16 01:28:46.343	2026-11-16 01:28:46.343
c33fa22b-2467-4805-824d-8c5d8c2d3674	Test Batch	3970b5db-9f0f-4b63-b53f-86b8bf83301e	superadmin	national	36c321f4-7ba4-4abb-bcfc-88e744ac5138	0	0	0	-1	IN_PROGRESS	2026-11-16 01:32:18.502	2026-11-16 01:32:18.972
18b0cde4-c204-4126-93b0-9c751be36cda	Test Batch	3970b5db-9f0f-4b63-b53f-86b8bf83301e	superadmin	national	79b6b164-50f7-4eb9-ad05-be5327f5d991	0	0	0	-1	IN_PROGRESS	2026-11-16 01:46:16.033	2026-11-16 01:46:16.482
e8e5ea8c-d4e6-4537-bc15-922e39ff2b5c	Test Batch	3970b5db-9f0f-4b63-b53f-86b8bf83301e	superadmin	national	6219d2e2-c683-46f7-aafa-ad6fb690c66b	0	0	0	-1	IN_PROGRESS	2026-11-16 01:47:58.061	2026-11-16 01:47:58.395
\.


--
-- Data for Name: latihan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.latihan (id, ranting_id, kegiatan_id, pelatih_id, hari_tanggal, lokasi, jenis_materi, hasil_latihan_global, rekomendasi_latihan_berikutnya, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: materi_latihan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.materi_latihan (id, latihan_id, kategori, detail, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: member_referrals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_referrals (id, referrer_id, referred_id, status, "rewardPoints", created_at) FROM stdin;
\.


--
-- Data for Name: monitoring_alerts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.monitoring_alerts (id, name, metric, operator, threshold, duration, channels, telegram_bot_token, telegram_chat_id, email_recipients, cooldown, is_active, last_triggered_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nasional; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nasional (id, nama, kode, created_at, updated_at, is_visible) FROM stdin;
11c1a5ce-f597-4317-bf52-b6481b1e4a0e	Test Nasional	TESTN	2026-11-15 13:48:21.413	2026-11-15 13:48:21.413	t
6cfc26f5-448e-417f-b473-b261ae97537c	Test Nasional	TN1794750860495	2026-11-15 13:54:20.497	2026-11-15 13:54:20.497	t
748708af-7f84-4e78-861a-37d6dbc2347b	Test Nasional	TN1794751025406	2026-11-15 13:57:05.407	2026-11-15 13:57:05.407	t
ed5ce2bf-89b2-4c80-9439-b5d521676cb0	Test Nasional	TN1794751156807	2026-11-15 13:59:16.809	2026-11-15 13:59:16.809	t
fa0ee6c6-13ee-4fe3-8387-e3e6e41ac459	Test Nasional	TN1794752433513	2026-11-15 14:20:33.515	2026-11-15 14:20:33.515	t
a7943766-30bb-4eed-bb09-c64de2ce7dd4	Test Nasional	TN1794792526089	2026-11-16 01:28:46.09	2026-11-16 01:28:46.09	t
36c321f4-7ba4-4abb-bcfc-88e744ac5138	Test Nasional	TN1794792737618	2026-11-16 01:32:18.232	2026-11-16 01:32:18.232	t
79b6b164-50f7-4eb9-ad05-be5327f5d991	Test Nasional	TN1794793574689	2026-11-16 01:46:15.754	2026-11-16 01:46:15.754	t
6219d2e2-c683-46f7-aafa-ad6fb690c66b	Test Nasional	TN1794793677210	2026-11-16 01:47:57.798	2026-11-16 01:47:57.798	t
\.


--
-- Data for Name: national_holidays; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.national_holidays (id, date, name, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nilai_pendadaran; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nilai_pendadaran (id, kegiatan_id, calon_anggota_id, anggota_id, item_penilaian_id, penguji_user_id, skor, komentar, created_at, updated_at, ujian_praktek_id, status_validasi, divalidasi_oleh, divalidasi_at) FROM stdin;
\.


--
-- Data for Name: notifikasi; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifikasi (id, user_id, judul, isi, tipe, is_read, data, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_accounts (id, user_id, provider, provider_id, email, name, photo, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: organisasi; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organisasi (id, struktur, is_visible, updated_at) FROM stdin;
\.


--
-- Data for Name: payment_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_transactions (id, iuran_id, order_id, amount, status, payment_type, transaction_id, raw_response, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: penandatangans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.penandatangans (id, nama, jabatan, is_active, created_at, updated_at, distrik_id) FROM stdin;
\.


--
-- Data for Name: pendaftaran; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pendaftaran (id, nama_lengkap, jenis_kelamin, tempat_lahir, tanggal_lahir, alamat, no_hp, email, sumber_info, status, catatan, created_at, updated_at, ranting_id) FROM stdin;
\.


--
-- Data for Name: penugasan_penguji; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.penugasan_penguji (id, penguji_user_id, kegiatan_id, peran, catatan, created_at, updated_at, status, disetujui_oleh, disetujui_at) FROM stdin;
\.


--
-- Data for Name: periode; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.periode (id, nama, tgl_mulai, tgl_selesai, is_active, created_at, updated_at) FROM stdin;
47d10636-ebc5-42bd-b326-03c5b83b2666	2025-2028	2025-01-01 00:00:00	2028-12-31 00:00:00	t	2026-11-03 00:05:14.814	2026-11-03 00:05:14.814
3023da77-372f-41c3-859b-d4d0b8d7e787	2022-2025	2022-01-01 00:00:00	2025-12-31 00:00:00	f	2026-11-03 00:05:14.842	2026-11-03 00:05:14.842
\.


--
-- Data for Name: periode_aktif; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.periode_aktif (id, periode_id, level, unit_id, created_at) FROM stdin;
\.


--
-- Data for Name: peserta_pendadaran; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.peserta_pendadaran (id, kegiatan_id, calon_anggota_id, sumber, diusulkan_oleh, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: presensi_kegiatan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.presensi_kegiatan (id, kegiatan_id, anggota_id, hadir, created_at) FROM stdin;
\.


--
-- Data for Name: qr_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.qr_codes (id, anggota_id, token, type, is_active, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: qr_scan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.qr_scan (id, qr_validation_id, scanned_at, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: qr_validation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.qr_validation (id, dokumen_id, token, is_valid, scanned_at, scan_count, created_at, reason, source, verification_url) FROM stdin;
efc1f3bb-b0c0-4167-b4f0-5bfa53516a00	268bc75d-4166-46e1-899c-d7e7e564e33f	dummy-token	t	\N	0	2026-11-16 01:28:46.359	\N	digital	\N
5af9bee3-6503-4f86-b4ad-edab568e6c3f	5ad08b30-45e9-4731-8bab-8e10a925b3e7	QR-1794792737618	f	\N	0	2026-11-16 01:32:18.52	\N	digital	\N
b1c72550-7440-40d0-890f-5e0e30c9956a	3516f104-7729-469e-aa2e-53a47975b312	QR-1794793574689	f	\N	0	2026-11-16 01:46:16.048	\N	digital	\N
ada27cdb-b124-4731-bdd5-699cf73fd6b2	cc984dfe-5c6b-4a75-957a-3b3e57941b50	QR-1794793677210	f	\N	0	2026-11-16 01:47:58.077	\N	digital	\N
\.


--
-- Data for Name: queue_uptime_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.queue_uptime_events (id, start_time, end_time, duration_ms, notes, component, created_at, updated_at, approved_at, approved_by, rejection_reason, status) FROM stdin;
\.


--
-- Data for Name: ranting; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ranting (id, wilayah_id, kode_ranting, nama, lokasi_latihan, created_at, updated_at, is_visible) FROM stdin;
d384f0cd-b68f-4b62-bffa-a46d111be5c6	546ae91f-b802-4c6c-89e8-39dfcf969de6	TSTR	Test Ranting	\N	2026-11-15 13:48:21.432	2026-11-15 13:48:21.432	t
e1214623-1776-460b-a931-4bf8ff03da30	064816de-d9dd-4900-9f62-24a3d609b486	TR1794750860495	Test Ranting	\N	2026-11-15 13:54:20.51	2026-11-15 13:54:20.51	t
94d68aba-88f8-4d76-aff9-d698fc5a2ffb	73aed166-2212-4b5d-97ea-2d3f499c8d47	TR1794751025406	Test Ranting	\N	2026-11-15 13:57:05.424	2026-11-15 13:57:05.424	t
e9bdaa44-1839-4302-8113-b605a1b95bdb	20867e19-fb3b-4652-b207-21d0af0b4650	TR1794751156807	Test Ranting	\N	2026-11-15 13:59:16.822	2026-11-15 13:59:16.822	t
e19d1986-f576-4680-9609-7f01fe597e6b	457d7b94-3274-41fa-b5fd-e0c6f8afc533	TR1794752433513	Test Ranting	\N	2026-11-15 14:20:33.532	2026-11-15 14:20:33.532	t
d778828d-0752-4e88-8254-28459a8485d0	33cf071e-880e-4467-b364-0d7b3c0aaf9d	TR1794792526089	Test Ranting	\N	2026-11-16 01:28:46.103	2026-11-16 01:28:46.103	t
7cb72afc-51a5-4f17-829e-326211117a65	36afc707-48bb-480c-b101-f20c0b6df0d5	TR1794792737618	Test Ranting	\N	2026-11-16 01:32:18.251	2026-11-16 01:32:18.251	t
57b3d03a-2d7a-4d76-ada9-3547ed8c062e	affab757-bcd2-45db-b753-9c2876aa3d39	TR1794793574689	Test Ranting	\N	2026-11-16 01:46:15.775	2026-11-16 01:46:15.775	t
5f820086-10bd-4c14-8fd7-87ee2164cd43	88c795c9-4bb0-423c-be5c-eaa2356be8f5	TR1794793677210	Test Ranting	\N	2026-11-16 01:47:57.814	2026-11-16 01:47:57.814	t
\.


--
-- Data for Name: risk_flags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.risk_flags (id, anggota_id, "riskType", score, factors, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: role_menu_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_menu_permissions (id, role, menu_key, is_enabled, created_at, updated_at) FROM stdin;
8180b48f-d837-4d92-a965-72247b9dda3c	superadmin	galeriUpload	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
07fd3a8c-743d-4c69-b8f5-6edd71188c43	admin_nasional	galeriUpload	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
2cbcaa92-21e0-4bec-9fe2-726b1694c7fa	admin_distrik	galeriUpload	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
2ec1b14d-0bca-476b-ab78-48bb88ccd902	admin_wilayah	galeriUpload	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
e2e78802-02f6-449a-8199-035979653df6	admin_ranting	galeriUpload	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
80c01746-cd97-403d-b6c3-8d2ae0db3682	admin_kegiatan	galeriUpload	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
3aacf85b-4170-4da5-b234-3866ebf3bc88	penguji	galeriUpload	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
eb604fcd-1bdf-474f-81ee-350921244206	anggota	galeriUpload	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
88488ffa-6bee-4aec-aea4-7c04cfc53739	superadmin	galeriManage	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
d425863d-40e2-47f7-aefe-c189b6a24cb1	admin_nasional	galeriManage	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
4d76e9fa-b2ce-4baf-a325-a91704d80c76	admin_distrik	galeriManage	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
bea8cff1-020e-431d-b576-f72330bac591	admin_wilayah	galeriManage	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
91446210-3e90-4120-8d13-12ac466b1972	admin_ranting	galeriManage	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
349bfbcc-6ae1-4a8b-929f-5f9d79528477	admin_kegiatan	galeriManage	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
17a859fa-bdab-4df9-8215-63bba812ff9a	penguji	galeriManage	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
e6fb1621-2960-4b30-8d75-9f1d78194ca6	anggota	galeriManage	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
6e82bf4e-06e2-40ad-aac3-a446c79ae8b7	superadmin	dashboard	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
f4ddc94c-1ef7-4fb1-80ef-6f6ce956001b	admin_nasional	dashboard	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
6ad92bbb-f985-42c4-9685-a1b8f733c5f7	admin_distrik	dashboard	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
ea39f839-8305-4897-8883-82705d488370	admin_wilayah	dashboard	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
a34adc60-efea-4b9c-9d8f-85c03bce78b1	admin_ranting	dashboard	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
5562243c-87b3-4b8d-ab2b-3d96838ec2e6	admin_kegiatan	dashboard	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
a54f0c3a-3ecf-413e-a8f2-e646f4540f28	penguji	dashboard	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
e3b68b3f-8378-4590-801d-778c1bd16ac8	anggota	dashboard	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
1ea5f32f-71d3-4645-9047-1b789975a7e2	superadmin	activities	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
58b4fcae-953c-48d1-aaa5-ac3ece73f44d	admin_nasional	activities	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
b67c0f82-48cb-42a8-9255-38e09ffe2f65	admin_distrik	activities	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
fd507be2-244f-405b-b88f-70f6a77c52d5	admin_wilayah	activities	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
fc7618a7-36aa-4254-a738-aa6ec5696e9b	admin_ranting	activities	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
6613b20c-3b8b-4708-9cb3-92d5b0b5c598	admin_kegiatan	activities	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
2fa8e167-f725-4e6c-b4ab-ed8a9f8b0556	penguji	activities	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
b3758485-76ea-433f-8d75-601d3d0923a1	anggota	activities	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
41984692-d655-4aca-9d8a-511a16b6dcb5	superadmin	calendar	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
c045f994-2a3a-4739-9513-072ee986bb42	admin_nasional	calendar	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
9d0e432d-dce0-4399-96f0-a8a46e72d5f8	admin_distrik	calendar	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
02d286f3-9847-48c8-ad66-0a0056df49b6	admin_wilayah	calendar	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
fa6ea2f7-231f-4db4-ad50-198aa1186c0c	admin_ranting	calendar	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
a298abe2-8107-4ac8-9a31-e61236bb1a83	admin_kegiatan	calendar	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
fdd7b705-80e9-405f-af19-080ac7f6748a	penguji	calendar	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
87b147b6-602a-4b87-bf0b-4b6ad073eec8	anggota	calendar	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
c3ef2d8f-2dc7-45f5-a138-a5481d3435be	superadmin	forum	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
ae5eeb88-70fc-4bf1-af28-f656fc873483	admin_nasional	forum	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
efa33f08-8c36-4e5e-bf27-3834af4fdc63	admin_distrik	forum	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
56966164-6461-41c3-97ad-3bfe8506988c	admin_wilayah	forum	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
ca1609ca-e719-4cd3-9136-47e41eca2bd3	admin_ranting	forum	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
c907cf8d-dc3f-45b7-8c5c-b32a67871ce2	admin_kegiatan	forum	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
006f6aa5-ec9d-4593-80b9-d3f5ff3d3128	penguji	forum	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
2deec7ba-415e-4c07-99d6-91f6398f03e5	anggota	forum	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
629923c4-012f-4013-a786-92ff380d0825	superadmin	notifications	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
8e0ddae7-decc-40f6-8c71-2b2960524bbe	admin_nasional	notifications	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
2cc512f5-b094-4801-9df8-2562f5b5f103	admin_distrik	notifications	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
c97853ca-d055-4b8d-b0fb-d9afcfb9e993	admin_wilayah	notifications	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
2248bbe9-a978-46ba-b47f-781d60681a3c	admin_ranting	notifications	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
106340fc-7e76-4ac1-beae-43ac78e87083	admin_kegiatan	notifications	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
9ea6aa00-15d8-4220-872a-866740e2ae0d	penguji	notifications	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
6e138bd7-7067-449f-8adf-09689a9441fa	anggota	notifications	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
b820234f-e182-4426-8bf3-0e42e99276a7	superadmin	orgChart	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
b533255f-3d72-497e-8700-873b64eaa25f	admin_nasional	orgChart	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
b2212bc4-1a6c-43bd-ab6f-8eb6455a3626	admin_distrik	orgChart	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
7b49bc8e-ae54-4741-b1bb-3fed57837473	admin_wilayah	orgChart	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
b49f16e9-d7cb-4692-bb65-165c292a57d6	admin_ranting	orgChart	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
620f4108-d1c6-4902-b6be-abe48fb4ea81	admin_kegiatan	orgChart	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
7dcadb57-1db8-4e3e-baba-ebd3a9fad775	penguji	orgChart	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
554bf43b-5e22-47a5-a9fe-814dffcaa2d5	anggota	orgChart	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
5bd76de1-3f78-48d9-876b-26690b3d7598	superadmin	documents	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
34d57074-15cd-46d9-9458-56b41224e145	admin_nasional	documents	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
33b66f8c-9538-4908-9917-f593010290c3	admin_distrik	documents	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
498eaedc-d77a-4b4a-a46f-fc7dcf1de7eb	admin_wilayah	documents	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
b71837b4-fb39-46ec-a11a-d8681ede692f	admin_ranting	documents	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
49fdb91b-2ea2-4697-90dd-3413f338fe15	admin_kegiatan	documents	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
8264eb60-26de-4a30-81bf-7f253d09a08e	penguji	documents	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
bab52bff-8c3e-4dd3-8b90-10bd3260e972	anggota	documents	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
59360d22-b30a-4b43-a29a-0095220f5075	superadmin	dues	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
0c8b8ffb-a622-45db-ba87-2b00e3a8d9c5	admin_nasional	dues	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
8cd84c6f-e0f5-410c-b8f6-2166813241b3	admin_distrik	dues	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
701be7f4-fb65-4414-ae35-5af28a9c6b6b	admin_wilayah	dues	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
b013c402-1dcb-4263-b122-93b4689467b1	admin_ranting	dues	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
ff84ff4a-c660-4ae5-8d90-e39302397347	admin_kegiatan	dues	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
efd6c2eb-f43b-4500-b3b2-eac294e45861	penguji	dues	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
1562d2d1-0ab9-4672-9f2f-d52cfb7f440d	anggota	dues	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
17a9754a-7596-4d76-9f04-152b7a30f461	superadmin	contentBerita	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
847c0cd0-40b0-4b26-a7ba-1972510dfc30	admin_nasional	contentBerita	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
d7b1cb4b-525e-45d9-857e-5743f0532d6b	admin_distrik	contentBerita	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
c8174531-da7c-406d-ae4b-887163e3b3b9	admin_wilayah	contentBerita	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
287c961c-ba1e-4d7c-9dfa-185d31e8c430	admin_ranting	contentBerita	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
a564ceb8-a367-476b-b8f0-4a9755f08f4d	admin_kegiatan	contentBerita	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
f96a8c6c-6ba7-4add-b4c4-3ac51fcdbb8d	penguji	contentBerita	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
d63d3852-0cb6-4d46-81d2-79bf77d6aa54	anggota	contentBerita	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
a08ac66a-cb42-4f09-9553-1a5a42db5a14	superadmin	reports	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
7301fbb6-4ab7-4120-bec6-34fb1f2c094c	admin_nasional	reports	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
4126be21-95d9-45e6-be19-cda1dc09e8e6	admin_distrik	reports	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
9ddb5795-4a6b-45da-b2d0-b711764d10e9	admin_wilayah	reports	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
3781e05b-563e-4436-b774-99c1bc97dd5f	admin_ranting	reports	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
7b982038-fa7b-496c-b89d-7c4f122cd9da	admin_kegiatan	reports	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
d153b47f-e8d0-401d-b1d7-7975fbc2d645	penguji	reports	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
42820634-54f5-472c-a284-b1cb0d1a7534	anggota	reports	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
aeb2c695-8f0f-44e4-9096-8b4b3a67a4c8	superadmin	members	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
e071308f-692a-4af4-963a-7b6ad3af28ac	admin_nasional	members	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
3d002267-7e90-4869-aa89-f7f4e9acf5dc	admin_distrik	members	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
8d7c1fd7-fd32-43de-9838-5fede315e4ee	admin_wilayah	members	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
59a8fefb-de59-48b1-b4d7-1d3371ae8145	admin_ranting	members	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
6dcf463c-1e69-4478-afb1-dd9acdc0dbab	admin_kegiatan	members	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
d5362ea3-1bb3-4960-8f52-988e83a2f70b	penguji	members	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
21bc806f-c1f3-42ea-810d-ff25bde8f3ab	anggota	members	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
81188b7e-6965-43ee-9a42-58c7e81c0027	superadmin	membersMutasi	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
1ebdc0c7-e712-4b00-a866-a4ab69a7949f	admin_nasional	membersMutasi	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
cebe0342-b795-4c98-b1f3-fdf4918ace3a	admin_distrik	membersMutasi	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
0cd729ef-e700-4efc-ba4a-173cb557d611	admin_wilayah	membersMutasi	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
63254cb3-361b-4e19-978c-78131d19d004	admin_ranting	membersMutasi	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
4f8f90fd-c6b9-467f-a731-252ea5797552	admin_kegiatan	membersMutasi	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
cf0abc78-9540-44a7-b47c-3835ad36f906	penguji	membersMutasi	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
48fce0d1-f3ae-4a1c-b730-2d88c5c8809d	anggota	membersMutasi	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
5ceb3955-4494-42d9-805b-094bbaa436e1	superadmin	candidates	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
36a83d0a-ff0e-42d8-82ff-2dff872e7435	admin_nasional	candidates	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
391b30c9-5729-42a9-8753-1cef808826c5	admin_distrik	candidates	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
5168d17a-83d1-497b-a8ce-dbfcd51a5a68	admin_wilayah	candidates	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
f14aa83d-920e-4d0d-87cd-f6aa56eadd8c	admin_ranting	candidates	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
47df4b78-c9e3-45c8-8ef9-a6c1fdc1ae32	admin_kegiatan	candidates	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
9fb42558-b1ea-4dba-81fb-c4599d102f76	penguji	candidates	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
d5e995bb-68c6-47b5-aed7-cd52b6be0348	anggota	candidates	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
8317f522-bfe6-4243-8aee-964c132bfb3d	superadmin	registrations	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
04d76781-142c-4a51-9207-21999ae7e9d5	admin_nasional	registrations	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
276e6876-bd7e-485f-9a80-4628227a43cb	admin_distrik	registrations	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
d1a99496-91f0-4e1f-b325-1a4fb4cbdbae	admin_wilayah	registrations	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
16f76f85-44e0-460c-93cb-ca0a7fb94fde	admin_ranting	registrations	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
552237b7-1158-4b51-af70-870e0356bfbd	admin_kegiatan	registrations	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
e8424cb4-d828-4acd-801e-7e4fbbec5fcb	penguji	registrations	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
24f6e4b5-73bf-4a9e-b533-1ed0827ac705	anggota	registrations	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
c2ec8c90-8bbe-4197-a231-237243857591	superadmin	claims	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
636f7715-7f45-4d0a-bc89-107bcc4d32ed	admin_nasional	claims	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
a17ee929-6470-45a9-b16c-6f21e7fb1781	admin_distrik	claims	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
a36bc686-2ffb-4165-9db7-b39e20aba9de	admin_wilayah	claims	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
453a7552-d47f-444e-8e44-62f520ebdff2	admin_ranting	claims	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
fa3c8b51-8c01-4e93-b5f6-652fd44c9e74	admin_kegiatan	claims	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
4c03fa2c-071f-4c39-9df7-ca06e7e7dfdb	penguji	claims	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
0f1a7ae9-a59d-40f9-95c0-8b5e308e094e	anggota	claims	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
3892fc59-25d7-4911-be39-f59591414d96	superadmin	letters	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
99b005c6-c8fd-4f56-8145-d0fc39b79f80	admin_nasional	letters	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
703f34b3-ade6-42f2-b569-20e216f33ba4	admin_distrik	letters	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
14e78d11-11e3-4f11-82bf-633665a091df	admin_wilayah	letters	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
f9fab309-aa5d-469b-a33a-bdfec7bb7122	admin_ranting	letters	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
f7b71c97-773f-431d-a4e6-c9fa77982a4a	admin_kegiatan	letters	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
def8a41b-1a9c-4a3e-915f-e37f5a96c096	penguji	letters	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
9d2fb519-28e1-4d6a-a4e5-9c6d7a5c954a	anggota	letters	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
9675ec8c-5741-4e3a-a9ef-de91a5514d2a	superadmin	trainings	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
01464a1b-26fd-43a2-b8d4-6afc5038f6f3	admin_nasional	trainings	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
e7bf2be4-b9db-4bd4-95c1-1203cc977d30	admin_distrik	trainings	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
26518b95-5c1a-4b7b-9a7d-3d10f32bf2f0	admin_wilayah	trainings	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
5e0077fa-10af-4fdb-aaa9-9db7de5b7daf	admin_ranting	trainings	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
2c0ab72c-9e43-483b-8286-0e1de1bf30ad	admin_kegiatan	trainings	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
fd70bd17-86be-4c45-b8b0-547c897c3b87	penguji	trainings	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
4039bd2a-1e54-4317-81da-5861788f21f2	anggota	trainings	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
b1f40b5b-1ea5-439a-a22e-0c9bad1933a7	superadmin	graduations	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
2a916b8d-c7c2-4827-b345-febbfa0a93d8	admin_nasional	graduations	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
0b694891-0da1-4866-94a5-8cc074f451a5	admin_distrik	graduations	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
f9c635af-1d16-4e0a-a620-ba0cfa958c2b	admin_wilayah	graduations	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
9cf5a28f-9d23-4b4d-a60a-bbff74605b8a	admin_ranting	graduations	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
c2e4350e-40fb-40a3-9485-8ead8933e399	admin_kegiatan	graduations	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
d13ca40f-8426-4d3b-b36b-2ae0a263d99b	penguji	graduations	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
ee64d2da-5e44-40a4-9b49-93ff1db865f4	anggota	graduations	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
29b8d1f8-45e0-4f6e-8a04-0109816131c9	superadmin	examiners	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
ae9b6f26-61b7-465d-a255-9644cb52ce0c	admin_nasional	examiners	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
3a444569-4cfd-4cf7-bd17-5cf8e6c636e5	admin_distrik	examiners	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
ad81c9f5-0961-4ab9-a6fc-bd7a14d6e291	admin_wilayah	examiners	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
672d6394-79ca-4b22-920a-bcf7d515a3d2	admin_ranting	examiners	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
34a89d1d-c05a-49a3-b43f-c76e80b923ba	admin_kegiatan	examiners	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
69c4c053-eb1a-4e2f-9017-7fcdab7f8c06	penguji	examiners	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
339a9709-dffb-4a32-96f1-679c969e88e0	anggota	examiners	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
d9866fb3-2a77-4cc8-8738-72fbda15b59c	superadmin	assessments	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
cf7cef07-5b7c-4fd0-8398-97bc556d0e68	admin_nasional	assessments	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
3f4e8bcd-c63c-44c4-8926-85199c524fb2	admin_distrik	assessments	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
fe9d0d1a-1196-482f-aca4-1c3431263be8	admin_wilayah	assessments	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
6e642a04-01ec-4cc7-8872-d33852e4ec3f	admin_ranting	assessments	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
01d29d07-c4f5-44c8-9332-c9366aabfc4c	admin_kegiatan	assessments	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
c44732ad-919e-4bf0-805b-b33f8ad99937	penguji	assessments	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
efa4f0ef-5081-467f-8fd7-898d42182d54	anggota	assessments	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
3757e711-0343-4085-b8f0-077c4a54a7f0	superadmin	approvals	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
75a27672-63a1-4e01-8e82-1eec82cb5981	admin_nasional	approvals	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
0a62a80c-2ea6-40d5-9033-32bdfa4ccdfc	admin_distrik	approvals	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
68e90e2c-e434-4877-9059-ecc2fb2ce384	admin_wilayah	approvals	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
d271b0d3-6f7c-4272-91d8-a3ae3ea32000	admin_ranting	approvals	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
1f033ba1-ec6d-41a3-b79b-d91f31fca145	admin_kegiatan	approvals	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
869166b5-11e6-4600-abdd-d3594f7c2113	penguji	approvals	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
fd858660-ae2c-419e-8b9a-8cf33a643ff0	anggota	approvals	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
0687dfe2-96b8-4fee-87bc-eabccf5ff8d7	superadmin	orgDocuments	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
587e6a6d-da22-4778-ac4b-edc55dbb783b	admin_nasional	orgDocuments	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
5dec29b1-5280-479c-b1bc-0d0376908011	admin_distrik	orgDocuments	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
343058b5-432e-46d6-bb03-47a83d7d8240	admin_wilayah	orgDocuments	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
c9090abc-ced7-4f7c-bcd8-c23caf7f88b9	admin_ranting	orgDocuments	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
6a363a9a-e07c-45e8-96a4-95f9898240b2	admin_kegiatan	orgDocuments	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
17f796ca-58c8-4a0b-b8ca-0ebcf9e2c20b	penguji	orgDocuments	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
fae97df2-f28e-4f30-b1d4-93fe33a46f58	anggota	orgDocuments	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
daff4f26-e1fa-4421-9c93-c66eb85c578a	superadmin	settingsJabatan	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
3c527670-c118-489f-9bf7-8691c1bb2268	admin_nasional	settingsJabatan	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
c28132e2-a152-4ebf-8dfd-2417f2867ee5	admin_distrik	settingsJabatan	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
5517a972-8c45-4552-a2ad-05e4d78b3f88	admin_wilayah	settingsJabatan	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
fce2cf99-5b15-4f01-85f4-f68fc8b6c548	admin_ranting	settingsJabatan	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
e140edfa-b6b8-4ae3-90c5-1f787deabff6	admin_kegiatan	settingsJabatan	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
eaf9a378-1af2-4806-80f6-6ad528153df0	penguji	settingsJabatan	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
3c1157eb-0ab5-4b4c-8130-95f89f007a9f	anggota	settingsJabatan	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
6545326f-ff2c-4d6e-88de-be693dbcef36	superadmin	settingsPeriode	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
cca70477-4241-47ff-a98c-0af1964454c3	admin_nasional	settingsPeriode	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
c8d43982-4e07-4cef-a4c5-7626c5bd46e8	admin_distrik	settingsPeriode	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
5f8af2d2-7ef1-47b3-9ab2-b8200d6a9b9b	admin_wilayah	settingsPeriode	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
48fe4bd2-808b-4f7f-9cfe-f478e3da196d	admin_ranting	settingsPeriode	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
521afafc-b9d1-4aca-93a9-95537f25de80	admin_kegiatan	settingsPeriode	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
2e81025f-a343-4919-9abd-c757baf9549f	penguji	settingsPeriode	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
e249e252-3564-4516-9518-61cbaf5c86d5	anggota	settingsPeriode	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
3b3636b9-a91b-4641-91e2-2f9c0797b511	superadmin	settingsKepengurusan	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
a86c4f96-f96f-4888-ab03-de9b260ffaa4	admin_nasional	settingsKepengurusan	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
3d0f0a06-259a-444d-ae51-b0d750412d7d	admin_distrik	settingsKepengurusan	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
409211b1-3b9a-47d7-b65a-64095e4d753e	admin_wilayah	settingsKepengurusan	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
8d839ce4-3687-4cf9-a6f4-28c2c7d39bbc	admin_ranting	settingsKepengurusan	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
fa6ae8e2-033b-4771-b5fe-b5037b0a9d05	admin_kegiatan	settingsKepengurusan	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
88aa4cac-0e00-4452-951f-8a8e975fbba9	penguji	settingsKepengurusan	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
a7503847-098a-408b-8f00-591325c21e2c	anggota	settingsKepengurusan	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
005af092-fb17-4db0-b3a9-3fc707ad694d	superadmin	settingsOrgChartEditor	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
ff935acb-d651-4406-a4f7-a86b32587033	admin_nasional	settingsOrgChartEditor	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
1f333bcf-c252-460b-965f-685be2a2c1d7	admin_distrik	settingsOrgChartEditor	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
5b7ec0aa-babe-40d6-b63b-c4084b472e54	admin_wilayah	settingsOrgChartEditor	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
36a5117e-06ca-4a16-b0d7-157d54b6d358	admin_ranting	settingsOrgChartEditor	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
8570f8bf-c717-4636-9e62-1206468028b7	admin_kegiatan	settingsOrgChartEditor	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
deff1921-a89b-4e06-b517-a2487984e077	penguji	settingsOrgChartEditor	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
bb9298d7-819a-49b0-bf9b-87ce80612dbd	anggota	settingsOrgChartEditor	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
317504c8-58e6-489a-b46b-eb61afd95508	superadmin	payments	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
1ede0bb8-a2ae-4c8d-8e71-35f6c22440cb	admin_nasional	payments	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
205fa24d-6275-4898-877b-7b4b7695d22c	admin_distrik	payments	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
4d36e36f-be74-4ba7-8179-ddad102c7ecf	admin_wilayah	payments	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
037ff664-d49a-447e-9bfc-59f625d07c04	admin_ranting	payments	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
7f887058-3781-431c-94f5-6227f05786ba	admin_kegiatan	payments	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
b926c2b1-29b6-40ad-b0e8-96a4098866ff	penguji	payments	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
4503b191-5113-4f0b-8955-fb1ef8cefcb5	anggota	payments	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
69b86f0a-029f-4344-8d38-252fc7f3316b	superadmin	users	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
3e4250f8-8bec-41a7-8cee-f2d05932d407	admin_nasional	users	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
bd8b2b41-e073-4f75-b8ae-0fccda50ab1a	admin_distrik	users	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
a0555ad9-b425-474f-ae53-dec65d4dd248	admin_wilayah	users	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
910c51e6-92e8-421f-a6a1-8b5c25c5d743	admin_ranting	users	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
9aad3d13-f5c7-4b72-a93a-605196245411	admin_kegiatan	users	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
acc8f148-eba5-4ddc-92bf-5e526c8c9d1c	penguji	users	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
d62aa062-3d42-4faf-b23e-d20c81a91140	anggota	users	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
2629d517-acfa-460f-b05a-f460d864a013	superadmin	monitoring	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
34db75f4-21eb-4e76-bbc9-1baab2c80f79	admin_nasional	monitoring	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
087cfbad-128f-4049-81cc-17049da2edc8	admin_distrik	monitoring	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
828fcb37-1a09-4189-9728-3b49fb284c7b	admin_wilayah	monitoring	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
3432af41-3840-4bd9-b817-65241835e0f7	admin_ranting	monitoring	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
0d182738-862b-4cf0-8207-0681d0e8f81c	admin_kegiatan	monitoring	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
643db6be-f372-42ce-b2ff-0a77e3711964	penguji	monitoring	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
d726b8c1-be9e-4118-acc0-aa92af3f374c	anggota	monitoring	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
31b96af8-b974-4275-9eae-e58b5d451dee	superadmin	monitoringAlerts	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
966ce6ef-f131-4355-9077-65bd1364efce	admin_nasional	monitoringAlerts	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
927f1e51-b658-4055-90af-afb9f6be9bd7	admin_distrik	monitoringAlerts	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
95d20e8c-03a0-4c9b-b419-29715417d0b9	admin_wilayah	monitoringAlerts	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
df43d209-e797-44f6-80de-d0e19cee53d9	admin_ranting	monitoringAlerts	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
9f2ef7fc-79b8-4922-ac47-e5848eeac56b	admin_kegiatan	monitoringAlerts	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
2dcd43cb-6b0a-4f46-a9f8-8dad6f1cfeca	penguji	monitoringAlerts	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
b8a41144-d761-4671-a94a-4985aad0ac5c	anggota	monitoringAlerts	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
a02431d7-0ceb-4b49-9249-a265a11b33ea	superadmin	monitoringIncidents	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
60483894-e313-4960-8640-981da71bbb11	admin_nasional	monitoringIncidents	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
d94c1270-0487-4b48-97ca-ea208c6978d5	admin_distrik	monitoringIncidents	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
de461133-a15f-45a0-aaea-cd83ff09011b	admin_wilayah	monitoringIncidents	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
f69cf575-d844-4a17-b089-626a556b3fde	admin_ranting	monitoringIncidents	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
4874afaf-e82b-4676-816c-159a8b9cc74f	admin_kegiatan	monitoringIncidents	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
8206a6d3-8e3c-437d-90e1-361f586dea58	penguji	monitoringIncidents	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
6ab226da-e97e-49a8-a5a5-c0a3d8b35564	anggota	monitoringIncidents	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
9b6c2709-9e47-4b77-a8f8-0c7b794d3ddb	superadmin	wsMonitor	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
67f1a5ca-a874-40fe-8fca-29f57c45cbb9	admin_nasional	wsMonitor	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
ac0e1083-2f0e-4ca5-9ec6-3dadd8de138a	admin_distrik	wsMonitor	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
41c12756-8f89-424d-b218-23b57a0da511	admin_wilayah	wsMonitor	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
8b440ff7-a489-4752-b21e-3d9effecf081	admin_ranting	wsMonitor	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
75b696ca-30c6-460f-93af-55246a74d75e	admin_kegiatan	wsMonitor	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
a1ec7d1e-e4ff-49c2-8a84-f52da4c4e26a	penguji	wsMonitor	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
40af34fe-e082-41f5-9e97-7261937f6ce5	anggota	wsMonitor	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
3cffc8c9-5b59-40a1-a282-1fde7e0ca679	superadmin	adminQueues	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
71ab050c-9d20-4cdb-920f-1eb6a070639b	admin_nasional	adminQueues	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
e3288b05-06b9-4840-95ea-c0b8534f9534	admin_distrik	adminQueues	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
86dabd6a-c7c5-451d-a9a5-ae6dcc45c08e	admin_wilayah	adminQueues	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
a648b771-9120-4306-ae0e-18d2a458a1fa	admin_ranting	adminQueues	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
c232853d-4bfb-48ba-bfe9-617ef3b647c8	admin_kegiatan	adminQueues	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
a48d2744-a4e3-447e-91a5-38ebfa45429c	penguji	adminQueues	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
8f922010-f715-4911-be7f-20bf76b98dc9	anggota	adminQueues	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
1a8c272c-f96f-4d27-a3d5-87a11a535bf0	superadmin	settings	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
bcb7da6d-af98-4277-935a-eb187c88b968	admin_nasional	settings	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
f64f06ef-d1e5-4696-ad70-72b3587c00e8	admin_distrik	settings	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
63627960-489b-4c85-a923-b485837c1012	admin_wilayah	settings	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
a6c6cb0d-a51d-45bb-88c2-b51b3b196be5	admin_ranting	settings	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
b99089f7-4a3f-43d8-9c2b-846a3e44868e	admin_kegiatan	settings	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
a150f6c0-638a-4700-89e0-ba52e0f0b477	penguji	settings	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
ceea5364-2791-4f6d-8513-886747db369e	anggota	settings	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
62bf75ca-64b7-4583-82e7-a5e7dda35a58	superadmin	settingsMenuPermissions	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
89b59ed7-6feb-4da1-81f4-afa101e8fc4b	admin_nasional	settingsMenuPermissions	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
d775d638-c25f-4aa1-b12b-945a712dba61	admin_distrik	settingsMenuPermissions	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
aff9ee76-2094-4b73-91d4-74d6d1e8de19	admin_wilayah	settingsMenuPermissions	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
b4964055-9f9c-45c8-8c5f-59eb4aebd72f	admin_ranting	settingsMenuPermissions	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
cea9ce15-de2a-40ca-8448-e503d76e661f	admin_kegiatan	settingsMenuPermissions	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
f9d32ccf-7629-4dd7-834a-40253806853e	penguji	settingsMenuPermissions	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
d461a6ed-5cf3-43d9-bf21-eae6c4376c62	anggota	settingsMenuPermissions	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
31d4997d-518e-4b83-8f49-62a50f8d1796	superadmin	settingsEmail	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
4cbfc6bb-75c6-4919-9eca-852538cc8113	admin_nasional	settingsEmail	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
53685661-f49b-4115-a393-7a8f7be6bac5	admin_distrik	settingsEmail	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
65098fd4-1e83-49fa-b3f7-4f01401d896f	admin_wilayah	settingsEmail	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
8fa811ce-2655-425a-a1e8-bd9415736dbc	admin_ranting	settingsEmail	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
8e217c1f-c513-4336-83af-75e460d407af	admin_kegiatan	settingsEmail	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
6c30c811-80a5-4245-be6d-158fedbfb7f8	penguji	settingsEmail	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
7aefda97-7622-4bcb-9276-b53cd290601e	anggota	settingsEmail	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
7013ae24-9e19-4e97-bc75-3866ff2b7bd6	superadmin	settingsEmailLogs	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
16b6f105-690e-4258-85da-443f436fa4c2	admin_nasional	settingsEmailLogs	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
25dca5d2-bedb-4854-bfc3-177e08c6370b	admin_distrik	settingsEmailLogs	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
5b0889d7-981f-4052-984d-4d5db73d929a	admin_wilayah	settingsEmailLogs	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
edd616b1-0050-4587-a1ad-0150f4be16df	admin_ranting	settingsEmailLogs	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
5978d09c-6422-4b7a-969d-2c2aaa8abe15	admin_kegiatan	settingsEmailLogs	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
10b919d3-f526-45be-a9a9-f1b29ce9bd94	penguji	settingsEmailLogs	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
ceb4685c-e884-4475-b67b-5eaaf2c7630b	anggota	settingsEmailLogs	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
dd44fb6e-f95f-46c7-9b45-8445b3ac93ca	superadmin	settingsPenandatangan	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
3e8a5c2b-5b92-4500-b06d-06326512bb19	admin_nasional	settingsPenandatangan	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
58aa1836-adc9-46d5-9c19-3274d3d96849	admin_distrik	settingsPenandatangan	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
a0d0ae06-1e7d-4582-ac54-cf63e284bff5	admin_wilayah	settingsPenandatangan	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
94a1d0b5-18dd-40b1-b3a8-28b87fa96b5f	admin_ranting	settingsPenandatangan	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
e7cb85fa-615b-44ec-a276-5872e533228b	admin_kegiatan	settingsPenandatangan	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
9ccd0055-de7d-48e1-a40d-88e7531385c3	penguji	settingsPenandatangan	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
9960aace-e6da-43bf-872e-7cc171ac192c	anggota	settingsPenandatangan	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
9d77392e-db0b-4926-921f-2e97d9ecf4e4	superadmin	settingsKartu	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
9bb02e52-ecef-4418-978c-23b87d5fc6c0	admin_nasional	settingsKartu	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
98c701a8-921e-4e78-8d3e-b199fc7d28a6	admin_distrik	settingsKartu	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
52254b21-258d-44b2-963a-2f9bd4d74de8	admin_wilayah	settingsKartu	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
b9422985-4dcd-4e18-9464-5d03b950f217	admin_ranting	settingsKartu	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
3e131728-3f1a-4d4a-9195-7d42649c70e1	admin_kegiatan	settingsKartu	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
29e09a14-2b1b-40c8-a7a4-80e32664cf90	penguji	settingsKartu	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
e85c2585-cd7f-4757-bbd5-d3001c349b11	anggota	settingsKartu	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
9db2d220-046b-4c60-bc6b-ef60efc2bb76	superadmin	settingsDokumen	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
7e5f4057-a7d2-4ab8-bc03-e629d322ade2	admin_nasional	settingsDokumen	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
340f5c57-6043-4318-9d7a-9327498c1a8b	admin_distrik	settingsDokumen	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
040631d9-dc04-4d72-9ee4-8d42f8e27941	admin_wilayah	settingsDokumen	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
a722442d-cd20-476c-b4c4-1dfcf038346c	admin_ranting	settingsDokumen	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
75906f94-72ca-46b4-95d1-d67ac26c4c7b	admin_kegiatan	settingsDokumen	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
de372e69-0309-423c-8771-a1fa169cb09b	penguji	settingsDokumen	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
d6dbd7a0-7339-419c-bd09-f392d5e570a5	anggota	settingsDokumen	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
5967fc01-dad5-4e99-af04-e2c8a79cda79	superadmin	settingsFcmTest	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
17dfaff9-9138-46fa-a2cc-4f811f0c1e61	admin_nasional	settingsFcmTest	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
f2a9d4ee-5ae0-44c3-a22e-a44fbffe9932	admin_distrik	settingsFcmTest	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
b13c43e3-65d7-4d05-a126-2c547df959fd	admin_wilayah	settingsFcmTest	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
6aae73ba-c0ba-4da6-9ee2-38baba3d0997	admin_ranting	settingsFcmTest	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
ff70270a-b8a3-4319-8bdc-c236d86507ab	admin_kegiatan	settingsFcmTest	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
d9fecd4e-7cfc-4303-a9c2-7798d0d9b624	penguji	settingsFcmTest	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
6367a79f-4133-4374-8272-6db1e5196d24	anggota	settingsFcmTest	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
c157435d-e5a5-4d8a-9fc1-6652d5025768	superadmin	settingsSessions	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
31aa6e3a-ce5c-45d5-8818-e8c015e03983	admin_nasional	settingsSessions	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
4e20cc65-df2f-43f5-91f3-8086026cc5ae	admin_distrik	settingsSessions	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
f7292def-0b4c-45ae-8236-bcaac853f302	admin_wilayah	settingsSessions	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
3c05230a-f006-4ef5-b83e-b2b46eb4b533	admin_ranting	settingsSessions	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
9348fc34-d781-41d3-99f9-cce7027ca6a7	admin_kegiatan	settingsSessions	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
cf216835-b6a6-44dc-bf53-9433b4b6d823	penguji	settingsSessions	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
d75dcfd9-15c5-4446-891f-916a758f8468	anggota	settingsSessions	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
e03d4120-19cc-48d6-9fea-50cb3db95382	superadmin	settingsBackup	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
21330200-9f13-4a99-80ad-5aac9482c4bc	admin_nasional	settingsBackup	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
899a5b60-9af2-499d-bfe2-723ab79ddc9f	admin_distrik	settingsBackup	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
62e32e97-d36a-4d6e-ad9b-0f2e57264df6	admin_wilayah	settingsBackup	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
4e4b7a16-f606-4d3d-a09f-f5bbaffd1f3e	admin_ranting	settingsBackup	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
fbe5a727-03f2-409b-99be-8602d7538f34	admin_kegiatan	settingsBackup	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
d657ceb9-2813-4f3e-8c8d-e98fa81da6ce	penguji	settingsBackup	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
a61c47ce-241e-44aa-9c70-32563042bf54	anggota	settingsBackup	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
2410176c-d8a5-4c8c-a73a-fd9f958ddf4d	superadmin	gamification	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
0cbe1813-bb92-404b-9740-4b3bf749d5dc	admin_nasional	gamification	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
ebb6b8db-a1f4-40cb-963c-83801c194fc1	admin_distrik	gamification	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
ab49a18d-0c6c-4d30-b22a-a778d225b8ff	admin_wilayah	gamification	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
a17e1e57-f97c-4cfb-8caa-0d2a0d1a3da2	admin_ranting	gamification	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
1d098beb-661e-4e0a-aab5-09c33c9fc715	admin_kegiatan	gamification	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
8ecae6d3-dae8-4170-82e8-187b05b28efd	penguji	gamification	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
61597db7-bf4a-4fa3-b7cf-44f1c6535073	anggota	gamification	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
4bf9d332-53c0-457a-99b6-292a765fa498	superadmin	gamificationAdmin	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
b7be1d5d-4a24-47f0-a82d-7d53f5286160	admin_nasional	gamificationAdmin	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
541bb78e-c2ab-417d-9e2e-d93deb41f4a9	admin_distrik	gamificationAdmin	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
838e52ff-7e87-4498-8e04-c99f74720455	admin_wilayah	gamificationAdmin	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
41dc7e15-6876-4607-a5e9-9e4e4e9736dd	admin_ranting	gamificationAdmin	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
e695442f-4e02-4b4c-9144-674724285975	admin_kegiatan	gamificationAdmin	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
c17541e4-3a3c-4004-818d-f1859b541f57	penguji	gamificationAdmin	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
8c86de79-200e-49cf-b9a0-693aafb6e55b	anggota	gamificationAdmin	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
b96a436e-e56c-4c29-a4fc-3f21f606e071	superadmin	gamificationScoreboard	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
03df0bf9-6f01-4d48-a288-be35320c93f7	admin_nasional	gamificationScoreboard	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
5fb789c7-d4f2-4eed-b7f4-ca3f6065ed36	admin_distrik	gamificationScoreboard	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
a48300ea-44d9-46ea-9218-d647bfaf9df2	admin_wilayah	gamificationScoreboard	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
699d1e8a-0b8e-420e-a038-88258e531f16	admin_ranting	gamificationScoreboard	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
f4e76bec-3fc5-4cd9-a029-5cb8fd76da33	admin_kegiatan	gamificationScoreboard	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
99702929-1d4e-4e08-a7f0-af7543c65d3c	penguji	gamificationScoreboard	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
b7599889-7c10-42f4-83aa-fdee7146281a	anggota	gamificationScoreboard	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
9757581d-c8a9-4dea-aa60-e0092b3c6df2	superadmin	gamificationReport	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
e1c4e7f5-b715-458c-abf7-843ca25c2fab	admin_nasional	gamificationReport	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
21a84ab7-37ed-48e3-b80d-d6e5d852c458	admin_distrik	gamificationReport	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
757fbf17-ef73-4531-961d-263c7ca71424	admin_wilayah	gamificationReport	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
f38d0907-6607-46d1-a6c1-b1d966c82c5f	admin_ranting	gamificationReport	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
405f88c6-544c-4daa-b7aa-4fb86b4c3a1d	admin_kegiatan	gamificationReport	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
a863acb9-ad52-4d0e-ba7b-aa97dd6a9db1	penguji	gamificationReport	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
0b837fa9-d9aa-468b-8217-3959fc76be1d	anggota	gamificationReport	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
b69ddc38-7fd7-4dd5-99af-a009c1098674	superadmin	scanStats	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
b0ee1eab-cc80-4101-9486-c4538dc1f1c6	admin_nasional	scanStats	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
d0284feb-e054-4156-8e5f-f1c9ea87e069	admin_distrik	scanStats	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
222ff36f-e555-453f-bf9c-154b7e7cfcb8	admin_wilayah	scanStats	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
7839a1be-85bb-4a26-b6d0-6209903c6c05	admin_ranting	scanStats	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
441797d7-2378-4331-9926-9ec5c6509b54	admin_kegiatan	scanStats	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
a5529950-bf2c-4f57-9142-22c9fae6237e	penguji	scanStats	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
897ca856-461e-4a83-97a3-30d96da84df5	anggota	scanStats	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
b8f576d2-c31d-4204-b975-1563f2ff3f78	superadmin	contentSejarah	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
40bb52eb-2872-44cb-8f15-05d93cf11d74	admin_nasional	contentSejarah	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
42f6b641-d741-4b7a-9246-d1f632d81074	admin_distrik	contentSejarah	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
d9c28606-961d-44ee-83cc-42b6a3ad052c	admin_wilayah	contentSejarah	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
2237590c-c882-4379-96ef-e6f674d58c03	admin_ranting	contentSejarah	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
159484ae-4720-44fa-b9ef-bd1a4425de3e	admin_kegiatan	contentSejarah	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
9b532e72-6a2b-4e47-a27c-36cd83725c07	penguji	contentSejarah	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
7245919b-6603-4b7b-8afe-326ad5b13bd6	anggota	contentSejarah	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
e1b3f4ec-6d8e-4ae1-b7b0-172ccbefae36	superadmin	contentOrganisasi	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
3412621d-760c-418a-a2d2-b0a0b63e4a89	admin_nasional	contentOrganisasi	t	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
20179a29-bfde-413a-ae3e-fe871fbe70d2	admin_distrik	contentOrganisasi	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
a0bc2bac-958f-4b02-a344-86a55dfbf49b	admin_wilayah	contentOrganisasi	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
69e43a59-5306-4b97-90b9-1812731e394d	admin_ranting	contentOrganisasi	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
0cb80cf0-73e7-44fa-a5d5-d7e4c174ae6c	admin_kegiatan	contentOrganisasi	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
e17398b7-e679-423d-bb48-7fac3e413144	penguji	contentOrganisasi	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
2c5ca1a4-7cae-4745-b768-52b124c0be4b	anggota	contentOrganisasi	f	2026-11-02 23:14:54.546	2026-11-02 23:14:54.546
53f999ac-98f6-4fbb-88e4-9812c326ea6d	admin_berita	galeriUpload	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
fd480c3d-ef65-4ab4-98bc-eb503d54561d	admin_berita	galeriManage	t	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
3f99430c-b69e-413f-b23c-f4df53bb99b1	admin_berita	dashboard	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
97e28187-c47b-41ae-9222-0e69f8538eac	admin_berita	activities	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
8c000955-a9c7-42a6-8a0e-83c5e1385239	admin_berita	calendar	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
6385f64d-c0f3-467d-8395-a74b366f87e2	admin_berita	forum	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
c61622f8-4e89-4cf6-900f-95923e9ad322	admin_berita	notifications	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
97804012-f389-45f7-b918-bf3e01e77835	admin_berita	orgChart	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
6048e3f8-c402-4ea4-b262-a04a594ae237	admin_berita	documents	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
4a72e796-0416-4fb5-81cd-4c354814014a	admin_berita	dues	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
5f1d0752-9692-404e-964b-442bce6233af	admin_berita	contentBerita	t	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
cdb0e2c7-bd87-45f7-a36b-8239dcd77af0	admin_berita	reports	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
2595f23b-a3d3-4866-9ec3-b126df1d881a	admin_berita	members	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
695a1958-d064-4b7d-abe6-29977e64659d	admin_berita	membersMutasi	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
3ab683c4-7d1c-49f7-8c94-bb6c76d780db	admin_berita	candidates	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
286899ff-ee82-4877-912e-425d45fe2e35	admin_berita	registrations	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
0a8f9810-0e7f-45d8-86ae-90245a5a1120	admin_berita	claims	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
2551542c-b269-4478-8f52-3f69ccffc665	admin_berita	letters	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
f1405f5e-50ec-4748-abd5-bd7ddc5991ff	superadmin	ktaQueue	t	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
f34b09f5-5c10-4152-860f-df8aedfbda3a	admin_nasional	ktaQueue	t	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
32063c19-a8eb-4e46-8b35-e687ca8529a2	admin_distrik	ktaQueue	t	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
52dc286d-7924-4620-8c52-1b88982a74b9	admin_wilayah	ktaQueue	t	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
ad8171cd-7359-41bc-be0f-a017278bf72a	admin_ranting	ktaQueue	t	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
fe1381f1-b17c-49aa-8601-ae2c5b651620	admin_kegiatan	ktaQueue	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
752341bc-ae19-4ad2-9137-b56073bef4d7	admin_berita	ktaQueue	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
f6945391-ab7a-4f2f-897e-6825498d5dbb	penguji	ktaQueue	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
9bf7ef14-9a48-405b-97cd-3dbc0665ae2f	anggota	ktaQueue	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
91c6db35-8638-4716-a13f-3b2cd31e754d	superadmin	ktaDistrikProcess	t	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
60b1a640-2c5c-464e-9be7-e7ce01211fc3	admin_nasional	ktaDistrikProcess	t	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
68dd955f-63fa-4efd-93b7-c7d41ab546e9	admin_distrik	ktaDistrikProcess	t	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
554670ef-6f1e-41e6-875b-b6e8674289b2	admin_wilayah	ktaDistrikProcess	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
9fb38ac3-b461-4bf8-9934-149d5651297e	admin_ranting	ktaDistrikProcess	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
2261e4d9-dcad-4e38-9821-ee96868a1069	admin_kegiatan	ktaDistrikProcess	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
c081dee0-167c-4280-a2e5-7e7a1e3179ad	admin_berita	ktaDistrikProcess	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
7d729d18-d39a-45e9-8509-cea3ba6d2e2f	penguji	ktaDistrikProcess	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
b803d30b-ec93-4636-b63e-ea58e1701907	anggota	ktaDistrikProcess	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
1ac1e526-fe5b-4b81-b3be-f177b9c654c0	superadmin	ktaAnalytics	t	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
28ff83b0-5948-4ea3-8572-a906a63cb309	admin_nasional	ktaAnalytics	t	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
b09ce2fe-42b4-4170-9078-e2e58bdf3539	admin_distrik	ktaAnalytics	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
dcabf6c4-3ca6-40e5-84ec-bd1dece1ce9b	admin_wilayah	ktaAnalytics	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
b48a11f4-77a6-41dd-bb35-522f25a28fb4	admin_ranting	ktaAnalytics	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
1d6e1d85-faa7-4268-8ded-055f0d8c6a7d	admin_kegiatan	ktaAnalytics	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
110d092e-a7be-47d5-82fb-aa6e5f30ecc7	admin_berita	ktaAnalytics	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
8e62f81d-3350-4e13-939a-b0998a9f3d98	penguji	ktaAnalytics	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
2cd82f77-eaa3-465f-91bd-918f645bb750	anggota	ktaAnalytics	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
926a6f9b-2158-4097-876b-0753be065b63	admin_berita	trainings	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
f6487d8d-8fb9-4eaf-8923-860a5cd8ecd6	admin_berita	graduations	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
7a23e272-9516-4ea7-b2e0-f4417a15e141	admin_berita	examiners	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
66d029c8-c952-4c79-84bf-34ce6364f2ce	admin_berita	assessments	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
02a15cb7-7978-4877-9e62-15a5c77b00ae	admin_berita	approvals	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
06fcab08-d788-42c5-9e08-98c2c64f744a	admin_berita	orgDocuments	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
50e8e0eb-addb-43bc-98d5-ecf28959e83b	admin_berita	settingsJabatan	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
17f16419-4532-492d-8aaa-e9f058295e61	admin_berita	settingsPeriode	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
9528d54e-9714-4cf1-927b-6aa754980496	admin_berita	settingsKepengurusan	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
5c20a2d0-9267-4dae-9341-10c1901a9392	admin_berita	settingsOrgChartEditor	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
450bc383-07da-4e22-a6bc-8b931e6ffb37	admin_berita	payments	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
02cca243-9926-4536-adb1-419ed53f4ec1	admin_berita	users	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
ddff0f11-ec15-43f7-a295-7d37694851e1	admin_berita	monitoring	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
f9e012d4-4014-4d0c-b220-0605223fd4fa	admin_berita	monitoringAlerts	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
a20509d1-9dcc-4542-9367-160082abc89a	admin_berita	monitoringIncidents	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
6ea095c2-4c50-436d-9225-d1da20546963	admin_berita	wsMonitor	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
b89fd1b9-d42e-434e-870c-287237be571a	admin_berita	adminQueues	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
a50e601d-a627-4fab-9fef-86c2c56ef77e	admin_berita	settings	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
4721188d-b2c0-4019-99e7-7f1d89f00b8b	superadmin	settingsGeneral	t	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
52efbc1c-2fd3-4d12-b712-ffa188d3a518	admin_nasional	settingsGeneral	t	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
c127d0d2-9a2a-4052-9d08-000be445c6ac	admin_distrik	settingsGeneral	t	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
c2056d69-6c90-4e4e-bd8e-902ad2ddce9a	admin_wilayah	settingsGeneral	t	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
588583ee-3315-41d9-92cb-c04a3f00dab4	admin_ranting	settingsGeneral	t	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
f4688520-e637-49fe-9e1a-16b25f38785a	admin_kegiatan	settingsGeneral	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
fbdba925-3f52-47c4-b293-50faae74d7c6	admin_berita	settingsGeneral	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
820f3122-8f3d-48d0-8921-a6853ec2df17	penguji	settingsGeneral	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
5399226e-98c4-4532-b761-3839d3cf027c	anggota	settingsGeneral	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
d4f8f05a-4549-4696-8710-27a64a4ed2a7	admin_berita	settingsMenuPermissions	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
72010bfa-ad63-455e-a8ca-8a12515aeff4	admin_berita	settingsEmail	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
05e1ad3b-4d3e-4074-8a4c-544e9128188b	admin_berita	settingsEmailLogs	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
47217da2-f0d5-4bda-9980-3ad346b1e833	admin_berita	settingsPenandatangan	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
7b1def5f-6a87-4e09-9e32-83e372b1aaf6	admin_berita	settingsKartu	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
499f282b-587f-43df-a3b8-09b9b20ca42d	admin_berita	settingsDokumen	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
a600b59e-ab61-421d-9ddd-a4d7103d1ff5	admin_berita	settingsFcmTest	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
1287cfa7-aa3c-4b93-af6c-3a908ccf5f40	admin_berita	settingsSessions	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
a4e68616-9af6-4266-8097-5262834f0fce	admin_berita	settingsBackup	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
90774220-a9e4-4d07-bc3b-c02a0d2a0711	admin_berita	gamification	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
7d64d8f4-8a80-4864-84b4-0db74495a751	admin_berita	gamificationAdmin	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
5fb27dbf-5533-4184-94a6-4bef5eeeb224	superadmin	gamificationSettings	t	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
c99cd43b-74e5-4a1f-a881-5ad4bbe48756	admin_nasional	gamificationSettings	t	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
e7fb72ad-9675-418e-9b1f-4f48e80a522e	admin_distrik	gamificationSettings	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
d0785172-387a-4a2d-8152-96a2e3328f7f	admin_wilayah	gamificationSettings	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
d4d365b8-e62a-41a3-b517-f275096fd63c	admin_ranting	gamificationSettings	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
7115a98f-d9d3-4800-80c9-cb29d2ff434e	admin_kegiatan	gamificationSettings	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
ab18450f-668a-4d2d-85d1-e4fb0b3b0580	admin_berita	gamificationSettings	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
34dab10c-44ac-4aa9-9156-5ea27db69dc1	penguji	gamificationSettings	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
457faa08-faaa-4ad3-969f-b3304d0d6361	anggota	gamificationSettings	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
83b1abb1-a9f7-425e-912b-9fbd650a302a	admin_berita	gamificationScoreboard	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
4ac8e660-d9e8-4883-adc3-cac132bdbcff	admin_berita	gamificationReport	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
4be82248-1e10-4537-a27f-13d8e1708a03	admin_berita	scanStats	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
df4ac86f-d7eb-42ee-b763-b015ea841d9c	superadmin	auditLogs	t	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
193f7055-c474-46b3-9b1e-d2ab7e051839	admin_nasional	auditLogs	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
fe69fb9a-9cf1-4d55-8b01-639312f862c9	admin_distrik	auditLogs	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
9aa19dfa-aefd-4885-8eea-85b7980d21a1	admin_wilayah	auditLogs	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
67616137-ea1c-4636-82a0-e38adaf8daca	admin_ranting	auditLogs	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
76cb6dc1-8f01-496b-86c7-32d258b4e7a5	admin_kegiatan	auditLogs	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
84913891-1a36-434e-844d-24d6c339ee33	admin_berita	auditLogs	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
a7e5d214-43d3-49b7-ba0a-d81a1a386b0a	penguji	auditLogs	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
38c607b5-fb43-4ec6-908e-ca09bdf99a6d	anggota	auditLogs	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
09b21f7e-486e-4457-b38b-f6aa3498f9f0	admin_berita	contentSejarah	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
baee88ab-4121-4069-9df1-9f4e8c9478eb	admin_berita	contentOrganisasi	f	2026-11-15 12:57:18.025	2026-11-15 12:57:18.025
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permissions (id, role, key, is_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sambutan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sambutan (id, judul, konten, tokoh, foto_tokoh, is_visible, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sejarah; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sejarah (id, konten, is_visible, updated_at) FROM stdin;
\.


--
-- Data for Name: sesi_ujian_peserta; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sesi_ujian_peserta (id, ujian_praktek_id, calon_anggota_id, durasi_standar_menit, tambahan_menit, mulai_at, selesai_at, status, diperpanjang_oleh, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.settings (id, key, value, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stempel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stempel (id, nama, image_path, is_active, created_at, updated_at, distrik_id) FROM stdin;
\.


--
-- Data for Name: suppressed_emails; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.suppressed_emails (id, email, reason, event_id, created_at) FROM stdin;
\.


--
-- Data for Name: surat_keluar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.surat_keluar (id, nomor_surat, tanggal_surat, tujuan, perihal, isi, file_path, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: surat_masuk; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.surat_masuk (id, nomor_surat, tanggal_surat, tanggal_terima, pengirim, perihal, file_scan_path, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tanda_tangan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tanda_tangan (id, user_id, nama, jabatan, image_path, is_active, created_at, updated_at, distrik_id) FROM stdin;
\.


--
-- Data for Name: tingkatan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tingkatan (id, nama, strip_count, strip_warna, urutan, created_at, updated_at) FROM stdin;
ed3cc0e4-6eda-430a-a1f8-dbb128e68c93	Anggota	0	#94a3b8	0	2026-10-30 01:16:53.543	2026-10-30 01:16:53.543
8af38a0b-e7bd-4776-97ac-0f25b8a7c615	Pratama	1	#1d4ed8	1	2026-10-30 01:16:53.549	2026-10-30 01:16:53.549
16000b00-ed06-4df4-bc68-38a3d2c6d0ac	Tamtama	2	#1d4ed8	2	2026-10-30 01:16:53.554	2026-10-30 01:16:53.554
ca9b2786-11ee-44f7-bd2a-9345172a3b2b	Muda	1	#ca8a04	3	2026-10-30 01:16:53.557	2026-10-30 01:16:53.557
2d592f5a-7b16-4f79-8ec0-a3172d7d8e4e	Madya	2	#ca8a04	4	2026-10-30 01:16:53.562	2026-10-30 01:16:53.562
436c7619-926b-4633-9a86-2db0da229a85	Utama	3	#ca8a04	5	2026-10-30 01:16:53.565	2026-10-30 01:16:53.565
\.


--
-- Data for Name: transfer_approvals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transfer_approvals (id, transfer_request_id, side, level, status, "order", decided_by, decided_at, note, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: transfer_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transfer_requests (id, anggota_id, from_ranting_id, to_ranting_id, reason, status, approved_by, approved_at, rejected_by, rejected_at, note, created_at, updated_at, requested_by, scope) FROM stdin;
\.


--
-- Data for Name: ujian_praktek; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ujian_praktek (id, kegiatan_id, nama, deskripsi, tanggal, durasi_menit, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ujian_praktek_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ujian_praktek_item (id, ujian_praktek_id, item_penilaian_id, urutan, created_at) FROM stdin;
\.


--
-- Data for Name: ujian_praktek_penilai; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ujian_praktek_penilai (id, ujian_praktek_id, penguji_user_id, catatan, created_at) FROM stdin;
\.


--
-- Data for Name: undangan_pendadaran; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.undangan_pendadaran (id, kegiatan_id, anggota_id, status, dikirim_at, konfirmasi_at, konfirmasi_oleh, catatan, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: unit_latihan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.unit_latihan (id, distrik_id, nama, tipe, lokasi, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_sessions (id, user_id, refresh_token, device_name, ip_address, user_agent, last_used_at, created_at, revoked_at) FROM stdin;
76920082-2d71-4f82-96e9-62fa3b3cbfbe	3970b5db-9f0f-4b63-b53f-86b8bf83301e	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzOTcwYjVkYi05ZjBmLTRiNjMtYjUzZi04NmI4YmY4MzMwMWUiLCJlbWFpbCI6InN1cGVyYWRtaW5AdGhzLXRobS5vcmciLCJyb2xlIjoic3VwZXJhZG1pbiIsImlhdCI6MTc5NDc1MDQ3MCwiZXhwIjoxNzk1OTYwMDcwfQ.xbLOsUKDUfs8SZ-bxTmmAkU5EprdkSETE0Zz7-6cYB4	\N	::1	axios/1.20.0	2026-11-15 13:47:50.903	2026-11-15 13:47:50.903	\N
17c7c54e-2880-42e5-907f-7c6298a06a42	3970b5db-9f0f-4b63-b53f-86b8bf83301e	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzOTcwYjVkYi05ZjBmLTRiNjMtYjUzZi04NmI4YmY4MzMwMWUiLCJlbWFpbCI6InN1cGVyYWRtaW5AdGhzLXRobS5vcmciLCJyb2xlIjoic3VwZXJhZG1pbiIsImlhdCI6MTc5NDc1MDQ5MCwiZXhwIjoxNzk1OTYwMDkwfQ.neiugAcmcmLy2h2xzQjWkTbedlWsCqcS95t5dMPtYqA	\N	::1	axios/1.20.0	2026-11-15 13:48:11.001	2026-11-15 13:48:11.001	\N
54768508-79b8-49fc-b5c0-41940a0c91c4	3970b5db-9f0f-4b63-b53f-86b8bf83301e	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzOTcwYjVkYi05ZjBmLTRiNjMtYjUzZi04NmI4YmY4MzMwMWUiLCJlbWFpbCI6InN1cGVyYWRtaW5AdGhzLXRobS5vcmciLCJyb2xlIjoic3VwZXJhZG1pbiIsImlhdCI6MTc5NDc1MDUwMSwiZXhwIjoxNzk1OTYwMTAxfQ.30VBJW8LHsku6cBILWrdTaAPzcTOjSK3AHE-R0leblg	\N	::1	axios/1.20.0	2026-11-15 13:48:21.144	2026-11-15 13:48:21.144	\N
5f31153d-1c52-4f44-90dc-f0f68dd6cf19	3970b5db-9f0f-4b63-b53f-86b8bf83301e	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzOTcwYjVkYi05ZjBmLTRiNjMtYjUzZi04NmI4YmY4MzMwMWUiLCJlbWFpbCI6InN1cGVyYWRtaW5AdGhzLXRobS5vcmciLCJyb2xlIjoic3VwZXJhZG1pbiIsImlhdCI6MTc5NDc1MDYzOSwiZXhwIjoxNzk1OTYwMjM5fQ.M5Rzi6eStWm1XlHDXsi-_pPoS02av7230Hqu4aUSGjE	\N	::1	axios/1.20.0	2026-11-15 13:50:39.436	2026-11-15 13:50:39.436	\N
85992f81-dc4b-4085-9273-633f7d3e9372	3970b5db-9f0f-4b63-b53f-86b8bf83301e	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzOTcwYjVkYi05ZjBmLTRiNjMtYjUzZi04NmI4YmY4MzMwMWUiLCJlbWFpbCI6InN1cGVyYWRtaW5AdGhzLXRobS5vcmciLCJyb2xlIjoic3VwZXJhZG1pbiIsImlhdCI6MTc5NDc1MDg2MCwiZXhwIjoxNzk1OTYwNDYwfQ.a4aiQjQ95qbLNumhspTtSjovK78GSdf4jA9oNzXuCvk	\N	::1	axios/1.20.0	2026-11-15 13:54:20.481	2026-11-15 13:54:20.481	\N
d2f2a602-93f0-49c2-801f-a14e8afd4efa	3970b5db-9f0f-4b63-b53f-86b8bf83301e	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzOTcwYjVkYi05ZjBmLTRiNjMtYjUzZi04NmI4YmY4MzMwMWUiLCJlbWFpbCI6InN1cGVyYWRtaW5AdGhzLXRobS5vcmciLCJyb2xlIjoic3VwZXJhZG1pbiIsImlhdCI6MTc5NDc1MTAyNSwiZXhwIjoxNzk1OTYwNjI1fQ.mqCMnv7wc3TNbC7ZpTWoPzIe6F3TGa_KC_6EYK_dIfg	\N	::1	axios/1.20.0	2026-11-15 13:57:05.394	2026-11-15 13:57:05.394	\N
1a82ee53-cde9-4c29-90cc-12fc52a2edc6	3970b5db-9f0f-4b63-b53f-86b8bf83301e	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzOTcwYjVkYi05ZjBmLTRiNjMtYjUzZi04NmI4YmY4MzMwMWUiLCJlbWFpbCI6InN1cGVyYWRtaW5AdGhzLXRobS5vcmciLCJyb2xlIjoic3VwZXJhZG1pbiIsImlhdCI6MTc5NDc1MTE1NiwiZXhwIjoxNzk1OTYwNzU2fQ.Iiaiz9FUAJJmeDn80iN3TSFMi0WuJ-2-qdSCm8KYyZ0	\N	::1	axios/1.20.0	2026-11-15 13:59:16.798	2026-11-15 13:59:16.798	\N
c9718cac-1f93-4353-8590-0fef00f6ef17	3970b5db-9f0f-4b63-b53f-86b8bf83301e	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzOTcwYjVkYi05ZjBmLTRiNjMtYjUzZi04NmI4YmY4MzMwMWUiLCJlbWFpbCI6InN1cGVyYWRtaW5AdGhzLXRobS5vcmciLCJyb2xlIjoic3VwZXJhZG1pbiIsImlhdCI6MTc5NDc1MjQzMywiZXhwIjoxNzk1OTYyMDMzfQ.ylDgsxt1D717MQpd_Gg_wEdOhC3GnIX_lNss3vWto4I	\N	::1	axios/1.20.0	2026-11-15 14:20:33.493	2026-11-15 14:20:33.493	\N
a5b660bf-da59-4e94-b122-382deab50c25	3970b5db-9f0f-4b63-b53f-86b8bf83301e	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzOTcwYjVkYi05ZjBmLTRiNjMtYjUzZi04NmI4YmY4MzMwMWUiLCJlbWFpbCI6InN1cGVyYWRtaW5AdGhzLXRobS5vcmciLCJyb2xlIjoic3VwZXJhZG1pbiIsImlhdCI6MTc5NDc5MjUyNiwiZXhwIjoxNzk2MDAyMTI2fQ.0n_RelKeOhm-hPUd47wsRDY5K0HQjN8qAbFyEoPP09M	\N	::1	axios/1.20.0	2026-11-16 01:28:46.049	2026-11-16 01:28:46.049	\N
ac71ceed-9e8e-4991-a56f-ab4fae4ab9a5	7c10db76-a09c-44e7-bb4e-77a255cb30b9	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI3YzEwZGI3Ni1hMDljLTQ0ZTctYmI0ZS03N2EyNTVjYjMwYjkiLCJlbWFpbCI6ImUyZS5tZW1iZXIrMTc5NDc5MjUyNjA4OUBleGFtcGxlLmNvbSIsInJvbGUiOiJhbmdnb3RhIiwiaWF0IjoxNzk0NzkyNTI2LCJleHAiOjE3OTYwMDIxMjZ9.-q1dCvONm1yZHBz7FeujaWP7Kgw4zOSHuLSONCS59q0	\N	::1	axios/1.20.0	2026-11-16 01:28:46.63	2026-11-16 01:28:46.63	\N
e8da7e80-50df-4aae-b80b-ca64d4c380b3	3970b5db-9f0f-4b63-b53f-86b8bf83301e	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzOTcwYjVkYi05ZjBmLTRiNjMtYjUzZi04NmI4YmY4MzMwMWUiLCJlbWFpbCI6InN1cGVyYWRtaW5AdGhzLXRobS5vcmciLCJyb2xlIjoic3VwZXJhZG1pbiIsImlhdCI6MTc5NDc5MjY1MiwiZXhwIjoxNzk2MDAyMjUyfQ.Xq488xE2Bp1-6duw6LUY6RC9PqQ2uT2mofznud1bh8E	\N	::1	axios/1.20.0	2026-11-16 01:30:52.805	2026-11-16 01:30:52.805	\N
e39c1cba-a808-40d7-a919-e0feb930e73f	3970b5db-9f0f-4b63-b53f-86b8bf83301e	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzOTcwYjVkYi05ZjBmLTRiNjMtYjUzZi04NmI4YmY4MzMwMWUiLCJlbWFpbCI6InN1cGVyYWRtaW5AdGhzLXRobS5vcmciLCJyb2xlIjoic3VwZXJhZG1pbiIsImlhdCI6MTc5NDc5MjczOCwiZXhwIjoxNzk2MDAyMzM4fQ.5yCTA82I5lmBIin7UxDosUEIeLP-T__DnVi99g8vvUc	\N	::1	axios/1.20.0	2026-11-16 01:32:18.213	2026-11-16 01:32:18.213	\N
48cc4d25-7d64-434f-9483-1f024e5cf8aa	f001e357-fa08-42f8-a647-095fdf32b757	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJmMDAxZTM1Ny1mYTA4LTQyZjgtYTY0Ny0wOTVmZGYzMmI3NTciLCJlbWFpbCI6ImUyZS5tZW1iZXIrMTc5NDc5MjczNzYxOEBleGFtcGxlLmNvbSIsInJvbGUiOiJhbmdnb3RhIiwiaWF0IjoxNzk0NzkyNzM4LCJleHAiOjE3OTYwMDIzMzh9.UDx1j1pkuFxWF4k5D_RhZ95FYEPis0qObL8Xd8Cl2yc	\N	::1	axios/1.20.0	2026-11-16 01:32:18.788	2026-11-16 01:32:18.788	\N
3f358542-0bba-414a-99d1-b669fdefaf06	3970b5db-9f0f-4b63-b53f-86b8bf83301e	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzOTcwYjVkYi05ZjBmLTRiNjMtYjUzZi04NmI4YmY4MzMwMWUiLCJlbWFpbCI6InN1cGVyYWRtaW5AdGhzLXRobS5vcmciLCJyb2xlIjoic3VwZXJhZG1pbiIsImlhdCI6MTc5NDc5MzU3NSwiZXhwIjoxNzk2MDAzMTc1fQ.wpf2ZJyYGUZKHyHdiVPd0SvlgjEkmMHnK3FKsWRvtQM	\N	::1	axios/1.20.0	2026-11-16 01:46:15.709	2026-11-16 01:46:15.709	\N
ebb4bda5-f122-4ca6-a068-acbc72315eec	4a3af5b9-8acb-4bc5-9ab1-2efcecc41d04	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI0YTNhZjViOS04YWNiLTRiYzUtOWFiMS0yZWZjZWNjNDFkMDQiLCJlbWFpbCI6ImUyZS5tZW1iZXIrMTc5NDc5MzU3NDY4OUBleGFtcGxlLmNvbSIsInJvbGUiOiJhbmdnb3RhIiwiaWF0IjoxNzk0NzkzNTc2LCJleHAiOjE3OTYwMDMxNzZ9.zDBVW_cA5dE-BaN74tbJhFthNBL5Lgi5pcb8jvMsKMc	\N	::1	axios/1.20.0	2026-11-16 01:46:16.323	2026-11-16 01:46:16.323	\N
caa946fa-5589-4672-879d-0ada962e9a14	3970b5db-9f0f-4b63-b53f-86b8bf83301e	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzOTcwYjVkYi05ZjBmLTRiNjMtYjUzZi04NmI4YmY4MzMwMWUiLCJlbWFpbCI6InN1cGVyYWRtaW5AdGhzLXRobS5vcmciLCJyb2xlIjoic3VwZXJhZG1pbiIsImlhdCI6MTc5NDc5MzY3NywiZXhwIjoxNzk2MDAzMjc3fQ.Ry1vhJcvPnqkyusp5IK4w-1thJAo4hzWM_ahhN8HdFo	\N	::1	axios/1.20.0	2026-11-16 01:47:57.784	2026-11-16 01:47:57.784	\N
f1f5137a-d356-476e-8f3d-4ec0266ea7af	c0f267a7-5bf8-41a2-ae1c-0ebb1e4c8d5d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJjMGYyNjdhNy01YmY4LTQxYTItYWUxYy0wZWJiMWU0YzhkNWQiLCJlbWFpbCI6ImUyZS5tZW1iZXIrMTc5NDc5MzY3NzIxMEBleGFtcGxlLmNvbSIsInJvbGUiOiJhbmdnb3RhIiwiaWF0IjoxNzk0NzkzNjc4LCJleHAiOjE3OTYwMDMyNzh9.7_b8Jklrnf68kKnmOOu5WUvzZJkVa48mTtakvI1g3gs	\N	::1	axios/1.20.0	2026-11-16 01:47:58.343	2026-11-16 01:47:58.343	\N
8db0da84-d324-4e1d-a1fb-ea8740ad51d2	3970b5db-9f0f-4b63-b53f-86b8bf83301e	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzOTcwYjVkYi05ZjBmLTRiNjMtYjUzZi04NmI4YmY4MzMwMWUiLCJlbWFpbCI6InN1cGVyYWRtaW5AdGhzLXRobS5vcmciLCJyb2xlIjoic3VwZXJhZG1pbiIsImlhdCI6MTc5NDc5NDg0NiwiZXhwIjoxNzk2MDA0NDQ2fQ.STipI307FxXpJPwXn3Aqjx8DST_XfuDXr2LtdknMXaQ	\N	::1	axios/1.20.0	2026-11-16 02:07:26.773	2026-11-16 02:07:26.773	\N
17b3bf26-e7d2-491e-ae14-89f7cdcff966	3970b5db-9f0f-4b63-b53f-86b8bf83301e	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzOTcwYjVkYi05ZjBmLTRiNjMtYjUzZi04NmI4YmY4MzMwMWUiLCJlbWFpbCI6InN1cGVyYWRtaW5AdGhzLXRobS5vcmciLCJyb2xlIjoic3VwZXJhZG1pbiIsImlhdCI6MTc5NDc5NTM0MCwiZXhwIjoxNzk2MDA0OTQwfQ.3uOhcn7o-TF2aKxTl8qd09vqxMds6Krl6xt8CIWkwGM	\N	::1	axios/1.20.0	2026-11-16 02:15:40.687	2026-11-16 02:15:40.687	\N
8f40e2a8-13fb-4025-9f2e-516821fe6d73	3970b5db-9f0f-4b63-b53f-86b8bf83301e	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzOTcwYjVkYi05ZjBmLTRiNjMtYjUzZi04NmI4YmY4MzMwMWUiLCJlbWFpbCI6InN1cGVyYWRtaW5AdGhzLXRobS5vcmciLCJyb2xlIjoic3VwZXJhZG1pbiIsImlhdCI6MTc5NDc5OTM2MywiZXhwIjoxNzk2MDA4OTYzfQ.1A6IqBhHLJghv6hmrUWRdaKe5NrfO48JD3NkNdBUDlk	\N	::1	axios/1.20.0	2026-11-16 03:22:43.627	2026-11-16 03:22:43.627	\N
383e4b32-65e6-40ba-9107-5961e99ad7cd	3970b5db-9f0f-4b63-b53f-86b8bf83301e	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzOTcwYjVkYi05ZjBmLTRiNjMtYjUzZi04NmI4YmY4MzMwMWUiLCJlbWFpbCI6InN1cGVyYWRtaW5AdGhzLXRobS5vcmciLCJyb2xlIjoic3VwZXJhZG1pbiIsImlhdCI6MTc5NDgzOTkxMywiZXhwIjoxNzk2MDQ5NTEzfQ.WgynG35f4dkOTsotKK8eQ8EZWw4DUcYs_MTjDVDkSRc	\N	::1	curl/8.22.0	2026-11-16 14:38:33.861	2026-11-16 14:38:33.861	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, nama_lengkap, role, ranting_id, fcm_token, refresh_token, is_active, created_at, updated_at, phone, must_change_password, failed_login_attempts, locked_until, totp_secret, totp_enabled, totp_verified_at, distrik_id, wilayah_id) FROM stdin;
9bde9cac-bbc8-4c1b-8fc2-521eadb19a07	superadmin@ths-thm.cloud	$2a$12$HbaJK.6uWoZ08PsCPDO7j.2toALlikz9Q1SHibnsnF0flC93wFXoq	Super Admin	superadmin	\N	\N	\N	t	2026-10-30 01:16:53.289	2026-10-30 01:16:53.289	\N	f	0	\N	\N	f	\N	\N	\N
425a1784-a2db-4c2a-8a56-aea917e62ec3	e2e.member+1794751156807@example.com	$2a$12$cJdm5k5TmaWzrt8HOvBboe4L6z.eHrJrOwmHfF8tNjU2rt7FFIGfm	E2E Test Member	anggota	\N	\N	\N	t	2026-11-15 13:59:17.053	2026-11-15 13:59:17.053	\N	f	0	\N	\N	f	\N	\N	\N
b0d4e8a2-ccf3-4f60-9498-cc25ef276a8b	e2e.member+1794752433513@example.com	$2a$12$MmrwJY4Cbh9bsRwhXj0uh.gX26wZf5gPpbzRgM.VaumaS1Uqmke6K	E2E Test Member	anggota	\N	\N	\N	t	2026-11-15 14:20:33.766	2026-11-15 14:20:33.766	\N	f	0	\N	\N	f	\N	\N	\N
3b2b89a4-aaa8-427d-a7e9-d3cebb0296f3	e2e.member@example.com	$2a$12$4EbZrFSgEzlLJCA/jzHYguML08cPj/0YTdJB/P19DVqUOYHP5mlFO	E2E Test Member	anggota	\N	\N	\N	t	2026-11-15 13:47:51.153	2026-11-15 13:47:51.153	\N	f	0	\N	\N	f	\N	\N	\N
c0f267a7-5bf8-41a2-ae1c-0ebb1e4c8d5d	e2e.member+1794793677210@example.com	$2a$12$JPVmWJukKoPhVkIxR5P9/u2fV1Koi0pxODyXOjl/13YJStSQwiY2a	E2E Test Member	anggota	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJjMGYyNjdhNy01YmY4LTQxYTItYWUxYy0wZWJiMWU0YzhkNWQiLCJlbWFpbCI6ImUyZS5tZW1iZXIrMTc5NDc5MzY3NzIxMEBleGFtcGxlLmNvbSIsInJvbGUiOiJhbmdnb3RhIiwiaWF0IjoxNzk0NzkzNjc4LCJleHAiOjE3OTYwMDMyNzh9.7_b8Jklrnf68kKnmOOu5WUvzZJkVa48mTtakvI1g3gs	t	2026-11-16 01:47:58.044	2026-11-16 01:47:58.34	\N	f	0	\N	\N	f	\N	\N	\N
a4cc4fc2-ebfc-4b87-9594-294d0ac78ef4	e2e.member+1794750501158@example.com	$2a$12$ZCBtLYXs9uXlyyzdeBWZdOQud0GiHPYjT4HoFp7ovFsxaB.2Yq7da	E2E Test Member	anggota	\N	\N	\N	t	2026-11-15 13:48:21.406	2026-11-15 13:48:21.406	\N	f	0	\N	\N	f	\N	\N	\N
7c10db76-a09c-44e7-bb4e-77a255cb30b9	e2e.member+1794792526089@example.com	$2a$12$hMJcwTHy9waicixePE08BeTnW9n6muqs8Dt0L4WrB1xUgU8ViWyZ6	E2E Test Member	anggota	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI3YzEwZGI3Ni1hMDljLTQ0ZTctYmI0ZS03N2EyNTVjYjMwYjkiLCJlbWFpbCI6ImUyZS5tZW1iZXIrMTc5NDc5MjUyNjA4OUBleGFtcGxlLmNvbSIsInJvbGUiOiJhbmdnb3RhIiwiaWF0IjoxNzk0NzkyNTI2LCJleHAiOjE3OTYwMDIxMjZ9.-q1dCvONm1yZHBz7FeujaWP7Kgw4zOSHuLSONCS59q0	t	2026-11-16 01:28:46.331	2026-11-16 01:28:46.622	\N	f	0	\N	\N	f	\N	\N	\N
daddc97f-1b22-44ca-9104-b4e8b57dafb8	e2e.member+1794751025406@example.com	$2a$12$M7LvcVp3yXotOCcRMD17pe7SN9Al6nvCMB2weLlfBS9Co4INyHKla	E2E Test Member	anggota	\N	\N	\N	t	2026-11-15 13:57:05.657	2026-11-15 13:57:05.657	\N	f	0	\N	\N	f	\N	\N	\N
f001e357-fa08-42f8-a647-095fdf32b757	e2e.member+1794792737618@example.com	$2a$12$2XeYfSkidW2FjFkeaqIbWeJXvdr7bnhm9cWBqEWdSXX84KQZXmSFi	E2E Test Member	anggota	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJmMDAxZTM1Ny1mYTA4LTQyZjgtYTY0Ny0wOTVmZGYzMmI3NTciLCJlbWFpbCI6ImUyZS5tZW1iZXIrMTc5NDc5MjczNzYxOEBleGFtcGxlLmNvbSIsInJvbGUiOiJhbmdnb3RhIiwiaWF0IjoxNzk0NzkyNzM4LCJleHAiOjE3OTYwMDIzMzh9.UDx1j1pkuFxWF4k5D_RhZ95FYEPis0qObL8Xd8Cl2yc	t	2026-11-16 01:32:18.484	2026-11-16 01:32:18.781	\N	f	0	\N	\N	f	\N	\N	\N
4a3af5b9-8acb-4bc5-9ab1-2efcecc41d04	e2e.member+1794793574689@example.com	$2a$12$CAEhxQojec3VQoT9mtVHBOBWN2uJF4/u50WF9x5PCgbo9SysTB6Ae	E2E Test Member	anggota	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI0YTNhZjViOS04YWNiLTRiYzUtOWFiMS0yZWZjZWNjNDFkMDQiLCJlbWFpbCI6ImUyZS5tZW1iZXIrMTc5NDc5MzU3NDY4OUBleGFtcGxlLmNvbSIsInJvbGUiOiJhbmdnb3RhIiwiaWF0IjoxNzk0NzkzNTc2LCJleHAiOjE3OTYwMDMxNzZ9.zDBVW_cA5dE-BaN74tbJhFthNBL5Lgi5pcb8jvMsKMc	t	2026-11-16 01:46:16.019	2026-11-16 01:46:16.315	\N	f	0	\N	\N	f	\N	\N	\N
3970b5db-9f0f-4b63-b53f-86b8bf83301e	superadmin@ths-thm.org	$2a$12$kr593PCQcaLtOiGUYUta1.T.9bCG24ASBsb1tIOHUaatKA4ffA4om	Super Admin	superadmin	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzOTcwYjVkYi05ZjBmLTRiNjMtYjUzZi04NmI4YmY4MzMwMWUiLCJlbWFpbCI6InN1cGVyYWRtaW5AdGhzLXRobS5vcmciLCJyb2xlIjoic3VwZXJhZG1pbiIsImlhdCI6MTc5NDgzOTkxMywiZXhwIjoxNzk2MDQ5NTEzfQ.WgynG35f4dkOTsotKK8eQ8EZWw4DUcYs_MTjDVDkSRc	t	2026-11-05 01:48:49.175	2026-11-16 14:38:33.856	\N	f	0	\N	\N	f	\N	\N	\N
\.


--
-- Data for Name: webhook_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhook_events (id, event_id, provider, event_type, payload, processed_at) FROM stdin;
\.


--
-- Data for Name: wilayah; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wilayah (id, distrik_id, kode_wilayah, nama, created_at, updated_at, is_visible) FROM stdin;
546ae91f-b802-4c6c-89e8-39dfcf969de6	ff8a62f0-8460-4b23-b60c-017bc20bc860	TESTW	Test Wilayah	2026-11-15 13:48:21.427	2026-11-15 13:48:21.427	t
064816de-d9dd-4900-9f62-24a3d609b486	24200442-6534-4f5c-8d66-2d241a62f992	TW1794750860495	Test Wilayah	2026-11-15 13:54:20.506	2026-11-15 13:54:20.506	t
73aed166-2212-4b5d-97ea-2d3f499c8d47	e114afe8-7254-4358-b409-d6286293ef71	TW1794751025406	Test Wilayah	2026-11-15 13:57:05.42	2026-11-15 13:57:05.42	t
20867e19-fb3b-4652-b207-21d0af0b4650	3340fd51-f9a4-4cbf-8f6a-2ba726d6bec2	TW1794751156807	Test Wilayah	2026-11-15 13:59:16.819	2026-11-15 13:59:16.819	t
457d7b94-3274-41fa-b5fd-e0c6f8afc533	36390b4d-10eb-47ce-823d-718c90780230	TW1794752433513	Test Wilayah	2026-11-15 14:20:33.527	2026-11-15 14:20:33.527	t
33cf071e-880e-4467-b364-0d7b3c0aaf9d	a261cd25-f0fb-4013-bdea-9c96ee068e4b	TW1794792526089	Test Wilayah	2026-11-16 01:28:46.099	2026-11-16 01:28:46.099	t
36afc707-48bb-480c-b101-f20c0b6df0d5	88864740-e3f4-4c1a-abc1-20dd9275c9fe	TW1794792737618	Test Wilayah	2026-11-16 01:32:18.245	2026-11-16 01:32:18.245	t
affab757-bcd2-45db-b753-9c2876aa3d39	4c0c5dff-6058-4fba-a48e-b1977647d8fb	TW1794793574689	Test Wilayah	2026-11-16 01:46:15.767	2026-11-16 01:46:15.767	t
88c795c9-4bb0-423c-be5c-eaa2356be8f5	5a265be7-c7c3-4a69-a7f2-d6bac8c82912	TW1794793677210	Test Wilayah	2026-11-16 01:47:57.809	2026-11-16 01:47:57.809	t
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: absensi_latihan absensi_latihan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.absensi_latihan
    ADD CONSTRAINT absensi_latihan_pkey PRIMARY KEY (id);


--
-- Name: anggota anggota_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.anggota
    ADD CONSTRAINT anggota_pkey PRIMARY KEY (id);


--
-- Name: approval_levels approval_levels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_levels
    ADD CONSTRAINT approval_levels_pkey PRIMARY KEY (id);


--
-- Name: approval_requests approval_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_pkey PRIMARY KEY (id);


--
-- Name: aspek_penilaian aspek_penilaian_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aspek_penilaian
    ADD CONSTRAINT aspek_penilaian_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: bank_info bank_info_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_info
    ADD CONSTRAINT bank_info_pkey PRIMARY KEY (id);


--
-- Name: berita berita_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.berita
    ADD CONSTRAINT berita_pkey PRIMARY KEY (id);


--
-- Name: bulk_notifications bulk_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bulk_notifications
    ADD CONSTRAINT bulk_notifications_pkey PRIMARY KEY (id);


--
-- Name: calon_anggota calon_anggota_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calon_anggota
    ADD CONSTRAINT calon_anggota_pkey PRIMARY KEY (id);


--
-- Name: card_templates card_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_templates
    ADD CONSTRAINT card_templates_pkey PRIMARY KEY (id);


--
-- Name: chat_members chat_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_members
    ADD CONSTRAINT chat_members_pkey PRIMARY KEY (id);


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- Name: chat_rooms chat_rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_rooms
    ADD CONSTRAINT chat_rooms_pkey PRIMARY KEY (id);


--
-- Name: check_ins check_ins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.check_ins
    ADD CONSTRAINT check_ins_pkey PRIMARY KEY (id);


--
-- Name: data_revisions data_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_revisions
    ADD CONSTRAINT data_revisions_pkey PRIMARY KEY (id);


--
-- Name: device_tokens device_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_tokens
    ADD CONSTRAINT device_tokens_pkey PRIMARY KEY (id);


--
-- Name: disposisi disposisi_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disposisi
    ADD CONSTRAINT disposisi_pkey PRIMARY KEY (id);


--
-- Name: distrik distrik_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distrik
    ADD CONSTRAINT distrik_pkey PRIMARY KEY (id);


--
-- Name: document_batch_jobs document_batch_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_batch_jobs
    ADD CONSTRAINT document_batch_jobs_pkey PRIMARY KEY (id);


--
-- Name: document_jobs document_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_jobs
    ADD CONSTRAINT document_jobs_pkey PRIMARY KEY (id);


--
-- Name: dokumen_kegiatan dokumen_kegiatan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dokumen_kegiatan
    ADD CONSTRAINT dokumen_kegiatan_pkey PRIMARY KEY (id);


--
-- Name: dokumen_organisasi dokumen_organisasi_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dokumen_organisasi
    ADD CONSTRAINT dokumen_organisasi_pkey PRIMARY KEY (id);


--
-- Name: dokumen_penandatangans dokumen_penandatangans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dokumen_penandatangans
    ADD CONSTRAINT dokumen_penandatangans_pkey PRIMARY KEY (id);


--
-- Name: dokumen dokumen_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dokumen
    ADD CONSTRAINT dokumen_pkey PRIMARY KEY (id);


--
-- Name: dokumen_versions dokumen_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dokumen_versions
    ADD CONSTRAINT dokumen_versions_pkey PRIMARY KEY (id);


--
-- Name: donasi_program donasi_program_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donasi_program
    ADD CONSTRAINT donasi_program_pkey PRIMARY KEY (id);


--
-- Name: dues_lock_history dues_lock_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dues_lock_history
    ADD CONSTRAINT dues_lock_history_pkey PRIMARY KEY (id);


--
-- Name: email_events email_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_events
    ADD CONSTRAINT email_events_pkey PRIMARY KEY (id);


--
-- Name: email_logs email_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_pkey PRIMARY KEY (id);


--
-- Name: email_templates email_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT email_templates_pkey PRIMARY KEY (id);


--
-- Name: evaluasi_latihan evaluasi_latihan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evaluasi_latihan
    ADD CONSTRAINT evaluasi_latihan_pkey PRIMARY KEY (id);


--
-- Name: feature_flags feature_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_pkey PRIMARY KEY (id);


--
-- Name: forum_categories forum_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forum_categories
    ADD CONSTRAINT forum_categories_pkey PRIMARY KEY (id);


--
-- Name: forum_post_reactions forum_post_reactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forum_post_reactions
    ADD CONSTRAINT forum_post_reactions_pkey PRIMARY KEY (id);


--
-- Name: forum_posts forum_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forum_posts
    ADD CONSTRAINT forum_posts_pkey PRIMARY KEY (id);


--
-- Name: forum_thread_reactions forum_thread_reactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forum_thread_reactions
    ADD CONSTRAINT forum_thread_reactions_pkey PRIMARY KEY (id);


--
-- Name: forum_threads forum_threads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forum_threads
    ADD CONSTRAINT forum_threads_pkey PRIMARY KEY (id);


--
-- Name: galeri_moderation_log galeri_moderation_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galeri_moderation_log
    ADD CONSTRAINT galeri_moderation_log_pkey PRIMARY KEY (id);


--
-- Name: galeri galeri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galeri
    ADD CONSTRAINT galeri_pkey PRIMARY KEY (id);


--
-- Name: gamification_badges gamification_badges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gamification_badges
    ADD CONSTRAINT gamification_badges_pkey PRIMARY KEY (id);


--
-- Name: gamification_events gamification_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gamification_events
    ADD CONSTRAINT gamification_events_pkey PRIMARY KEY (id);


--
-- Name: gamification_profiles gamification_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gamification_profiles
    ADD CONSTRAINT gamification_profiles_pkey PRIMARY KEY (id);


--
-- Name: gamification_redemptions gamification_redemptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gamification_redemptions
    ADD CONSTRAINT gamification_redemptions_pkey PRIMARY KEY (id);


--
-- Name: gamification_rewards gamification_rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gamification_rewards
    ADD CONSTRAINT gamification_rewards_pkey PRIMARY KEY (id);


--
-- Name: hasil_pendadaran hasil_pendadaran_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hasil_pendadaran
    ADD CONSTRAINT hasil_pendadaran_pkey PRIMARY KEY (id);


--
-- Name: import_batch_items import_batch_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batch_items
    ADD CONSTRAINT import_batch_items_pkey PRIMARY KEY (id);


--
-- Name: import_batches import_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_pkey PRIMARY KEY (id);


--
-- Name: import_logs import_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_logs
    ADD CONSTRAINT import_logs_pkey PRIMARY KEY (id);


--
-- Name: item_penilaian item_penilaian_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_penilaian
    ADD CONSTRAINT item_penilaian_pkey PRIMARY KEY (id);


--
-- Name: iuran iuran_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iuran
    ADD CONSTRAINT iuran_pkey PRIMARY KEY (id);


--
-- Name: iuran_recurring iuran_recurring_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iuran_recurring
    ADD CONSTRAINT iuran_recurring_pkey PRIMARY KEY (id);


--
-- Name: iuran_reminders iuran_reminders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iuran_reminders
    ADD CONSTRAINT iuran_reminders_pkey PRIMARY KEY (id);


--
-- Name: jabatan jabatan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jabatan
    ADD CONSTRAINT jabatan_pkey PRIMARY KEY (id);


--
-- Name: kategori_dokumen kategori_dokumen_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kategori_dokumen
    ADD CONSTRAINT kategori_dokumen_pkey PRIMARY KEY (id);


--
-- Name: kegiatan_peserta kegiatan_peserta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kegiatan_peserta
    ADD CONSTRAINT kegiatan_peserta_pkey PRIMARY KEY (id);


--
-- Name: kegiatan kegiatan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kegiatan
    ADD CONSTRAINT kegiatan_pkey PRIMARY KEY (id);


--
-- Name: kepengurusan kepengurusan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kepengurusan
    ADD CONSTRAINT kepengurusan_pkey PRIMARY KEY (id);


--
-- Name: klaim klaim_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.klaim
    ADD CONSTRAINT klaim_pkey PRIMARY KEY (id);


--
-- Name: kta_app_histories kta_app_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kta_app_histories
    ADD CONSTRAINT kta_app_histories_pkey PRIMARY KEY (id);


--
-- Name: kta_applications kta_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kta_applications
    ADD CONSTRAINT kta_applications_pkey PRIMARY KEY (id);


--
-- Name: kta_batches kta_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kta_batches
    ADD CONSTRAINT kta_batches_pkey PRIMARY KEY (id);


--
-- Name: latihan latihan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.latihan
    ADD CONSTRAINT latihan_pkey PRIMARY KEY (id);


--
-- Name: materi_latihan materi_latihan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.materi_latihan
    ADD CONSTRAINT materi_latihan_pkey PRIMARY KEY (id);


--
-- Name: member_referrals member_referrals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_referrals
    ADD CONSTRAINT member_referrals_pkey PRIMARY KEY (id);


--
-- Name: monitoring_alerts monitoring_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monitoring_alerts
    ADD CONSTRAINT monitoring_alerts_pkey PRIMARY KEY (id);


--
-- Name: nasional nasional_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nasional
    ADD CONSTRAINT nasional_pkey PRIMARY KEY (id);


--
-- Name: national_holidays national_holidays_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.national_holidays
    ADD CONSTRAINT national_holidays_pkey PRIMARY KEY (id);


--
-- Name: nilai_pendadaran nilai_pendadaran_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nilai_pendadaran
    ADD CONSTRAINT nilai_pendadaran_pkey PRIMARY KEY (id);


--
-- Name: notifikasi notifikasi_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifikasi
    ADD CONSTRAINT notifikasi_pkey PRIMARY KEY (id);


--
-- Name: oauth_accounts oauth_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_accounts
    ADD CONSTRAINT oauth_accounts_pkey PRIMARY KEY (id);


--
-- Name: organisasi organisasi_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisasi
    ADD CONSTRAINT organisasi_pkey PRIMARY KEY (id);


--
-- Name: payment_transactions payment_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT payment_transactions_pkey PRIMARY KEY (id);


--
-- Name: penandatangans penandatangans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penandatangans
    ADD CONSTRAINT penandatangans_pkey PRIMARY KEY (id);


--
-- Name: pendaftaran pendaftaran_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pendaftaran
    ADD CONSTRAINT pendaftaran_pkey PRIMARY KEY (id);


--
-- Name: penugasan_penguji penugasan_penguji_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penugasan_penguji
    ADD CONSTRAINT penugasan_penguji_pkey PRIMARY KEY (id);


--
-- Name: periode_aktif periode_aktif_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periode_aktif
    ADD CONSTRAINT periode_aktif_pkey PRIMARY KEY (id);


--
-- Name: periode periode_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periode
    ADD CONSTRAINT periode_pkey PRIMARY KEY (id);


--
-- Name: peserta_pendadaran peserta_pendadaran_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.peserta_pendadaran
    ADD CONSTRAINT peserta_pendadaran_pkey PRIMARY KEY (id);


--
-- Name: presensi_kegiatan presensi_kegiatan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presensi_kegiatan
    ADD CONSTRAINT presensi_kegiatan_pkey PRIMARY KEY (id);


--
-- Name: qr_codes qr_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qr_codes
    ADD CONSTRAINT qr_codes_pkey PRIMARY KEY (id);


--
-- Name: qr_scan qr_scan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qr_scan
    ADD CONSTRAINT qr_scan_pkey PRIMARY KEY (id);


--
-- Name: qr_validation qr_validation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qr_validation
    ADD CONSTRAINT qr_validation_pkey PRIMARY KEY (id);


--
-- Name: queue_uptime_events queue_uptime_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.queue_uptime_events
    ADD CONSTRAINT queue_uptime_events_pkey PRIMARY KEY (id);


--
-- Name: ranting ranting_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ranting
    ADD CONSTRAINT ranting_pkey PRIMARY KEY (id);


--
-- Name: risk_flags risk_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.risk_flags
    ADD CONSTRAINT risk_flags_pkey PRIMARY KEY (id);


--
-- Name: role_menu_permissions role_menu_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_menu_permissions
    ADD CONSTRAINT role_menu_permissions_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: sambutan sambutan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sambutan
    ADD CONSTRAINT sambutan_pkey PRIMARY KEY (id);


--
-- Name: sejarah sejarah_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sejarah
    ADD CONSTRAINT sejarah_pkey PRIMARY KEY (id);


--
-- Name: sesi_ujian_peserta sesi_ujian_peserta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sesi_ujian_peserta
    ADD CONSTRAINT sesi_ujian_peserta_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: stempel stempel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stempel
    ADD CONSTRAINT stempel_pkey PRIMARY KEY (id);


--
-- Name: suppressed_emails suppressed_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppressed_emails
    ADD CONSTRAINT suppressed_emails_pkey PRIMARY KEY (id);


--
-- Name: surat_keluar surat_keluar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.surat_keluar
    ADD CONSTRAINT surat_keluar_pkey PRIMARY KEY (id);


--
-- Name: surat_masuk surat_masuk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.surat_masuk
    ADD CONSTRAINT surat_masuk_pkey PRIMARY KEY (id);


--
-- Name: tanda_tangan tanda_tangan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tanda_tangan
    ADD CONSTRAINT tanda_tangan_pkey PRIMARY KEY (id);


--
-- Name: tingkatan tingkatan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tingkatan
    ADD CONSTRAINT tingkatan_pkey PRIMARY KEY (id);


--
-- Name: transfer_approvals transfer_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transfer_approvals
    ADD CONSTRAINT transfer_approvals_pkey PRIMARY KEY (id);


--
-- Name: transfer_requests transfer_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transfer_requests
    ADD CONSTRAINT transfer_requests_pkey PRIMARY KEY (id);


--
-- Name: ujian_praktek_item ujian_praktek_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ujian_praktek_item
    ADD CONSTRAINT ujian_praktek_item_pkey PRIMARY KEY (id);


--
-- Name: ujian_praktek_penilai ujian_praktek_penilai_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ujian_praktek_penilai
    ADD CONSTRAINT ujian_praktek_penilai_pkey PRIMARY KEY (id);


--
-- Name: ujian_praktek ujian_praktek_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ujian_praktek
    ADD CONSTRAINT ujian_praktek_pkey PRIMARY KEY (id);


--
-- Name: undangan_pendadaran undangan_pendadaran_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.undangan_pendadaran
    ADD CONSTRAINT undangan_pendadaran_pkey PRIMARY KEY (id);


--
-- Name: unit_latihan unit_latihan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unit_latihan
    ADD CONSTRAINT unit_latihan_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webhook_events webhook_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_events
    ADD CONSTRAINT webhook_events_pkey PRIMARY KEY (id);


--
-- Name: wilayah wilayah_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wilayah
    ADD CONSTRAINT wilayah_pkey PRIMARY KEY (id);


--
-- Name: absensi_latihan_anggota_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX absensi_latihan_anggota_id_idx ON public.absensi_latihan USING btree (anggota_id);


--
-- Name: absensi_latihan_latihan_id_anggota_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX absensi_latihan_latihan_id_anggota_id_key ON public.absensi_latihan USING btree (latihan_id, anggota_id);


--
-- Name: anggota_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX anggota_email_key ON public.anggota USING btree (email) WHERE (deleted_at IS NULL);


--
-- Name: anggota_no_hp_normalized_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX anggota_no_hp_normalized_idx ON public.anggota USING btree (no_hp_normalized);


--
-- Name: anggota_nomor_anggota_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX anggota_nomor_anggota_key ON public.anggota USING btree (nomor_anggota) WHERE (deleted_at IS NULL);


--
-- Name: anggota_status_data_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX anggota_status_data_idx ON public.anggota USING btree (status_data);


--
-- Name: approval_levels_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approval_levels_order_idx ON public.approval_levels USING btree ("order");


--
-- Name: approval_request_levels_request_id_approval_level_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX approval_request_levels_request_id_approval_level_id_key ON public.approval_request_levels USING btree (request_id, approval_level_id);


--
-- Name: approval_requests_requestType_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "approval_requests_requestType_idx" ON public.approval_requests USING btree ("requestType");


--
-- Name: approval_requests_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approval_requests_status_idx ON public.approval_requests USING btree (status);


--
-- Name: aspek_penilaian_kegiatan_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aspek_penilaian_kegiatan_id_idx ON public.aspek_penilaian USING btree (kegiatan_id);


--
-- Name: aspek_penilaian_kode_aspek_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aspek_penilaian_kode_aspek_idx ON public.aspek_penilaian USING btree (kode_aspek);


--
-- Name: aspek_penilaian_kode_aspek_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX aspek_penilaian_kode_aspek_key ON public.aspek_penilaian USING btree (kode_aspek);


--
-- Name: audit_logs_action_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_action_idx ON public.audit_logs USING btree (action);


--
-- Name: audit_logs_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_created_at_idx ON public.audit_logs USING btree (created_at DESC);


--
-- Name: audit_logs_entity_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_entity_id_idx ON public.audit_logs USING btree (entity_id);


--
-- Name: audit_logs_entity_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_entity_idx ON public.audit_logs USING btree (entity);


--
-- Name: audit_logs_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_user_id_idx ON public.audit_logs USING btree (user_id);


--
-- Name: berita_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX berita_created_at_idx ON public.berita USING btree (created_at);


--
-- Name: berita_is_visible_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX berita_is_visible_idx ON public.berita USING btree (is_visible);


--
-- Name: berita_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX berita_slug_key ON public.berita USING btree (slug);


--
-- Name: berita_tanggal_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX berita_tanggal_idx ON public.berita USING btree (tanggal);


--
-- Name: bulk_notifications_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bulk_notifications_status_idx ON public.bulk_notifications USING btree (status);


--
-- Name: calon_anggota_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX calon_anggota_created_at_idx ON public.calon_anggota USING btree (created_at);


--
-- Name: calon_anggota_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX calon_anggota_email_key ON public.calon_anggota USING btree (email);


--
-- Name: calon_anggota_ranting_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX calon_anggota_ranting_id_idx ON public.calon_anggota USING btree (ranting_id);


--
-- Name: calon_anggota_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX calon_anggota_status_idx ON public.calon_anggota USING btree (status);


--
-- Name: card_templates_distrik_id_is_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX card_templates_distrik_id_is_active_idx ON public.card_templates USING btree (distrik_id, is_active);


--
-- Name: card_templates_is_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX card_templates_is_active_idx ON public.card_templates USING btree (is_active);


--
-- Name: card_templates_name_scope_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX card_templates_name_scope_key ON public.card_templates USING btree (name, COALESCE(distrik_id, 'GLOBAL'::text));


--
-- Name: chat_members_anggota_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_members_anggota_id_idx ON public.chat_members USING btree (anggota_id);


--
-- Name: chat_members_room_id_anggota_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX chat_members_room_id_anggota_id_key ON public.chat_members USING btree (room_id, anggota_id);


--
-- Name: chat_members_room_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_members_room_id_idx ON public.chat_members USING btree (room_id);


--
-- Name: chat_messages_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_messages_created_at_idx ON public.chat_messages USING btree (created_at DESC);


--
-- Name: chat_messages_room_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_messages_room_id_idx ON public.chat_messages USING btree (room_id);


--
-- Name: chat_messages_sender_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_messages_sender_id_idx ON public.chat_messages USING btree (sender_id);


--
-- Name: chat_rooms_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_rooms_type_idx ON public.chat_rooms USING btree (type);


--
-- Name: check_ins_anggota_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX check_ins_anggota_id_idx ON public.check_ins USING btree (anggota_id);


--
-- Name: check_ins_checked_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX check_ins_checked_at_idx ON public.check_ins USING btree (checked_at DESC);


--
-- Name: data_revisions_entity_entity_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_revisions_entity_entity_id_created_at_idx ON public.data_revisions USING btree (entity, entity_id, created_at DESC);


--
-- Name: device_tokens_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX device_tokens_token_key ON public.device_tokens USING btree (token);


--
-- Name: device_tokens_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX device_tokens_user_id_idx ON public.device_tokens USING btree (user_id);


--
-- Name: disposisi_surat_masuk_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX disposisi_surat_masuk_id_idx ON public.disposisi USING btree (surat_masuk_id);


--
-- Name: distrik_kode_distrik_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX distrik_kode_distrik_key ON public.distrik USING btree (kode_distrik);


--
-- Name: document_batch_jobs_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX document_batch_jobs_created_at_idx ON public.document_batch_jobs USING btree (created_at DESC);


--
-- Name: document_batch_jobs_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX document_batch_jobs_status_idx ON public.document_batch_jobs USING btree (status);


--
-- Name: document_jobs_batch_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX document_jobs_batch_id_idx ON public.document_jobs USING btree (batch_id);


--
-- Name: document_jobs_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX document_jobs_status_idx ON public.document_jobs USING btree (status);


--
-- Name: dokumen_anggota_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dokumen_anggota_id_idx ON public.dokumen USING btree (anggota_id);


--
-- Name: dokumen_nomor_dokumen_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX dokumen_nomor_dokumen_key ON public.dokumen USING btree (nomor_dokumen);


--
-- Name: dokumen_penandatangans_dokumen_type_distrik_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dokumen_penandatangans_dokumen_type_distrik_id_idx ON public.dokumen_penandatangans USING btree (dokumen_type, distrik_id);


--
-- Name: dokumen_penandatangans_dokumen_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dokumen_penandatangans_dokumen_type_idx ON public.dokumen_penandatangans USING btree (dokumen_type);


--
-- Name: dokumen_penandatangans_scope_urutan_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX dokumen_penandatangans_scope_urutan_key ON public.dokumen_penandatangans USING btree (dokumen_type, COALESCE(distrik_id, 'GLOBAL'::text), urutan);


--
-- Name: dokumen_versions_dokumen_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dokumen_versions_dokumen_id_idx ON public.dokumen_versions USING btree (dokumen_id);


--
-- Name: donasi_program_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX donasi_program_created_at_idx ON public.donasi_program USING btree (created_at);


--
-- Name: donasi_program_is_visible_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX donasi_program_is_visible_idx ON public.donasi_program USING btree (is_visible);


--
-- Name: dues_lock_history_iuran_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dues_lock_history_iuran_id_idx ON public.dues_lock_history USING btree (iuran_id);


--
-- Name: email_events_email_log_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_events_email_log_id_idx ON public.email_events USING btree (email_log_id);


--
-- Name: email_events_event_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_events_event_idx ON public.email_events USING btree (event);


--
-- Name: email_events_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_events_timestamp_idx ON public.email_events USING btree ("timestamp" DESC);


--
-- Name: email_logs_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_logs_created_at_idx ON public.email_logs USING btree (created_at DESC);


--
-- Name: email_logs_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_logs_status_idx ON public.email_logs USING btree (status);


--
-- Name: email_logs_to_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_logs_to_idx ON public.email_logs USING btree ("to");


--
-- Name: email_templates_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX email_templates_name_key ON public.email_templates USING btree (name);


--
-- Name: evaluasi_latihan_anggota_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX evaluasi_latihan_anggota_id_idx ON public.evaluasi_latihan USING btree (anggota_id);


--
-- Name: evaluasi_latihan_latihan_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX evaluasi_latihan_latihan_id_idx ON public.evaluasi_latihan USING btree (latihan_id);


--
-- Name: feature_flags_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX feature_flags_key_key ON public.feature_flags USING btree (key);


--
-- Name: forum_post_reactions_post_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX forum_post_reactions_post_id_idx ON public.forum_post_reactions USING btree (post_id);


--
-- Name: forum_post_reactions_post_id_user_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX forum_post_reactions_post_id_user_id_key ON public.forum_post_reactions USING btree (post_id, user_id);


--
-- Name: forum_post_reactions_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX forum_post_reactions_user_id_idx ON public.forum_post_reactions USING btree (user_id);


--
-- Name: forum_posts_author_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX forum_posts_author_id_idx ON public.forum_posts USING btree (author_id);


--
-- Name: forum_posts_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX forum_posts_created_at_idx ON public.forum_posts USING btree (created_at);


--
-- Name: forum_posts_parent_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX forum_posts_parent_id_idx ON public.forum_posts USING btree (parent_id);


--
-- Name: forum_posts_thread_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX forum_posts_thread_id_idx ON public.forum_posts USING btree (thread_id);


--
-- Name: forum_thread_reactions_thread_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX forum_thread_reactions_thread_id_idx ON public.forum_thread_reactions USING btree (thread_id);


--
-- Name: forum_thread_reactions_thread_id_user_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX forum_thread_reactions_thread_id_user_id_key ON public.forum_thread_reactions USING btree (thread_id, user_id);


--
-- Name: forum_thread_reactions_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX forum_thread_reactions_user_id_idx ON public.forum_thread_reactions USING btree (user_id);


--
-- Name: forum_threads_author_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX forum_threads_author_id_idx ON public.forum_threads USING btree (author_id);


--
-- Name: forum_threads_category_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX forum_threads_category_id_idx ON public.forum_threads USING btree (category_id);


--
-- Name: forum_threads_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX forum_threads_created_at_idx ON public.forum_threads USING btree (created_at DESC);


--
-- Name: galeri_kategori_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX galeri_kategori_idx ON public.galeri USING btree (kategori);


--
-- Name: galeri_moderation_log_galeri_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX galeri_moderation_log_galeri_id_created_at_idx ON public.galeri_moderation_log USING btree (galeri_id, created_at);


--
-- Name: galeri_status_is_visible_tanggal_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX galeri_status_is_visible_tanggal_idx ON public.galeri USING btree (status, is_visible, tanggal);


--
-- Name: galeri_storage_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX galeri_storage_key_key ON public.galeri USING btree (storage_key);


--
-- Name: galeri_thumb_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX galeri_thumb_key_key ON public.galeri USING btree (thumb_key);


--
-- Name: galeri_uploader_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX galeri_uploader_id_idx ON public.galeri USING btree (uploader_id);


--
-- Name: gamification_badges_badge_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gamification_badges_badge_id_idx ON public.gamification_badges USING btree (badge_id);


--
-- Name: gamification_badges_profile_id_badge_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gamification_badges_profile_id_badge_id_idx ON public.gamification_badges USING btree (profile_id, badge_id);


--
-- Name: gamification_badges_profile_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gamification_badges_profile_id_idx ON public.gamification_badges USING btree (profile_id);


--
-- Name: gamification_events_anggota_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gamification_events_anggota_id_idx ON public.gamification_events USING btree (anggota_id);


--
-- Name: gamification_events_profile_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gamification_events_profile_id_idx ON public.gamification_events USING btree (profile_id);


--
-- Name: gamification_events_profile_id_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gamification_events_profile_id_timestamp_idx ON public.gamification_events USING btree (profile_id, "timestamp" DESC);


--
-- Name: gamification_events_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gamification_events_timestamp_idx ON public.gamification_events USING btree ("timestamp" DESC);


--
-- Name: gamification_profiles_anggota_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gamification_profiles_anggota_id_idx ON public.gamification_profiles USING btree (anggota_id);


--
-- Name: gamification_profiles_anggota_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX gamification_profiles_anggota_id_key ON public.gamification_profiles USING btree (anggota_id);


--
-- Name: gamification_profiles_points_anggota_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gamification_profiles_points_anggota_id_idx ON public.gamification_profiles USING btree (points DESC, anggota_id);


--
-- Name: gamification_profiles_points_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gamification_profiles_points_idx ON public.gamification_profiles USING btree (points DESC);


--
-- Name: gamification_redemptions_anggota_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gamification_redemptions_anggota_id_idx ON public.gamification_redemptions USING btree (anggota_id);


--
-- Name: gamification_redemptions_reward_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gamification_redemptions_reward_id_idx ON public.gamification_redemptions USING btree (reward_id);


--
-- Name: hasil_pendadaran_kegiatan_id_calon_anggota_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX hasil_pendadaran_kegiatan_id_calon_anggota_id_key ON public.hasil_pendadaran USING btree (kegiatan_id, calon_anggota_id);


--
-- Name: import_batch_items_batch_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX import_batch_items_batch_id_idx ON public.import_batch_items USING btree (batch_id);


--
-- Name: import_batches_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX import_batches_created_at_idx ON public.import_batches USING btree (created_at DESC);


--
-- Name: import_batches_imported_by_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX import_batches_imported_by_id_idx ON public.import_batches USING btree (imported_by_id);


--
-- Name: import_batches_module_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX import_batches_module_idx ON public.import_batches USING btree (module);


--
-- Name: import_logs_imported_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX import_logs_imported_at_idx ON public.import_logs USING btree (imported_at DESC);


--
-- Name: import_logs_module_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX import_logs_module_idx ON public.import_logs USING btree (module);


--
-- Name: item_penilaian_aspek_kode_item_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX item_penilaian_aspek_kode_item_key ON public.item_penilaian USING btree (aspek_id, kode_item);


--
-- Name: item_penilaian_kode_item_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX item_penilaian_kode_item_idx ON public.item_penilaian USING btree (kode_item);


--
-- Name: iuran_anggota_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX iuran_anggota_id_idx ON public.iuran USING btree (anggota_id);


--
-- Name: iuran_anggota_id_periode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX iuran_anggota_id_periode_key ON public.iuran USING btree (anggota_id, periode);


--
-- Name: iuran_isLocked_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "iuran_isLocked_idx" ON public.iuran USING btree ("isLocked");


--
-- Name: iuran_locked_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX iuran_locked_at_idx ON public.iuran USING btree (locked_at);


--
-- Name: iuran_recurring_anggota_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX iuran_recurring_anggota_id_idx ON public.iuran_recurring USING btree (anggota_id);


--
-- Name: iuran_reminders_iuran_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX iuran_reminders_iuran_id_idx ON public.iuran_reminders USING btree (iuran_id);


--
-- Name: iuran_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX iuran_status_idx ON public.iuran USING btree (status);


--
-- Name: jabatan_distrik_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX jabatan_distrik_id_idx ON public.jabatan USING btree (distrik_id);


--
-- Name: jabatan_kode_scope_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX jabatan_kode_scope_key ON public.jabatan USING btree (kode, COALESCE(distrik_id, 'GLOBAL'::text));


--
-- Name: jabatan_nama_scope_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX jabatan_nama_scope_key ON public.jabatan USING btree (nama, COALESCE(distrik_id, 'GLOBAL'::text));


--
-- Name: kegiatan_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kegiatan_created_at_idx ON public.kegiatan USING btree (created_at);


--
-- Name: kegiatan_peserta_anggota_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kegiatan_peserta_anggota_id_idx ON public.kegiatan_peserta USING btree (anggota_id);


--
-- Name: kegiatan_peserta_kegiatan_id_anggota_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX kegiatan_peserta_kegiatan_id_anggota_id_key ON public.kegiatan_peserta USING btree (kegiatan_id, anggota_id);


--
-- Name: kegiatan_scope_type_scope_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kegiatan_scope_type_scope_id_idx ON public.kegiatan USING btree (scope_type, scope_id);


--
-- Name: kegiatan_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kegiatan_status_idx ON public.kegiatan USING btree (status);


--
-- Name: kegiatan_tanggal_mulai_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kegiatan_tanggal_mulai_idx ON public.kegiatan USING btree (tanggal_mulai);


--
-- Name: kepengurusan_parent_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kepengurusan_parent_id_idx ON public.kepengurusan USING btree (parent_id);


--
-- Name: kepengurusan_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kepengurusan_status_idx ON public.kepengurusan USING btree (status);


--
-- Name: klaim_anggota_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX klaim_anggota_id_idx ON public.klaim USING btree (anggota_id);


--
-- Name: klaim_ranting_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX klaim_ranting_id_idx ON public.klaim USING btree (ranting_id);


--
-- Name: kta_app_histories_kta_application_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kta_app_histories_kta_application_id_idx ON public.kta_app_histories USING btree (kta_application_id);


--
-- Name: kta_applications_anggota_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kta_applications_anggota_id_idx ON public.kta_applications USING btree (anggota_id);


--
-- Name: kta_applications_batch_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kta_applications_batch_id_idx ON public.kta_applications USING btree (batch_id);


--
-- Name: kta_applications_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kta_applications_status_idx ON public.kta_applications USING btree (status);


--
-- Name: kta_applications_submitted_by_role_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kta_applications_submitted_by_role_idx ON public.kta_applications USING btree (submitted_by_role);


--
-- Name: kta_batches_scope_level_scope_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kta_batches_scope_level_scope_id_idx ON public.kta_batches USING btree (scope_level, scope_id);


--
-- Name: kta_batches_submitted_by_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kta_batches_submitted_by_id_idx ON public.kta_batches USING btree (submitted_by_id);


--
-- Name: latihan_ranting_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX latihan_ranting_id_idx ON public.latihan USING btree (ranting_id);


--
-- Name: materi_latihan_latihan_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX materi_latihan_latihan_id_idx ON public.materi_latihan USING btree (latihan_id);


--
-- Name: member_referrals_referred_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX member_referrals_referred_id_key ON public.member_referrals USING btree (referred_id);


--
-- Name: member_referrals_referrer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX member_referrals_referrer_id_idx ON public.member_referrals USING btree (referrer_id);


--
-- Name: nasional_kode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX nasional_kode_key ON public.nasional USING btree (kode);


--
-- Name: national_holidays_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX national_holidays_date_idx ON public.national_holidays USING btree (date);


--
-- Name: national_holidays_date_is_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX national_holidays_date_is_active_idx ON public.national_holidays USING btree (date, is_active);


--
-- Name: national_holidays_date_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX national_holidays_date_name_key ON public.national_holidays USING btree (date, name);


--
-- Name: nilai_pendadaran_item_penilaian_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nilai_pendadaran_item_penilaian_id_idx ON public.nilai_pendadaran USING btree (item_penilaian_id);


--
-- Name: nilai_pendadaran_kegiatan_id_calon_anggota_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nilai_pendadaran_kegiatan_id_calon_anggota_id_idx ON public.nilai_pendadaran USING btree (kegiatan_id, calon_anggota_id);


--
-- Name: nilai_pendadaran_penguji_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nilai_pendadaran_penguji_user_id_idx ON public.nilai_pendadaran USING btree (penguji_user_id);


--
-- Name: notifikasi_user_id_is_read_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifikasi_user_id_is_read_idx ON public.notifikasi USING btree (user_id, is_read);


--
-- Name: oauth_accounts_provider_provider_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX oauth_accounts_provider_provider_id_key ON public.oauth_accounts USING btree (provider, provider_id);


--
-- Name: oauth_accounts_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX oauth_accounts_user_id_idx ON public.oauth_accounts USING btree (user_id);


--
-- Name: payment_transactions_iuran_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_transactions_iuran_id_idx ON public.payment_transactions USING btree (iuran_id);


--
-- Name: payment_transactions_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_transactions_order_id_idx ON public.payment_transactions USING btree (order_id);


--
-- Name: payment_transactions_order_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX payment_transactions_order_id_key ON public.payment_transactions USING btree (order_id);


--
-- Name: penandatangans_distrik_id_is_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX penandatangans_distrik_id_is_active_idx ON public.penandatangans USING btree (distrik_id, is_active);


--
-- Name: penandatangans_is_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX penandatangans_is_active_idx ON public.penandatangans USING btree (is_active);


--
-- Name: penandatangans_single_active_scope_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX penandatangans_single_active_scope_idx ON public.penandatangans USING btree (COALESCE(distrik_id, 'GLOBAL'::text)) WHERE is_active;


--
-- Name: pendaftaran_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pendaftaran_created_at_idx ON public.pendaftaran USING btree (created_at);


--
-- Name: pendaftaran_ranting_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pendaftaran_ranting_id_idx ON public.pendaftaran USING btree (ranting_id);


--
-- Name: pendaftaran_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pendaftaran_status_idx ON public.pendaftaran USING btree (status);


--
-- Name: periode_aktif_level_unit_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX periode_aktif_level_unit_id_key ON public.periode_aktif USING btree (level, unit_id);


--
-- Name: periode_aktif_periode_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX periode_aktif_periode_id_idx ON public.periode_aktif USING btree (periode_id);


--
-- Name: peserta_pendadaran_calon_anggota_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX peserta_pendadaran_calon_anggota_id_idx ON public.peserta_pendadaran USING btree (calon_anggota_id);


--
-- Name: peserta_pendadaran_kegiatan_id_calon_anggota_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX peserta_pendadaran_kegiatan_id_calon_anggota_id_key ON public.peserta_pendadaran USING btree (kegiatan_id, calon_anggota_id);


--
-- Name: presensi_kegiatan_anggota_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX presensi_kegiatan_anggota_id_idx ON public.presensi_kegiatan USING btree (anggota_id);


--
-- Name: presensi_kegiatan_kegiatan_id_anggota_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX presensi_kegiatan_kegiatan_id_anggota_id_key ON public.presensi_kegiatan USING btree (kegiatan_id, anggota_id);


--
-- Name: qr_codes_anggota_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX qr_codes_anggota_id_idx ON public.qr_codes USING btree (anggota_id);


--
-- Name: qr_codes_token_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX qr_codes_token_idx ON public.qr_codes USING btree (token);


--
-- Name: qr_codes_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX qr_codes_token_key ON public.qr_codes USING btree (token);


--
-- Name: qr_scan_qr_validation_id_scanned_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX qr_scan_qr_validation_id_scanned_at_idx ON public.qr_scan USING btree (qr_validation_id, scanned_at DESC);


--
-- Name: qr_validation_dokumen_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX qr_validation_dokumen_id_idx ON public.qr_validation USING btree (dokumen_id);


--
-- Name: qr_validation_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX qr_validation_token_key ON public.qr_validation USING btree (token);


--
-- Name: queue_uptime_events_start_time_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX queue_uptime_events_start_time_idx ON public.queue_uptime_events USING btree (start_time DESC);


--
-- Name: ranting_wilayah_id_kode_ranting_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ranting_wilayah_id_kode_ranting_key ON public.ranting USING btree (wilayah_id, kode_ranting);


--
-- Name: risk_flags_anggota_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX risk_flags_anggota_id_idx ON public.risk_flags USING btree (anggota_id);


--
-- Name: role_menu_permissions_role_menu_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX role_menu_permissions_role_menu_key_key ON public.role_menu_permissions USING btree (role, menu_key);


--
-- Name: role_permissions_role_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX role_permissions_role_key_key ON public.role_permissions USING btree (role, key);


--
-- Name: sambutan_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sambutan_created_at_idx ON public.sambutan USING btree (created_at);


--
-- Name: sambutan_is_visible_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sambutan_is_visible_idx ON public.sambutan USING btree (is_visible);


--
-- Name: sejarah_is_visible_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sejarah_is_visible_idx ON public.sejarah USING btree (is_visible);


--
-- Name: sesi_ujian_peserta_calon_anggota_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sesi_ujian_peserta_calon_anggota_id_idx ON public.sesi_ujian_peserta USING btree (calon_anggota_id);


--
-- Name: sesi_ujian_peserta_ujian_praktek_id_calon_anggota_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sesi_ujian_peserta_ujian_praktek_id_calon_anggota_id_key ON public.sesi_ujian_peserta USING btree (ujian_praktek_id, calon_anggota_id);


--
-- Name: settings_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX settings_key_key ON public.settings USING btree (key);


--
-- Name: stempel_distrik_id_is_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stempel_distrik_id_is_active_idx ON public.stempel USING btree (distrik_id, is_active);


--
-- Name: suppressed_emails_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX suppressed_emails_email_idx ON public.suppressed_emails USING btree (email);


--
-- Name: suppressed_emails_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX suppressed_emails_email_key ON public.suppressed_emails USING btree (email);


--
-- Name: surat_keluar_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX surat_keluar_created_at_idx ON public.surat_keluar USING btree (created_at);


--
-- Name: surat_keluar_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX surat_keluar_status_idx ON public.surat_keluar USING btree (status);


--
-- Name: surat_keluar_tanggal_surat_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX surat_keluar_tanggal_surat_idx ON public.surat_keluar USING btree (tanggal_surat);


--
-- Name: surat_masuk_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX surat_masuk_created_at_idx ON public.surat_masuk USING btree (created_at);


--
-- Name: surat_masuk_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX surat_masuk_status_idx ON public.surat_masuk USING btree (status);


--
-- Name: surat_masuk_tanggal_terima_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX surat_masuk_tanggal_terima_idx ON public.surat_masuk USING btree (tanggal_terima);


--
-- Name: tanda_tangan_distrik_id_is_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tanda_tangan_distrik_id_is_active_idx ON public.tanda_tangan USING btree (distrik_id, is_active);


--
-- Name: tingkatan_nama_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tingkatan_nama_key ON public.tingkatan USING btree (nama);


--
-- Name: tingkatan_urutan_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tingkatan_urutan_idx ON public.tingkatan USING btree (urutan);


--
-- Name: transfer_approvals_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transfer_approvals_status_idx ON public.transfer_approvals USING btree (status);


--
-- Name: transfer_approvals_transfer_request_id_side_level_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX transfer_approvals_transfer_request_id_side_level_key ON public.transfer_approvals USING btree (transfer_request_id, side, level);


--
-- Name: transfer_requests_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transfer_requests_status_idx ON public.transfer_requests USING btree (status);


--
-- Name: ujian_praktek_item_ujian_praktek_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ujian_praktek_item_ujian_praktek_id_idx ON public.ujian_praktek_item USING btree (ujian_praktek_id);


--
-- Name: ujian_praktek_item_ujian_praktek_id_item_penilaian_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ujian_praktek_item_ujian_praktek_id_item_penilaian_id_key ON public.ujian_praktek_item USING btree (ujian_praktek_id, item_penilaian_id);


--
-- Name: ujian_praktek_kegiatan_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ujian_praktek_kegiatan_id_idx ON public.ujian_praktek USING btree (kegiatan_id);


--
-- Name: ujian_praktek_penilai_ujian_praktek_id_penguji_user_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ujian_praktek_penilai_ujian_praktek_id_penguji_user_id_key ON public.ujian_praktek_penilai USING btree (ujian_praktek_id, penguji_user_id);


--
-- Name: undangan_pendadaran_kegiatan_id_anggota_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX undangan_pendadaran_kegiatan_id_anggota_id_key ON public.undangan_pendadaran USING btree (kegiatan_id, anggota_id);


--
-- Name: user_sessions_refresh_token_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_sessions_refresh_token_idx ON public.user_sessions USING btree (refresh_token);


--
-- Name: user_sessions_refresh_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX user_sessions_refresh_token_key ON public.user_sessions USING btree (refresh_token);


--
-- Name: user_sessions_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_sessions_user_id_idx ON public.user_sessions USING btree (user_id);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_phone_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_phone_key ON public.users USING btree (phone);


--
-- Name: webhook_events_event_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX webhook_events_event_id_key ON public.webhook_events USING btree (event_id);


--
-- Name: webhook_events_processed_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhook_events_processed_at_idx ON public.webhook_events USING btree (processed_at DESC);


--
-- Name: webhook_events_provider_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhook_events_provider_idx ON public.webhook_events USING btree (provider);


--
-- Name: wilayah_distrik_id_kode_wilayah_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX wilayah_distrik_id_kode_wilayah_key ON public.wilayah USING btree (distrik_id, kode_wilayah);


--
-- Name: galeri_moderation_log galeri_moderation_log_no_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER galeri_moderation_log_no_update BEFORE UPDATE ON public.galeri_moderation_log FOR EACH ROW EXECUTE FUNCTION public.galeri_moderation_log_append_only();


--
-- Name: absensi_latihan absensi_latihan_anggota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.absensi_latihan
    ADD CONSTRAINT absensi_latihan_anggota_id_fkey FOREIGN KEY (anggota_id) REFERENCES public.anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: absensi_latihan absensi_latihan_latihan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.absensi_latihan
    ADD CONSTRAINT absensi_latihan_latihan_id_fkey FOREIGN KEY (latihan_id) REFERENCES public.latihan(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: anggota anggota_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.anggota
    ADD CONSTRAINT anggota_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: anggota anggota_ranting_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.anggota
    ADD CONSTRAINT anggota_ranting_id_fkey FOREIGN KEY (ranting_id) REFERENCES public.ranting(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: anggota anggota_updated_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.anggota
    ADD CONSTRAINT anggota_updated_by_id_fkey FOREIGN KEY (updated_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: approval_request_levels approval_request_levels_approval_level_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_request_levels
    ADD CONSTRAINT approval_request_levels_approval_level_id_fkey FOREIGN KEY (approval_level_id) REFERENCES public.approval_levels(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: approval_request_levels approval_request_levels_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_request_levels
    ADD CONSTRAINT approval_request_levels_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.approval_requests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: aspek_penilaian aspek_penilaian_kegiatan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aspek_penilaian
    ADD CONSTRAINT aspek_penilaian_kegiatan_id_fkey FOREIGN KEY (kegiatan_id) REFERENCES public.kegiatan(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_ranting_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_ranting_id_fkey FOREIGN KEY (ranting_id) REFERENCES public.ranting(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: calon_anggota calon_anggota_ranting_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calon_anggota
    ADD CONSTRAINT calon_anggota_ranting_id_fkey FOREIGN KEY (ranting_id) REFERENCES public.ranting(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: calon_anggota calon_anggota_usul_oleh_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calon_anggota
    ADD CONSTRAINT calon_anggota_usul_oleh_user_id_fkey FOREIGN KEY (usul_oleh_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: card_templates card_templates_distrik_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_templates
    ADD CONSTRAINT card_templates_distrik_id_fkey FOREIGN KEY (distrik_id) REFERENCES public.distrik(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_members chat_members_anggota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_members
    ADD CONSTRAINT chat_members_anggota_id_fkey FOREIGN KEY (anggota_id) REFERENCES public.anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_members chat_members_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_members
    ADD CONSTRAINT chat_members_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.chat_rooms(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_messages chat_messages_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.chat_rooms(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_messages chat_messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: check_ins check_ins_anggota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.check_ins
    ADD CONSTRAINT check_ins_anggota_id_fkey FOREIGN KEY (anggota_id) REFERENCES public.anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: check_ins check_ins_kegiatan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.check_ins
    ADD CONSTRAINT check_ins_kegiatan_id_fkey FOREIGN KEY (kegiatan_id) REFERENCES public.kegiatan(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: check_ins check_ins_latihan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.check_ins
    ADD CONSTRAINT check_ins_latihan_id_fkey FOREIGN KEY (latihan_id) REFERENCES public.latihan(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: check_ins check_ins_qr_code_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.check_ins
    ADD CONSTRAINT check_ins_qr_code_id_fkey FOREIGN KEY (qr_code_id) REFERENCES public.qr_codes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: data_revisions data_revisions_changed_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_revisions
    ADD CONSTRAINT data_revisions_changed_by_id_fkey FOREIGN KEY (changed_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: device_tokens device_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_tokens
    ADD CONSTRAINT device_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: disposisi disposisi_dari_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disposisi
    ADD CONSTRAINT disposisi_dari_user_id_fkey FOREIGN KEY (dari_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: disposisi disposisi_kepada_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disposisi
    ADD CONSTRAINT disposisi_kepada_user_id_fkey FOREIGN KEY (kepada_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: disposisi disposisi_surat_masuk_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disposisi
    ADD CONSTRAINT disposisi_surat_masuk_id_fkey FOREIGN KEY (surat_masuk_id) REFERENCES public.surat_masuk(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: distrik distrik_nasional_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distrik
    ADD CONSTRAINT distrik_nasional_id_fkey FOREIGN KEY (nasional_id) REFERENCES public.nasional(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: document_jobs document_jobs_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_jobs
    ADD CONSTRAINT document_jobs_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.document_batch_jobs(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dokumen dokumen_anggota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dokumen
    ADD CONSTRAINT dokumen_anggota_id_fkey FOREIGN KEY (anggota_id) REFERENCES public.anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dokumen_kegiatan dokumen_kegiatan_kegiatan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dokumen_kegiatan
    ADD CONSTRAINT dokumen_kegiatan_kegiatan_id_fkey FOREIGN KEY (kegiatan_id) REFERENCES public.kegiatan(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: dokumen_organisasi dokumen_organisasi_kategori_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dokumen_organisasi
    ADD CONSTRAINT dokumen_organisasi_kategori_id_fkey FOREIGN KEY (kategori_id) REFERENCES public.kategori_dokumen(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: dokumen_organisasi dokumen_organisasi_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dokumen_organisasi
    ADD CONSTRAINT dokumen_organisasi_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: dokumen_penandatangans dokumen_penandatangans_distrik_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dokumen_penandatangans
    ADD CONSTRAINT dokumen_penandatangans_distrik_id_fkey FOREIGN KEY (distrik_id) REFERENCES public.distrik(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dokumen_penandatangans dokumen_penandatangans_penandatangan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dokumen_penandatangans
    ADD CONSTRAINT dokumen_penandatangans_penandatangan_id_fkey FOREIGN KEY (penandatangan_id) REFERENCES public.penandatangans(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dues_lock_history dues_lock_history_iuran_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dues_lock_history
    ADD CONSTRAINT dues_lock_history_iuran_id_fkey FOREIGN KEY (iuran_id) REFERENCES public.iuran(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: email_events email_events_email_log_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_events
    ADD CONSTRAINT email_events_email_log_id_fkey FOREIGN KEY (email_log_id) REFERENCES public.email_logs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: evaluasi_latihan evaluasi_latihan_anggota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evaluasi_latihan
    ADD CONSTRAINT evaluasi_latihan_anggota_id_fkey FOREIGN KEY (anggota_id) REFERENCES public.anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: evaluasi_latihan evaluasi_latihan_latihan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evaluasi_latihan
    ADD CONSTRAINT evaluasi_latihan_latihan_id_fkey FOREIGN KEY (latihan_id) REFERENCES public.latihan(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: forum_post_reactions forum_post_reactions_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forum_post_reactions
    ADD CONSTRAINT forum_post_reactions_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.forum_posts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: forum_post_reactions forum_post_reactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forum_post_reactions
    ADD CONSTRAINT forum_post_reactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: forum_posts forum_posts_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forum_posts
    ADD CONSTRAINT forum_posts_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: forum_posts forum_posts_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forum_posts
    ADD CONSTRAINT forum_posts_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.forum_posts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: forum_posts forum_posts_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forum_posts
    ADD CONSTRAINT forum_posts_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.forum_threads(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: forum_thread_reactions forum_thread_reactions_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forum_thread_reactions
    ADD CONSTRAINT forum_thread_reactions_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.forum_threads(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: forum_thread_reactions forum_thread_reactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forum_thread_reactions
    ADD CONSTRAINT forum_thread_reactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: forum_threads forum_threads_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forum_threads
    ADD CONSTRAINT forum_threads_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: forum_threads forum_threads_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forum_threads
    ADD CONSTRAINT forum_threads_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.forum_categories(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: galeri_moderation_log galeri_moderation_log_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galeri_moderation_log
    ADD CONSTRAINT galeri_moderation_log_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: galeri_moderation_log galeri_moderation_log_galeri_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galeri_moderation_log
    ADD CONSTRAINT galeri_moderation_log_galeri_id_fkey FOREIGN KEY (galeri_id) REFERENCES public.galeri(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: galeri galeri_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galeri
    ADD CONSTRAINT galeri_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: galeri galeri_uploader_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galeri
    ADD CONSTRAINT galeri_uploader_id_fkey FOREIGN KEY (uploader_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: gamification_badges gamification_badges_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gamification_badges
    ADD CONSTRAINT gamification_badges_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.gamification_profiles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: gamification_events gamification_events_anggota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gamification_events
    ADD CONSTRAINT gamification_events_anggota_id_fkey FOREIGN KEY (anggota_id) REFERENCES public.anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: gamification_events gamification_events_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gamification_events
    ADD CONSTRAINT gamification_events_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.gamification_profiles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: gamification_profiles gamification_profiles_anggota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gamification_profiles
    ADD CONSTRAINT gamification_profiles_anggota_id_fkey FOREIGN KEY (anggota_id) REFERENCES public.anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: gamification_redemptions gamification_redemptions_anggota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gamification_redemptions
    ADD CONSTRAINT gamification_redemptions_anggota_id_fkey FOREIGN KEY (anggota_id) REFERENCES public.anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: gamification_redemptions gamification_redemptions_reward_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gamification_redemptions
    ADD CONSTRAINT gamification_redemptions_reward_id_fkey FOREIGN KEY (reward_id) REFERENCES public.gamification_rewards(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: hasil_pendadaran hasil_pendadaran_calon_anggota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hasil_pendadaran
    ADD CONSTRAINT hasil_pendadaran_calon_anggota_id_fkey FOREIGN KEY (calon_anggota_id) REFERENCES public.calon_anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hasil_pendadaran hasil_pendadaran_divalidasi_oleh_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hasil_pendadaran
    ADD CONSTRAINT hasil_pendadaran_divalidasi_oleh_fkey FOREIGN KEY (divalidasi_oleh) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: hasil_pendadaran hasil_pendadaran_kegiatan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hasil_pendadaran
    ADD CONSTRAINT hasil_pendadaran_kegiatan_id_fkey FOREIGN KEY (kegiatan_id) REFERENCES public.kegiatan(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: import_batch_items import_batch_items_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batch_items
    ADD CONSTRAINT import_batch_items_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.import_batches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: import_batches import_batches_imported_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_imported_by_id_fkey FOREIGN KEY (imported_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: item_penilaian item_penilaian_aspek_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.item_penilaian
    ADD CONSTRAINT item_penilaian_aspek_id_fkey FOREIGN KEY (aspek_id) REFERENCES public.aspek_penilaian(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: iuran iuran_anggota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iuran
    ADD CONSTRAINT iuran_anggota_id_fkey FOREIGN KEY (anggota_id) REFERENCES public.anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: iuran iuran_diverifikasi_oleh_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iuran
    ADD CONSTRAINT iuran_diverifikasi_oleh_fkey FOREIGN KEY (diverifikasi_oleh) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: iuran_recurring iuran_recurring_anggota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iuran_recurring
    ADD CONSTRAINT iuran_recurring_anggota_id_fkey FOREIGN KEY (anggota_id) REFERENCES public.anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: jabatan jabatan_distrik_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jabatan
    ADD CONSTRAINT jabatan_distrik_id_fkey FOREIGN KEY (distrik_id) REFERENCES public.distrik(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: kegiatan kegiatan_admin_kegiatan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kegiatan
    ADD CONSTRAINT kegiatan_admin_kegiatan_id_fkey FOREIGN KEY (admin_kegiatan_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: kegiatan kegiatan_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kegiatan
    ADD CONSTRAINT kegiatan_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: kegiatan_peserta kegiatan_peserta_anggota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kegiatan_peserta
    ADD CONSTRAINT kegiatan_peserta_anggota_id_fkey FOREIGN KEY (anggota_id) REFERENCES public.anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: kegiatan_peserta kegiatan_peserta_kegiatan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kegiatan_peserta
    ADD CONSTRAINT kegiatan_peserta_kegiatan_id_fkey FOREIGN KEY (kegiatan_id) REFERENCES public.kegiatan(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: kegiatan kegiatan_updated_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kegiatan
    ADD CONSTRAINT kegiatan_updated_by_id_fkey FOREIGN KEY (updated_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: kepengurusan kepengurusan_distrik_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kepengurusan
    ADD CONSTRAINT kepengurusan_distrik_id_fkey FOREIGN KEY (distrik_id) REFERENCES public.distrik(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: kepengurusan kepengurusan_jabatan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kepengurusan
    ADD CONSTRAINT kepengurusan_jabatan_id_fkey FOREIGN KEY (jabatan_id) REFERENCES public.jabatan(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: kepengurusan kepengurusan_nasional_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kepengurusan
    ADD CONSTRAINT kepengurusan_nasional_id_fkey FOREIGN KEY (nasional_id) REFERENCES public.nasional(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: kepengurusan kepengurusan_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kepengurusan
    ADD CONSTRAINT kepengurusan_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.kepengurusan(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: kepengurusan kepengurusan_periode_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kepengurusan
    ADD CONSTRAINT kepengurusan_periode_id_fkey FOREIGN KEY (periode_id) REFERENCES public.periode(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: kepengurusan kepengurusan_ranting_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kepengurusan
    ADD CONSTRAINT kepengurusan_ranting_id_fkey FOREIGN KEY (ranting_id) REFERENCES public.ranting(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: kepengurusan kepengurusan_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kepengurusan
    ADD CONSTRAINT kepengurusan_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: kepengurusan kepengurusan_wilayah_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kepengurusan
    ADD CONSTRAINT kepengurusan_wilayah_id_fkey FOREIGN KEY (wilayah_id) REFERENCES public.wilayah(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: klaim klaim_anggota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.klaim
    ADD CONSTRAINT klaim_anggota_id_fkey FOREIGN KEY (anggota_id) REFERENCES public.anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: klaim klaim_ranting_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.klaim
    ADD CONSTRAINT klaim_ranting_id_fkey FOREIGN KEY (ranting_id) REFERENCES public.ranting(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: kta_app_histories kta_app_histories_kta_application_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kta_app_histories
    ADD CONSTRAINT kta_app_histories_kta_application_id_fkey FOREIGN KEY (kta_application_id) REFERENCES public.kta_applications(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: kta_applications kta_applications_anggota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kta_applications
    ADD CONSTRAINT kta_applications_anggota_id_fkey FOREIGN KEY (anggota_id) REFERENCES public.anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: kta_applications kta_applications_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kta_applications
    ADD CONSTRAINT kta_applications_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.kta_batches(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: latihan latihan_kegiatan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.latihan
    ADD CONSTRAINT latihan_kegiatan_id_fkey FOREIGN KEY (kegiatan_id) REFERENCES public.kegiatan(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: latihan latihan_pelatih_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.latihan
    ADD CONSTRAINT latihan_pelatih_id_fkey FOREIGN KEY (pelatih_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: latihan latihan_ranting_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.latihan
    ADD CONSTRAINT latihan_ranting_id_fkey FOREIGN KEY (ranting_id) REFERENCES public.ranting(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: materi_latihan materi_latihan_latihan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.materi_latihan
    ADD CONSTRAINT materi_latihan_latihan_id_fkey FOREIGN KEY (latihan_id) REFERENCES public.latihan(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: member_referrals member_referrals_referred_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_referrals
    ADD CONSTRAINT member_referrals_referred_id_fkey FOREIGN KEY (referred_id) REFERENCES public.anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: member_referrals member_referrals_referrer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_referrals
    ADD CONSTRAINT member_referrals_referrer_id_fkey FOREIGN KEY (referrer_id) REFERENCES public.anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: nilai_pendadaran nilai_pendadaran_anggota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nilai_pendadaran
    ADD CONSTRAINT nilai_pendadaran_anggota_id_fkey FOREIGN KEY (anggota_id) REFERENCES public.anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: nilai_pendadaran nilai_pendadaran_calon_anggota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nilai_pendadaran
    ADD CONSTRAINT nilai_pendadaran_calon_anggota_id_fkey FOREIGN KEY (calon_anggota_id) REFERENCES public.calon_anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: nilai_pendadaran nilai_pendadaran_item_penilaian_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nilai_pendadaran
    ADD CONSTRAINT nilai_pendadaran_item_penilaian_id_fkey FOREIGN KEY (item_penilaian_id) REFERENCES public.item_penilaian(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: nilai_pendadaran nilai_pendadaran_kegiatan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nilai_pendadaran
    ADD CONSTRAINT nilai_pendadaran_kegiatan_id_fkey FOREIGN KEY (kegiatan_id) REFERENCES public.kegiatan(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: nilai_pendadaran nilai_pendadaran_penguji_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nilai_pendadaran
    ADD CONSTRAINT nilai_pendadaran_penguji_user_id_fkey FOREIGN KEY (penguji_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: nilai_pendadaran nilai_pendadaran_ujian_praktek_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nilai_pendadaran
    ADD CONSTRAINT nilai_pendadaran_ujian_praktek_id_fkey FOREIGN KEY (ujian_praktek_id) REFERENCES public.ujian_praktek(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: notifikasi notifikasi_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifikasi
    ADD CONSTRAINT notifikasi_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: oauth_accounts oauth_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_accounts
    ADD CONSTRAINT oauth_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payment_transactions payment_transactions_iuran_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT payment_transactions_iuran_id_fkey FOREIGN KEY (iuran_id) REFERENCES public.iuran(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: penandatangans penandatangans_distrik_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penandatangans
    ADD CONSTRAINT penandatangans_distrik_id_fkey FOREIGN KEY (distrik_id) REFERENCES public.distrik(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pendaftaran pendaftaran_ranting_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pendaftaran
    ADD CONSTRAINT pendaftaran_ranting_id_fkey FOREIGN KEY (ranting_id) REFERENCES public.ranting(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: penugasan_penguji penugasan_penguji_kegiatan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penugasan_penguji
    ADD CONSTRAINT penugasan_penguji_kegiatan_id_fkey FOREIGN KEY (kegiatan_id) REFERENCES public.kegiatan(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: penugasan_penguji penugasan_penguji_penguji_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penugasan_penguji
    ADD CONSTRAINT penugasan_penguji_penguji_user_id_fkey FOREIGN KEY (penguji_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: periode_aktif periode_aktif_periode_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periode_aktif
    ADD CONSTRAINT periode_aktif_periode_id_fkey FOREIGN KEY (periode_id) REFERENCES public.periode(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: peserta_pendadaran peserta_pendadaran_calon_anggota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.peserta_pendadaran
    ADD CONSTRAINT peserta_pendadaran_calon_anggota_id_fkey FOREIGN KEY (calon_anggota_id) REFERENCES public.calon_anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: peserta_pendadaran peserta_pendadaran_kegiatan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.peserta_pendadaran
    ADD CONSTRAINT peserta_pendadaran_kegiatan_id_fkey FOREIGN KEY (kegiatan_id) REFERENCES public.kegiatan(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: presensi_kegiatan presensi_kegiatan_anggota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presensi_kegiatan
    ADD CONSTRAINT presensi_kegiatan_anggota_id_fkey FOREIGN KEY (anggota_id) REFERENCES public.anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: presensi_kegiatan presensi_kegiatan_kegiatan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presensi_kegiatan
    ADD CONSTRAINT presensi_kegiatan_kegiatan_id_fkey FOREIGN KEY (kegiatan_id) REFERENCES public.kegiatan(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: qr_codes qr_codes_anggota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qr_codes
    ADD CONSTRAINT qr_codes_anggota_id_fkey FOREIGN KEY (anggota_id) REFERENCES public.anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: qr_scan qr_scan_qr_validation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qr_scan
    ADD CONSTRAINT qr_scan_qr_validation_id_fkey FOREIGN KEY (qr_validation_id) REFERENCES public.qr_validation(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: qr_validation qr_validation_dokumen_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qr_validation
    ADD CONSTRAINT qr_validation_dokumen_id_fkey FOREIGN KEY (dokumen_id) REFERENCES public.dokumen(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ranting ranting_wilayah_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ranting
    ADD CONSTRAINT ranting_wilayah_id_fkey FOREIGN KEY (wilayah_id) REFERENCES public.wilayah(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sesi_ujian_peserta sesi_ujian_peserta_calon_anggota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sesi_ujian_peserta
    ADD CONSTRAINT sesi_ujian_peserta_calon_anggota_id_fkey FOREIGN KEY (calon_anggota_id) REFERENCES public.calon_anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sesi_ujian_peserta sesi_ujian_peserta_ujian_praktek_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sesi_ujian_peserta
    ADD CONSTRAINT sesi_ujian_peserta_ujian_praktek_id_fkey FOREIGN KEY (ujian_praktek_id) REFERENCES public.ujian_praktek(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stempel stempel_distrik_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stempel
    ADD CONSTRAINT stempel_distrik_id_fkey FOREIGN KEY (distrik_id) REFERENCES public.distrik(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: suppressed_emails suppressed_emails_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppressed_emails
    ADD CONSTRAINT suppressed_emails_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.email_events(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tanda_tangan tanda_tangan_distrik_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tanda_tangan
    ADD CONSTRAINT tanda_tangan_distrik_id_fkey FOREIGN KEY (distrik_id) REFERENCES public.distrik(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tanda_tangan tanda_tangan_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tanda_tangan
    ADD CONSTRAINT tanda_tangan_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: transfer_approvals transfer_approvals_transfer_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transfer_approvals
    ADD CONSTRAINT transfer_approvals_transfer_request_id_fkey FOREIGN KEY (transfer_request_id) REFERENCES public.transfer_requests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: transfer_requests transfer_requests_anggota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transfer_requests
    ADD CONSTRAINT transfer_requests_anggota_id_fkey FOREIGN KEY (anggota_id) REFERENCES public.anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: transfer_requests transfer_requests_from_ranting_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transfer_requests
    ADD CONSTRAINT transfer_requests_from_ranting_id_fkey FOREIGN KEY (from_ranting_id) REFERENCES public.ranting(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: transfer_requests transfer_requests_to_ranting_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transfer_requests
    ADD CONSTRAINT transfer_requests_to_ranting_id_fkey FOREIGN KEY (to_ranting_id) REFERENCES public.ranting(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ujian_praktek_item ujian_praktek_item_item_penilaian_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ujian_praktek_item
    ADD CONSTRAINT ujian_praktek_item_item_penilaian_id_fkey FOREIGN KEY (item_penilaian_id) REFERENCES public.item_penilaian(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ujian_praktek_item ujian_praktek_item_ujian_praktek_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ujian_praktek_item
    ADD CONSTRAINT ujian_praktek_item_ujian_praktek_id_fkey FOREIGN KEY (ujian_praktek_id) REFERENCES public.ujian_praktek(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ujian_praktek ujian_praktek_kegiatan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ujian_praktek
    ADD CONSTRAINT ujian_praktek_kegiatan_id_fkey FOREIGN KEY (kegiatan_id) REFERENCES public.kegiatan(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ujian_praktek_penilai ujian_praktek_penilai_penguji_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ujian_praktek_penilai
    ADD CONSTRAINT ujian_praktek_penilai_penguji_user_id_fkey FOREIGN KEY (penguji_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ujian_praktek_penilai ujian_praktek_penilai_ujian_praktek_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ujian_praktek_penilai
    ADD CONSTRAINT ujian_praktek_penilai_ujian_praktek_id_fkey FOREIGN KEY (ujian_praktek_id) REFERENCES public.ujian_praktek(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: undangan_pendadaran undangan_pendadaran_anggota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.undangan_pendadaran
    ADD CONSTRAINT undangan_pendadaran_anggota_id_fkey FOREIGN KEY (anggota_id) REFERENCES public.anggota(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: undangan_pendadaran undangan_pendadaran_kegiatan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.undangan_pendadaran
    ADD CONSTRAINT undangan_pendadaran_kegiatan_id_fkey FOREIGN KEY (kegiatan_id) REFERENCES public.kegiatan(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: unit_latihan unit_latihan_distrik_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unit_latihan
    ADD CONSTRAINT unit_latihan_distrik_id_fkey FOREIGN KEY (distrik_id) REFERENCES public.distrik(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_distrik_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_distrik_id_fkey FOREIGN KEY (distrik_id) REFERENCES public.distrik(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: users users_ranting_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_ranting_id_fkey FOREIGN KEY (ranting_id) REFERENCES public.ranting(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: users users_wilayah_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_wilayah_id_fkey FOREIGN KEY (wilayah_id) REFERENCES public.wilayah(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: wilayah wilayah_distrik_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wilayah
    ADD CONSTRAINT wilayah_distrik_id_fkey FOREIGN KEY (distrik_id) REFERENCES public.distrik(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict mnNS2MsD0VJFduHmb5G79peSumBSVDGA1T2apEXmENUyX2PkDX8WgOfgE4txcyh

